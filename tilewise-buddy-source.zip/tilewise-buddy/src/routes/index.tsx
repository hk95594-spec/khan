import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, useCallback, useRef } from "react";
import StockEditableCell from "@/components/StockEditableCell";
import StockImageCell from "@/components/StockImageCell";
import { stockEditPatch, type StockField, type StockPatch } from "@/lib/stock-edit";
import { supabase } from "@/integrations/supabase/client";
import SaleHistory, { buildInvoiceHtml as buildSaleInvoiceHtml } from "@/components/SaleHistory";
import ReturnHistory from "@/components/ReturnHistory";
import GodownStatus from "@/components/GodownStatus";
import CustomerManager from "@/components/CustomerManager";
import CustomerReport from "@/components/CustomerReport";
import CompanyReport from "@/components/CompanyReport";
import SupplierPayment from "@/components/SupplierPayment";
import ExpenseManager from "@/components/ExpenseManager";
import CostReport from "@/components/CostReport";
import DailyAccount from "@/components/DailyAccount";
import DailySummary from "@/components/DailySummary";
import PurchaseProduct from "@/components/PurchaseProduct";
import PurchaseHistory from "@/components/PurchaseHistory";
import { toast } from "sonner";
import SearchSelect from "@/components/SearchSelect";
import { INVOICE_CSS, INVOICE_LOGO_SVG } from "@/lib/invoice-style";
import logoAsset from "@/assets/alam-tiles-logo.asset.json";
import jsPDF from "jspdf";
import { openWhatsApp } from "@/lib/whatsapp";
import {
  LayoutDashboard, FileText, History, Undo2, Boxes, Warehouse,
  UserPlus, LineChart, Tags, Package, ShoppingCart, Truck,
  TruckIcon, Wallet, Coins, PieChart, ArrowLeftRight, BarChart3, LogOut, Plus, MessageSquare, Building2, Search,
  User, Phone, MapPin, CreditCard, BookOpen, X, IdCard, Sparkles, Pencil, Trash2, Scissors,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Alam Tiles - Inventory Management Dashboard" },
      { name: "description", content: "Complete inventory dashboard for Alam Tiles - manage sales, stock, customers, suppliers, and profit tracking in one place." },
      { property: "og:title", content: "Alam Tiles - Inventory Management Dashboard" },
      { property: "og:description", content: "Complete inventory dashboard for Alam Tiles - manage sales, stock, customers, suppliers, and profit tracking in one place." },
      { property: "og:url", content: "https://tilewise-buddy.lovable.app/" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "canonical", href: "https://tilewise-buddy.lovable.app/" },
    ],
  }),
  component: IndexPage,
});

// ------- types -------
type Product = {
  id: string; name: string; category: string | null; company: string | null; size: string | null;
  sqft_per_piece: number; pcs_per_carton: number; stock_pieces: number;
  purchase_price_per_piece: number; sell_price_per_piece: number;
  min_label_feet?: number;
  product_code: string | null;
  image_path?: string | null;
};
type Customer = { id: string; name: string; mobile: string | null; address: string | null; due_amount: number };
type Supplier = { id: string; name: string; mobile: string | null; address: string | null; company?: string | null; advance: number; total_due: number };
type SaleItem = { productId: string; pieces: number; totalPrice: number };
type Sale = {
  id: string; invoice_no: string; customer_id: string | null; total_amount: number;
  paid_amount: number; due_amount: number; items: SaleItem[]; is_returned: boolean;
  returned_amount: number; sale_date: string;
};
type Purchase = { id: string; product_id: string | null; supplier_id: string | null; pieces: number; cost_per_piece: number; total_cost: number; purchase_date: string };
type Category = { id: string; name: string };
type Company = { id: string; name: string };
type Cost = { id: string; description: string; amount: number; cost_date: string };
type CashTx = { id: string; type: "in" | "out"; amount: number; reason: string | null; trans_date: string };
type StockCut = { id: string; user_id: string; product_id: string | null; pieces: number; reason: string | null; cut_date: string; created_at: string };

const menuItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "saleForm", label: "Sale Form / Invoice", icon: FileText },
  { id: "saleHistory", label: "Sale History", icon: History },
  { id: "returnHistory", label: "Return History", icon: Undo2 },
  { id: "myStock", label: "My Stock", icon: Boxes },
  { id: "stockCut", label: "Damage List", icon: Scissors },
  { id: "godownStatus", label: "Godown Status", icon: Warehouse },
  { id: "addCustomer", label: "Add Customer & List", icon: UserPlus },
  { id: "customerReport", label: "Customer Report", icon: LineChart },
  { id: "addCategory", label: "Add Category", icon: Tags },
  { id: "addCompany", label: "Add Company", icon: Building2 },
  { id: "companyReport", label: "Company Report", icon: Building2 },
  { id: "addProduct", label: "Add Product", icon: Package },
  { id: "purchaseProduct", label: "Purchase Product", icon: ShoppingCart },
  { id: "purchaseHistory", label: "Purchase History", icon: Truck },
  { id: "addSupplier", label: "Add Supplier & List", icon: TruckIcon },
  { id: "supplierPayment", label: "Supplier Payment", icon: Wallet },
  { id: "addCost", label: "খরচ যোগ করুন", icon: Coins },
  { id: "costReport", label: "খরচ রিপোর্ট", icon: PieChart },
  { id: "cashInOut", label: "Cash In/Out", icon: ArrowLeftRight },
  { id: "profit", label: "লাভ / দৈনিক হিসাব", icon: BarChart3 },
  { id: "dailySummary", label: "Daily Account", icon: BookOpen },
] as const;

function IndexPage() {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string>("");
  const [activeMenu, setActiveMenu] = useState<string>("dashboard");
  const [editSaleId, setEditSaleId] = useState<string | null>(null);
  const [customerReportDueOnly, setCustomerReportDueOnly] = useState(false);

  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [costs, setCosts] = useState<Cost[]>([]);
  const [cashTx, setCashTx] = useState<CashTx[]>([]);
  const [stockCuts, setStockCuts] = useState<StockCut[]>([]);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (!session) navigate({ to: "/auth" });
      else {
        setUserId(session.user.id);
        setUserEmail(session.user.email ?? "");
      }
    });
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) navigate({ to: "/auth" });
      else {
        setUserId(data.session.user.id);
        setUserEmail(data.session.user.email ?? "");
      }
    });
    return () => sub.subscription.unsubscribe();
  }, [navigate]);

  const refreshAll = useCallback(async () => {
    if (!userId) return;
    const [p, c, s, sa, pu, cat, co, cs, ct, sc] = await Promise.all([
      supabase.from("products").select("*").order("created_at", { ascending: false }),
      supabase.from("customers").select("*").order("created_at", { ascending: false }),
      supabase.from("suppliers").select("*").order("created_at", { ascending: false }),
      supabase.from("sales").select("*").order("created_at", { ascending: false }),
      supabase.from("purchases").select("*").order("created_at", { ascending: false }),
      supabase.from("categories").select("*").order("created_at", { ascending: false }),
      supabase.from("companies").select("*").order("created_at", { ascending: false }),
      supabase.from("costs").select("*").order("created_at", { ascending: false }),
      supabase.from("cash_transactions").select("*").order("created_at", { ascending: false }),
      supabase.from("stock_cuts").select("*").order("created_at", { ascending: false }),
    ]);
    if (p.data) setProducts(p.data as any);
    if (c.data) setCustomers(c.data as any);
    if (s.data) setSuppliers(s.data as any);
    if (sa.data) setSales(sa.data as any);
    if (pu.data) setPurchases(pu.data as any);
    if (cat.data) setCategories(cat.data as any);
    if (co.data) setCompanies(co.data as any);
    if (cs.data) setCosts(cs.data as any);
    if (ct.data) setCashTx(ct.data as any);
    if (sc.data) setStockCuts(sc.data as any);
  }, [userId]);

  useEffect(() => { refreshAll(); }, [refreshAll]);

  const logout = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  };

  if (!userId) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  return (
    <div className="flex h-screen bg-gray-100 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 bg-white shadow-xl overflow-y-auto border-r border-gray-200 flex flex-col">
        <div className="p-5 bg-gradient-to-r from-blue-800 to-blue-700 text-white flex flex-col items-center">
          <img src={logoAsset.url} alt="Alam Tiles" className="w-12 h-12 object-contain rounded-lg bg-white p-1" />
          <h1 className="text-2xl font-bold mt-2">Alam Tiles</h1>
          <p className="text-xs text-blue-100 mt-1">{userEmail}</p>
        </div>
        <nav className="py-4 px-3 space-y-1 flex-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const active = activeMenu === item.id;
            return (
              <button key={item.id} onClick={() => setActiveMenu(item.id)}
                className={`w-full text-left px-4 py-2.5 rounded-xl flex items-center gap-3 text-sm font-medium transition-all ${
                  active ? "bg-blue-600 text-white shadow-md" : "text-gray-700 hover:bg-gray-100"
                }`}>
                <Icon className="w-4 h-4" /> {item.label}
              </button>
            );
          })}
        </nav>
        <button onClick={logout} className="m-3 px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg flex items-center gap-2">
          <LogOut className="w-4 h-4" /> Logout
        </button>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto p-6">
        {activeMenu === "dashboard" && <Dashboard products={products} customers={customers} suppliers={suppliers} sales={sales} purchases={purchases} costs={costs} cashTx={cashTx} stockCuts={stockCuts} onNavigate={setActiveMenu} onViewDueCustomers={() => setCustomerReportDueOnly(true)} />}
        {activeMenu === "saleForm" && <SaleForm userId={userId} products={products} customers={customers} sales={sales} refresh={refreshAll} onNavigate={setActiveMenu} editSaleId={editSaleId} clearEditSale={() => setEditSaleId(null)} />}
        {activeMenu === "saleHistory" && <SaleHistory sales={sales} customers={customers} products={products} userId={userId} refresh={refreshAll} onEditSale={(id) => { setEditSaleId(id); setActiveMenu("saleForm"); }} />}
        {activeMenu === "returnHistory" && <ReturnHistory sales={sales} customers={customers} products={products} userId={userId} refresh={refreshAll} />}
        {activeMenu === "myStock" && <MyStock userId={userId} products={products} categories={categories} companies={companies} purchases={purchases} sales={sales} stockCuts={stockCuts} suppliers={suppliers} refresh={refreshAll} />}
        {activeMenu === "stockCut" && <StockCutManager userId={userId} products={products} stockCuts={stockCuts} refresh={refreshAll} />}
        {activeMenu === "godownStatus" && <GodownStatus products={products} purchases={purchases} sales={sales} />}
        {activeMenu === "addCustomer" && <CustomerManager userId={userId} customers={customers} sales={sales} refresh={refreshAll} />}
        {activeMenu === "customerReport" && <CustomerReport userId={userId} customers={customers} sales={sales} products={products} refresh={refreshAll} showDueOnly={customerReportDueOnly} onEditSale={(id) => { setEditSaleId(id); setActiveMenu("saleForm"); }} />}
        {activeMenu === "addCategory" && <AddCategory userId={userId} categories={categories} refresh={refreshAll} />}
        {activeMenu === "addCompany" && <AddCompany userId={userId} companies={companies} refresh={refreshAll} />}
        {activeMenu === "companyReport" && <CompanyReport companies={companies} products={products} sales={sales} purchases={purchases} suppliers={suppliers} />}
        {activeMenu === "addProduct" && <AddProduct userId={userId} categories={categories} companies={companies} products={products} refresh={refreshAll} />}
        {activeMenu === "purchaseProduct" && <PurchaseProduct userId={userId} products={products} suppliers={suppliers} categories={categories} companies={companies} refresh={refreshAll} />}
        {activeMenu === "purchaseHistory" && <PurchaseHistory purchases={purchases} products={products} suppliers={suppliers} refresh={refreshAll} />}
        {activeMenu === "addSupplier" && <AddSupplier userId={userId} suppliers={suppliers} refresh={refreshAll} />}
        {activeMenu === "supplierPayment" && <SupplierPayment userId={userId} suppliers={suppliers} purchases={purchases} cashTx={cashTx} refresh={refreshAll} />}
        {activeMenu === "addCost" && <ExpenseManager userId={userId} costs={costs} sales={sales} refresh={refreshAll} />}
        {activeMenu === "costReport" && <CostReport costs={costs} sales={sales} />}
        {activeMenu === "cashInOut" && <CashInOut userId={userId} cashTx={cashTx} refresh={refreshAll} />}
        {activeMenu === "profit" && <DailyAccount sales={sales} purchases={purchases} costs={costs} cashTx={cashTx} products={products} />}
        {activeMenu === "dailySummary" && <DailySummary sales={sales} purchases={purchases} costs={costs} cashTx={cashTx} customers={customers} suppliers={suppliers} refresh={refreshAll} />}
      </main>
    </div>
  );
}

// ----- SaleForm (Professional Tiles Invoice) -----
const SHOP = {
  name: "আলম টাইলস",
  nameEn: "Alam Tiles",
  address: "বড় কালিবাড়ি, টাংগাইল",
  addressEn: "Boro Kalibari, Tangail",
  mobile: "01757-777096, 01621-176784",
};
const SALE_DRAFT_KEY = "saleDraft_v2";

type SaleRow = { productId: string; cartons: number; extraPcs: number; price: number };

function SaleForm({ userId, products, customers, sales, refresh, onNavigate, editSaleId, clearEditSale }: { userId: string; products: Product[]; customers: Customer[]; sales: Sale[]; refresh: () => void; onNavigate?: (m: string) => void; editSaleId?: string | null; clearEditSale?: () => void }) {
  const [anonymous, setAnonymous] = useState(false);
  const [customerId, setCustomerId] = useState("");
  const [anonName, setAnonName] = useState("Walk-in Customer");
  const [anonMobile, setAnonMobile] = useState("");
  const [anonAddress, setAnonAddress] = useState("");
  const [mobileSearch, setMobileSearch] = useState("");
  const [walkInSeq, setWalkInSeq] = useState(0);
  
  const [rows, setRows] = useState<SaleRow[]>(() =>
    Array.from({ length: 7 }, () => ({ productId: "", cartons: 0, extraPcs: 0, price: 0 }))
  );
  const [paid, setPaid] = useState<number | string>("");
  const [labor, setLabor] = useState<number | string>("");
  const [transport, setTransport] = useState<number | string>("");
  const [discountAmt, setDiscountAmt] = useState<number | string>("");
  const [includePrevDue, setIncludePrevDue] = useState(true);
  const [customerType, setCustomerType] = useState<"Regular" | "Dealer" | "Contractor" | "Walk-in">("Regular");
  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [qa, setQa] = useState({ name: "", mobile: "", address: "", due: 0 });
  const [ledgerOpen, setLedgerOpen] = useState(false);
  const [ledgerRows, setLedgerRows] = useState<Sale[]>([]);
  const [ledgerLoading, setLedgerLoading] = useState(false);
  const [customerStats, setCustomerStats] = useState<{ totalPurchase: number; totalPaid: number; invoices: number } | null>(null);
  const [ledgerFilter, setLedgerFilter] = useState<"all" | "today" | "custom" | "range">("all");
  const [ledgerCustomDate, setLedgerCustomDate] = useState<string>("");
  const [ledgerFromDate, setLedgerFromDate] = useState<string>("");
  const [ledgerToDate, setLedgerToDate] = useState<string>("");
  const [ledgerPageSize, setLedgerPageSize] = useState<number>(20);
  const [ledgerPage, setLedgerPage] = useState<number>(1);
  const [ledgerDetailId, setLedgerDetailId] = useState<string | null>(null);

  const editingSale = editSaleId ? sales.find((s) => s.id === editSaleId) || null : null;

  // Load draft (skip when editing an existing sale)
  useEffect(() => {
    if (editSaleId) return;
    try {
      const raw = localStorage.getItem(SALE_DRAFT_KEY);
      if (raw) {
        const d = JSON.parse(raw);
        if (d.rows) setRows(d.rows);
        if (typeof d.paid === "number" || typeof d.paid === "string") setPaid(d.paid);
        if (typeof d.labor === "number" || typeof d.labor === "string") setLabor(d.labor);
        if (typeof d.transport === "number" || typeof d.transport === "string") setTransport(d.transport);
        if (typeof d.discountAmt === "number" || typeof d.discountAmt === "string") setDiscountAmt(d.discountAmt);
        if (d.customerId) setCustomerId(d.customerId);
        if (d.anonymous) {
          setAnonymous(true);
          const next = sales.filter((s) => !s.customer_id).length + 1;
          setWalkInSeq(next);
          setAnonName(`Walk-in Customer ${next}`);
        }
      }
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Prefill from existing sale when editing
  useEffect(() => {
    if (!editingSale) return;
    const prodMap = new Map(products.map((p) => [p.id, p]));
    const prefilled: SaleRow[] = (editingSale.items || []).map((it: any) => {
      const p = prodMap.get(it.productId);
      const ppc = p ? (Number(p.pcs_per_carton) || 1) : 1;
      const cartons = Number(it.cartons) || 0;
      const extraPcs = Math.max(0, (Number(it.pieces) || 0) - cartons * ppc);
      return { productId: it.productId, cartons, extraPcs, price: Number(it.rate) || 0 };
    });
    while (prefilled.length < 7) prefilled.push({ productId: "", cartons: 0, extraPcs: 0, price: 0 });
    setRows(prefilled);
    setPaid(Number(editingSale.paid_amount) || "");
    setLabor((editingSale as any).labor ?? "");
    setTransport((editingSale as any).transport ?? "");
    setDiscountAmt((editingSale as any).discount ?? "");
    if (editingSale.customer_id) {
      setAnonymous(false);
      setCustomerId(editingSale.customer_id);
    } else {
      setAnonymous(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editSaleId]);

  useEffect(() => {
    if (editSaleId) return;
    const t = setTimeout(() => {
      try {
        localStorage.setItem(SALE_DRAFT_KEY, JSON.stringify({ rows, paid, labor, transport, discountAmt, customerId, anonymous }));
      } catch {}
    }, 400);
    return () => clearTimeout(t);
  }, [rows, paid, labor, transport, discountAmt, customerId, anonymous, editSaleId]);

  const selectedCustomer = customers.find((c) => c.id === customerId) || null;
  const prevDue = !anonymous && selectedCustomer
    ? (editingSale
        ? Math.max(0, (Number(editingSale.due_amount) || 0) + (Number(editingSale.paid_amount) || 0) - (Number((editingSale as any).total_amount) || 0))
        : (Number(selectedCustomer.due_amount) || 0))
    : 0;

  // Auto-generated CUST-NNNNN code based on creation order
  const sortedCustomers = [...customers].sort((a, b) => a.id.localeCompare(b.id));
  const customerCode = selectedCustomer
    ? `CUST-${String(sortedCustomers.findIndex((c) => c.id === selectedCustomer.id) + 1).padStart(5, "0")}`
    : "CUST-NEW";

  // Mobile search → auto-select
  useEffect(() => {
    if (!mobileSearch.trim()) return;
    const hit = customers.find((c) => (c.mobile || "").includes(mobileSearch.trim()));
    if (hit) { setAnonymous(false); setCustomerId(hit.id); }
  }, [mobileSearch, customers]);

  // Load purchase stats when customer changes
  useEffect(() => {
    if (!selectedCustomer) { setCustomerStats(null); return; }
    let cancelled = false;
    (async () => {
      const { data } = await supabase.from("sales")
        .select("total_amount, paid_amount").eq("customer_id", selectedCustomer.id);
      if (cancelled) return;
      const rows = (data as { total_amount: number; paid_amount: number }[]) || [];
      setCustomerStats({
        totalPurchase: rows.reduce((s, r) => s + Number(r.total_amount), 0),
        totalPaid: rows.reduce((s, r) => s + Number(r.paid_amount), 0),
        invoices: rows.length,
      });
    })();
    return () => { cancelled = true; };
  }, [selectedCustomer]);

  const quickAddCustomer = async () => {
    if (!qa.name.trim()) return toast.error("Name required / নাম দিন");
    const { data, error } = await supabase.from("customers").insert({
      user_id: userId, name: qa.name.trim(), mobile: qa.mobile.trim() || null,
      address: qa.address.trim() || null, due_amount: Number(qa.due) || 0,
    }).select().single();
    if (error) return toast.error(error.message);
    toast.success("Customer added / কাস্টমার যোগ হয়েছে ✓");
    setQa({ name: "", mobile: "", address: "", due: 0 });
    setQuickAddOpen(false);
    await refresh();
    if (data) { setAnonymous(false); setCustomerId((data as any).id); }
  };

  const openLedger = async () => {
    if (!selectedCustomer) return;
    setLedgerOpen(true); setLedgerLoading(true);
    const { data } = await supabase.from("sales").select("*")
      .eq("customer_id", selectedCustomer.id).order("sale_date", { ascending: false }).limit(50);
    setLedgerRows((data as any) || []); setLedgerLoading(false);
  };

  // Derived calcs per row
  // Sqft Per Piece = (Length × Width) / 144 — parsed from product.size like "8x12", "12×24".
  // Fallback to stored sqft_per_piece if size cannot be parsed.
  const parseSqftFromSize = (size: string | null | undefined): number => {
    if (!size) return 0;
    const m = String(size).match(/(\d+(?:\.\d+)?)\s*[x×*X]\s*(\d+(?:\.\d+)?)/);
    if (!m) return 0;
    const L = parseFloat(m[1]);
    const W = parseFloat(m[2]);
    if (!L || !W) return 0;
    return (L * W) / 144;
  };
  const computed = rows.map((r) => {
    const p = products.find((x) => x.id === r.productId);
    const pcsPerCarton = p ? Number(p.pcs_per_carton) || 1 : 1;
    const sizeSqft = p ? parseSqftFromSize(p.size) : 0;
    const sqftPerPiece = sizeSqft > 0 ? sizeSqft : (p ? Number(p.sqft_per_piece) || 0 : 0);
    const pieces = (Number(r.cartons) || 0) * pcsPerCarton + (Number(r.extraPcs) || 0);
    const feet = pieces * sqftPerPiece;
    const total = feet * (Number(r.price) || 0);
    const profit = p ? total - Number(p.purchase_price_per_piece) * feet : 0;
    const stockFeet = p ? Number(p.stock_pieces) * sqftPerPiece : 0;
    return { p, pieces, feet, total, profit, stockFeet, pcsPerCarton, sqftPerPiece };
  });

  const subtotal = computed.reduce((s, c) => s + c.total, 0);
  const totalFeetAll = computed.reduce((s, c) => s + c.feet, 0);
  const totalCartonsAll = rows.reduce((s, r) => s + (Number(r.cartons) || 0), 0);
  const totalPcsAll = computed.reduce((s, c) => s + c.pieces, 0);
  const laborAmount = totalCartonsAll * (Number(labor) || 0);
  const grandTotal = Math.max(subtotal - (Number(discountAmt) || 0) + laborAmount + (Number(transport) || 0), 0);
  const payableWithPrev = grandTotal + (includePrevDue ? prevDue : 0);
  const dueNow = Math.max(payableWithPrev - (Number(paid) || 0), 0);
  const totalProfit = computed.reduce((s, c) => s + c.profit, 0);

  const updateRow = (i: number, patch: Partial<SaleRow>) => {
    const next = [...rows];
    next[i] = { ...next[i], ...patch };
    if (patch.productId !== undefined) {
      const p = products.find((x) => x.id === patch.productId);
      next[i].price = p ? Number(p.sell_price_per_piece) : 0;
      next[i].cartons = 0;
      next[i].extraPcs = 0;
    }
    setRows(next);
  };
  const addRow = () => setRows([...rows, { productId: "", cartons: 0, extraPcs: 0, price: 0 }]);
  const removeRow = (i: number) => setRows(rows.length > 1 ? rows.filter((_, idx) => idx !== i) : rows);

  const resetForm = () => {
    setRows(Array.from({ length: 7 }, () => ({ productId: "", cartons: 0, extraPcs: 0, price: 0 })));
    setPaid(""); setLabor(""); setTransport(""); setDiscountAmt("");
    setCustomerId(""); setAnonymous(false); setMobileSearch(""); setWalkInSeq(0);
    localStorage.removeItem(SALE_DRAFT_KEY);
    toast.success("Form reset / ফর্ম রিসেট");
  };


  const toBnDigits = (s: string | number) => String(s).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
  const numToBnWords = (num: number): string => {
    num = Math.round(num);
    if (num === 0) return "শূন্য";
    const ones = ["", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়", "দশ", "এগারো", "বারো", "তেরো", "চৌদ্দ", "পনেরো", "ষোলো", "সতেরো", "আঠারো", "ঊনিশ", "বিশ", "একুশ", "বাইশ", "তেইশ", "চব্বিশ", "পঁচিশ", "ছাব্বিশ", "সাতাশ", "আঠাশ", "ঊনত্রিশ", "ত্রিশ", "একত্রিশ", "বত্রিশ", "তেত্রিশ", "চৌত্রিশ", "পঁইত্রিশ", "ছত্রিশ", "সাঁইত্রিশ", "আটত্রিশ", "ঊনচল্লিশ", "চল্লিশ", "একচল্লিশ", "বিয়াল্লিশ", "তেতাল্লিশ", "চুয়াল্লিশ", "পঁইতাল্লিশ", "ছিচল্লিশ", "সাতচল্লিশ", "আটচল্লিশ", "ঊনপঞ্চাশ", "পঞ্চাশ", "একান্ন", "বায়ান্ন", "তিপ্পান্ন", "চুয়ান্ন", "পঞ্চান্ন", "ছাপ্পান্ন", "সাতান্ন", "আটান্ন", "ঊনষাট", "ষাট", "একষট্টি", "বাষট্টি", "তেষট্টি", "চৌষট্টি", "পঁইষট্টি", "ছিষট্টি", "সাতষট্টি", "আটষট্টি", "ঊনসত্তর", "সত্তর", "একাত্তর", "বাহাত্তর", "তিয়াত্তর", "চুয়াত্তর", "পঁচাত্তর", "ছিয়াত্তর", "সাতাত্তর", "আটাত্তর", "ঊনআশি", "আশি", "একাশি", "বিরাশি", "তিরাশি", "চুরাশি", "পঁচাশি", "ছিয়াশি", "সাতাশি", "আটাশি", "ঊননব্বই", "নব্বই", "একানব্বই", "বিরানব্বই", "তিরানব্বই", "চুরানব্বই", "পঁচানব্বই", "ছিয়ানব্বই", "সাতানব্বই", "আটানব্বই", "নিরানব্বই"];
    const below1000 = (n: number): string => {
      if (n < 100) return ones[n];
      const h = Math.floor(n / 100), r = n % 100;
      return ones[h] + "শ" + (r ? " " + ones[r] : "");
    };
    const parts: string[] = [];
    const crore = Math.floor(num / 10000000); num %= 10000000;
    const lakh = Math.floor(num / 100000); num %= 100000;
    const thousand = Math.floor(num / 1000); num %= 1000;
    const rest = num;
    if (crore) parts.push(below1000(crore) + " কোটি");
    if (lakh) parts.push(below1000(lakh) + " লক্ষ");
    if (thousand) parts.push(below1000(thousand) + " হাজার");
    if (rest) parts.push(below1000(rest));
    return parts.join(" ");
  };

  const buildInvoiceHtml = (invoiceNo: string, custName: string, custMobile: string, custAddress: string) => {
    const dateStr = new Date().toLocaleDateString("en-GB");
    const itemRows = computed.filter((c) => c.p);
    const invNum = invoiceNo.replace(/\D/g, "").slice(-4) || invoiceNo;
    const prev = includePrevDue ? prevDue : 0;
    const paidAmt = Number(paid) || 0;
    const hasLabor = (Number(labor) || 0) > 0;
    const hasTransport = (Number(transport) || 0) > 0;
    const hasDiscount = (Number(discountAmt) || 0) > 0;

    const PER_PAGE = 11;
    const chunks: typeof itemRows[] = [];
    for (let i = 0; i < itemRows.length; i += PER_PAGE) chunks.push(itemRows.slice(i, i + PER_PAGE));
    if (chunks.length === 0) chunks.push([]);
    const totalPages = chunks.length;

    const renderRow = (c: typeof itemRows[number], globalIdx: number) => `
      <tr>
        <td class="c">${toBnDigits(globalIdx + 1)}</td>
        <td>${c.p!.name}${c.p!.size ? " " + c.p!.size : ""}</td>
        <td class="c">${toBnDigits(c.feet.toFixed(2))}</td>
        <td class="c">${Number(rows[globalIdx].cartons) ? toBnDigits(Number(rows[globalIdx].cartons)) : ""}</td>
        <td class="c">${Number(rows[globalIdx].extraPcs) ? toBnDigits(Number(rows[globalIdx].extraPcs)) : ""}</td>
        <td class="c">${toBnDigits((Number(rows[globalIdx].price) || 0).toFixed(0))}</td>
        <td class="r">${toBnDigits(c.total.toFixed(0))}</td>
      </tr>`;

    const buildPage = (chunk: typeof itemRows, chunkIdx: number, startIdx: number) => {
      const isLast = chunkIdx === totalPages - 1;
      const rowsHtml = chunk.map((c, i) => renderRow(c, startIdx + i)).join("");
      const extraSummaryRows = 2 + (Math.round(prev) > 0 ? 2 : 0) + (Math.round(dueNow) > 0 ? 1 : 0);
      const summaryRowsCount = (hasLabor ? 1 : 0) + (hasTransport ? 1 : 0) + (hasDiscount ? 1 : 0) + extraSummaryRows;
      const targetRows = isLast ? Math.max(0, PER_PAGE - summaryRowsCount) : PER_PAGE;
      const emptyCount = Math.max(0, targetRows - chunk.length);
      const emptyHtml = Array.from({ length: emptyCount }).map(() =>
        `<tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>`).join("");

      const laborHtml = isLast && hasLabor ? `<tr>
        <td></td><td class="sumlbl">লেবারঃ</td><td></td>
        <td class="c">${toBnDigits(totalCartonsAll)}</td><td></td>
        <td class="c">${toBnDigits(Number(labor) || 0)}</td>
        <td class="r">${toBnDigits(Math.round(laborAmount))}</td>
      </tr>` : "";
      const transportHtml = isLast && hasTransport ? `<tr>
        <td></td><td class="sumlbl">ভাড়াঃ</td><td colspan="4"></td>
        <td class="r">${toBnDigits(Number(transport) || 0)}</td>
      </tr>` : "";
      const discountHtml = isLast && hasDiscount ? `<tr class="shade-row">
        <td colspan="4"></td>
        <td class="sumlbl" colspan="2">ছাড়ঃ</td>
        <td class="sumval">${toBnDigits(Number(discountAmt) || 0)}</td>
      </tr>` : "";
      const summaryHtml = isLast ? `
        <tr class="sum-net">
          <td></td><td class="sumlbl">মোট ফিটঃ</td>
          <td class="c">${toBnDigits(totalFeetAll.toFixed(2))}</td>
          <td></td>
          <td class="sumlbl shade" colspan="2">মোট টাকাঃ</td>
          <td class="sumval shade">${toBnDigits((grandTotal + (Number(discountAmt) || 0)).toFixed(0))}</td>
        </tr>
        ${discountHtml}
        ${Math.round(prev) > 0 ? `<tr class="shade-row">
          <td colspan="4"></td>
          <td class="sumlbl" colspan="2">পূর্বের বাকিঃ</td>
          <td class="sumval">${toBnDigits(prev.toFixed(0))}</td>
        </tr>
        <tr class="sum-gross">
          <td colspan="4"></td>
          <td class="sumlbl" colspan="2">সর্বমোটঃ</td>
          <td class="sumval">${toBnDigits((grandTotal + (Number(discountAmt) || 0) + prev).toFixed(0))}</td>
        </tr>` : ""}
        <tr class="shade-row">
          <td colspan="4" class="katha">কথায়: ${numToBnWords(grandTotal)} টাকা মাত্র</td>
          <td class="sumlbl" colspan="2">জমাঃ</td>
          <td class="sumval">${toBnDigits(paidAmt.toFixed(0))}</td>
        </tr>
        ${Math.round(dueNow) > 0 ? `<tr class="shade-row sum-due">
          <td colspan="4"></td>
          <td class="sumlbl" colspan="2">বাকিঃ</td>
          <td class="sumval">${toBnDigits(dueNow.toFixed(0))}</td>
        </tr>` : ""}` : "";

      const footerHtml = isLast ? `
        <div class="foot-note">সরবরাহের পর কোন প্রকার অভিযোগ গ্রহণযোগ্য নয়</div>
        <div class="sign">
          <div>গ্রাহকের স্বাক্ষর</div>
          <div style="text-align:right"><span class="hasan">Hasan</span><br>পক্ষেঃ আলম টাইলস</div>
        </div>` : "";

      return `<div class="wrap page-break">
        <div class="top">
          <div class="logo">${INVOICE_LOGO_SVG}</div>
          <div class="center">
            <div class="bil">বিল মেমো</div>
            <div class="name">আলম টাইলস</div>
            <div class="en">ALAM TILES</div>
          </div>
          <div class="right">
            <div>মোবাইলঃ</div>
            <div>হাসানঃ 0175-7770796</div>
            <div>0162-1176784</div>
            <div>বড় কালি বাড়ি রোড,</div>
            <div>টাংগাইল।</div>
          </div>
        </div>
        <div class="tag">সকল প্রকার টাইলস, মার্বেল পাথর, সিনারী, বর্ডার সামগ্রী পাইকারী ও খুচরা বিক্রেতা<br>এবং সরবরাহকারক। ডিলারঃ কুংফু সিরামিক্স, তুষার সিরামিক্স।</div>
        <table class="meta">
          <tr>
            <td class="lbl">নামঃ</td><td>${custName || ""}</td>
            <td class="date-lbl">তারিখঃ</td><td class="date-val">${toBnDigits(dateStr)}</td>
          </tr>
          <tr><td class="lbl">মোবাইলঃ</td><td colspan="3">${toBnDigits(custMobile || "")}</td></tr>
          <tr><td class="lbl">ঠিকানাঃ</td><td colspan="3">${custAddress || ""}</td></tr>
        </table>
        <div class="billno">বিল নং ${toBnDigits(invNum)}</div>
        <table class="items" style="table-layout:fixed">
          <colgroup>
            <col style="width:8mm" /><col style="width:45mm" /><col style="width:14mm" /><col style="width:14mm" /><col style="width:10mm" /><col style="width:10mm" /><col style="width:22mm" />
          </colgroup>
          <thead><tr>
            <th>নং</th><th>বিবরণ</th><th>ফুট</th>
            <th>কাটুন</th><th>পিছ</th>
            <th>দর</th><th>মোট টাকা</th>
          </tr></thead>
          <tbody>
            ${rowsHtml}
            ${emptyHtml}
            ${laborHtml}
            ${transportHtml}
            ${summaryHtml}
          </tbody>
        </table>
        ${footerHtml}
        <div class="page">পৃষ্ঠা ${toBnDigits(chunkIdx + 1)} / ${toBnDigits(totalPages)}</div>
      </div>`;
    };

    const pagesHtml = chunks.map((chunk, idx) => buildPage(chunk, idx, idx * PER_PAGE)).join("");

    return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${invoiceNo}</title>
<style>${INVOICE_CSS}</style></head><body>
${pagesHtml}
<script>window.onload=function(){setTimeout(function(){window.print();},300);}</script>
</body></html>`;
  };

  const performSave = async (action: "save" | "print" | "whatsapp") => {
    const items = rows.filter((r) => r.productId);
    if (!items.length) return toast.error("Add at least one product / পণ্য যোগ করুন");
    if (!anonymous && !customerId) return toast.error("Select a customer / কাস্টমার নির্বাচন করুন");

    const finalCustName = anonymous ? anonName.trim() : (selectedCustomer?.name || "").trim();
    if (!finalCustName) return toast.error("কাস্টমারের নাম লিখুন / Customer Name is required");
    const finalCustMobile = anonymous ? anonMobile.trim() : (selectedCustomer?.mobile || "").trim();
    if (!anonymous && !finalCustMobile) return toast.error("কাস্টমারের মোবাইল নম্বর লিখুন / Customer Mobile is required");
    if (labor === "" || labor === undefined || labor === null) return toast.error("লেবারের পরিমাণ লিখুন / Labor is required");

    // Build per-product old pieces map (for stock restoration when editing)
    const oldPiecesByProduct = new Map<string, number>();
    if (editingSale) {
      for (const it of (editingSale.items || []) as any[]) {
        oldPiecesByProduct.set(it.productId, (oldPiecesByProduct.get(it.productId) || 0) + (Number(it.pieces) || 0));
      }
    }

    // Stock check (account for restored stock when editing)
    for (let i = 0; i < rows.length; i++) {
      const c = computed[i];
      if (!c.p) continue;
      if (c.pieces <= 0) return toast.error(`Row ${i + 1}: invalid quantity`);
      const restored = oldPiecesByProduct.get(c.p.id) || 0;
      const available = c.p.stock_pieces + restored;
      if (available < c.pieces) return toast.error(`Insufficient stock: ${c.p.name} (have ${available})`);
    }

    const numericSalesCount = sales.filter((s) => /^\d+$/.test(s.invoice_no)).length;
    const invoiceNo = editingSale ? editingSale.invoice_no : String(2600 + numericSalesCount);
    const custName = anonymous ? (anonName || "Walk-in") : (selectedCustomer?.name || "—");
    const custMobile = anonymous ? anonMobile : (selectedCustomer?.mobile || "");

    const payload = {
      user_id: userId,
      invoice_no: invoiceNo,
      customer_id: anonymous ? null : customerId,
      total_amount: grandTotal,
      paid_amount: Number(paid) || 0,
      due_amount: dueNow,
      items: computed.flatMap((c, i) => {
        if (!c.p) return [];
        const originalItem = editingSale?.items.find(it => it.productId === c.p?.id) as
          (SaleItem & { costPerSqft?: number }) | undefined;
        return [{
          productId: c.p.id, pieces: c.pieces, totalPrice: c.total,
          cartons: Number(rows[i].cartons) || 0, feet: c.feet, rate: Number(rows[i].price) || 0,
          ...(!editingSale || originalItem?.costPerSqft !== undefined ? {
            costPerSqft: originalItem?.costPerSqft ?? Number(c.p.purchase_price_per_piece),
          } : {}),
          costFeet: c.feet,
        }];
      }),
      labor: Number(labor) || 0,
      transport: Number(transport) || 0,
      discount: Number(discountAmt) || 0,
      sale_date: editingSale ? editingSale.sale_date : new Date().toISOString().slice(0, 10),
    };

    if (editingSale) {
      const { error } = await supabase.from("sales").update(payload).eq("id", editingSale.id);
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase.from("sales").insert(payload);
      if (error) return toast.error(error.message);
    }

    // Stock update: new pieces vs old pieces (per product)
    const newPiecesByProduct = new Map<string, number>();
    for (let i = 0; i < rows.length; i++) {
      const c = computed[i]; if (!c.p) continue;
      newPiecesByProduct.set(c.p.id, (newPiecesByProduct.get(c.p.id) || 0) + c.pieces);
    }
    const allProductIds = new Set<string>([...oldPiecesByProduct.keys(), ...newPiecesByProduct.keys()]);
    for (const pid of allProductIds) {
      const prod = products.find((p) => p.id === pid); if (!prod) continue;
      const oldPcs = oldPiecesByProduct.get(pid) || 0;
      const newPcs = newPiecesByProduct.get(pid) || 0;
      const delta = newPcs - oldPcs; // pieces removed from stock
      if (delta === 0) continue;
      await supabase.from("products").update({ stock_pieces: prod.stock_pieces - delta }).eq("id", prod.id);
    }
    // Customer due update (only for registered customers)
    if (!anonymous && selectedCustomer) {
      const dueDelta = editingSale
        ? (dueNow - Number(editingSale.due_amount))
        : (dueNow - (includePrevDue ? prevDue : 0));
      const newDue = Number(selectedCustomer.due_amount) + dueDelta;
      await supabase.from("customers").update({ due_amount: Math.max(newDue, 0) }).eq("id", selectedCustomer.id);
    }
    // Cash in/out (delta when editing)
    const paidNow = Number(paid) || 0;
    const cashDelta = editingSale ? (paidNow - Number(editingSale.paid_amount)) : paidNow;
    if (cashDelta !== 0) {
      await supabase.from("cash_transactions").insert({
        user_id: userId, type: cashDelta > 0 ? "in" : "out", amount: Math.abs(cashDelta),
        reason: editingSale ? `Edit sale ${invoiceNo}` : `Sale ${invoiceNo}`,
        trans_date: new Date().toISOString().slice(0, 10),
      });
    }

    const custAddress = anonymous ? anonAddress : (selectedCustomer?.address || "");
    const html = buildInvoiceHtml(invoiceNo, custName, custMobile, custAddress);

    const openInvoice = () => {
      const w = window.open("", "_blank");
      if (w) { w.document.open(); w.document.write(html); w.document.close(); }
    };

    if (action === "whatsapp") {
      openInvoice();
      const phone = (custMobile || "").replace(/\D/g, "");
      const intl = phone.startsWith("880") ? phone : phone.startsWith("0") ? "88" + phone.slice(1) : phone.length === 10 ? "880" + phone : phone;
      if (!intl) {
        toast.error("কাস্টমারের মোবাইল নম্বর নেই / No customer mobile");
      } else {
        const items = computed.filter((c) => c.p);
        const itemLines = items
          .map((c, i) => {
            const name = c.p!.name.length > 22 ? c.p!.name.slice(0, 22) + "…" : c.p!.name;
            return `${String(i + 1).padStart(2, "0")}. ${name}\n     ${c.pieces} pcs × ৳${(Number(rows[i].price) || 0).toFixed(2)} = ৳${c.total.toFixed(2)}`;
          })
          .join("\n");
        const totalPieces = items.reduce((s, c) => s + c.pieces, 0);
        const customerTotalDue = !anonymous && selectedCustomer
          ? Math.max(0, Number(selectedCustomer.due_amount) + (dueNow - (includePrevDue ? prevDue : 0)))
          : dueNow;
        const text =
`🏪 *${SHOP.nameEn}*
_${SHOP.name}_
📍 ${SHOP.address}
📞 ${SHOP.mobile}
━━━━━━━━━━━━━━━━━━
🧾 *Invoice:* ${invoiceNo}
📅 ${new Date().toLocaleDateString("en-GB")}
👤 ${custName}${custMobile ? `\n📱 ${custMobile}` : ""}
━━━━━━━━━━━━━━━━━━
🛒 *Items (${items.length}, ${totalPieces} pcs):*
${itemLines}
━━━━━━━━━━━━━━━━━━
💰 *Total:*  ৳${grandTotal.toFixed(2)}
✅ *Paid:*   ৳${(Number(paid) || 0).toFixed(2)}
⚠️ *Due:*    ৳${dueNow.toFixed(2)}${customerTotalDue !== dueNow ? `\n📊 *Total Due:* ৳${customerTotalDue.toFixed(2)}` : ""}
━━━━━━━━━━━━━━━━━━
আপনার কেনাকাটার জন্য ধন্যবাদ! 🙏
Thank you for shopping with us!`;
        openWhatsApp(intl, text);
        toast.success("WhatsApp এ পাঠানো হচ্ছে...");
      }
    } else {
      openInvoice();
    }


    toast.success(editingSale ? `Invoice ${invoiceNo} updated ✓` : `Invoice ${invoiceNo} saved ✓`);
    resetForm();
    if (clearEditSale) clearEditSale();
    refresh();
    if (editingSale && onNavigate) onNavigate("saleHistory");
  };

  const numericSalesCount = sales.filter((s) => /^\d+$/.test(s.invoice_no)).length;
  const currentInvoiceNumber = 2600 + numericSalesCount;
  const customerHeaderLabel = anonymous
    ? `Sale to Anonymous Customer${anonName ? " — " + anonName : ""}`
    : selectedCustomer
      ? `Sale — ${selectedCustomer.name}`
      : "Sale to Anonymous Customer";

  return (
    <div className="space-y-4 max-w-[1400px] mx-auto">
      {/* Top bar */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="inline-flex items-center px-4 py-2 rounded-md bg-gray-900 text-white text-sm font-semibold shadow">
          {customerHeaderLabel}
        </span>
        <div className="text-lg md:text-xl font-semibold text-gray-800">
          Current Invoice Number: <span className="text-gray-900">{currentInvoiceNumber}</span>
        </div>
      </div>

      {/* Add Customer / Walk-in toggle row */}
      <div className="flex flex-wrap items-center gap-2">
        <button type="button" onClick={() => setQuickAddOpen(true)}
          className="px-4 py-2 rounded-md bg-blue-500 hover:bg-blue-600 text-white text-sm font-semibold shadow">
          Add Customer
        </button>
        <button type="button" onClick={() => onNavigate?.("addCustomer")}
          className="px-3 py-2 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow">
          Manage Customers
        </button>
        <button type="button" onClick={openLedger} disabled={!selectedCustomer}
          className="px-3 py-2 rounded-md bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold shadow disabled:opacity-40">
          Ledger
        </button>
        <label className="ml-auto flex items-center gap-2 text-xs font-medium text-gray-700 bg-white border border-gray-300 px-3 py-2 rounded-md">
          <input type="checkbox" className="accent-blue-600" checked={anonymous}
            onChange={(e) => {
              setAnonymous(e.target.checked);
              if (e.target.checked) {
                setCustomerId("");
                setCustomerType("Walk-in");
                const next = Math.max(1, sales.filter((s) => !s.customer_id).length + 1);
                setWalkInSeq(next);
                setAnonName(`Walk-in Customer ${next}`);
                setAnonMobile("");
              } else {
                setCustomerType("Regular");
                setWalkInSeq(0);
                setAnonName("Walk-in Customer");
                setAnonMobile("");
              }
            }} />
          Walk-in / Anonymous
        </label>
      </div>

      {/* Invoice Form blue banner */}
      <div className={`${editingSale ? "bg-amber-600" : "bg-[#6b8aa8]"} text-white text-center py-3 rounded-sm flex items-center justify-center gap-4`}>
        <h2 className="text-xl font-semibold tracking-wide">
          {editingSale ? `EDIT INVOICE — ${editingSale.invoice_no}` : "INVOICE FORM"}
        </h2>
        {editingSale && (
          <button type="button"
            onClick={() => { if (clearEditSale) clearEditSale(); resetForm(); if (onNavigate) onNavigate("saleHistory"); }}
            className="px-3 py-1 rounded-md bg-white/20 hover:bg-white/30 text-white text-xs font-semibold">
            Cancel Edit
          </button>
        )}
      </div>

      {/* Customer fields */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Customer Id <span className="text-red-500">*</span>
          </label>
          <input
            readOnly
            value={anonymous ? `WALK-${String(Math.max(1, walkInSeq)).padStart(3, "0")}` : (selectedCustomer ? customerCode : "")}
            placeholder="Enter customer Id"
            className="w-full bg-gray-50 border border-gray-300 rounded-md px-3 py-2 text-sm"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Customer Name <span className="text-red-500">*</span>
          </label>
          {anonymous ? (
            <input
              value={anonName} onChange={(e) => setAnonName(e.target.value)}
              placeholder="Enter customer name"
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-none"
            />
          ) : (
            <SearchSelect
              placeholder="Enter customer name"
              value={customerId}
              onChange={(v) => setCustomerId(v)}
              options={customers.map((c) => ({
                value: c.id,
                label: `${c.name}${c.mobile ? ` (${c.mobile})` : ""}`,
                hint: Number(c.due_amount) > 0 ? `Due ৳${Number(c.due_amount).toFixed(0)}` : "",
              }))}
            />
          )}
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Customer Address <span className="text-red-500">*</span>
          </label>
          <input
            readOnly={!anonymous}
            value={anonymous ? anonAddress : (selectedCustomer?.address || "")}
            onChange={(e) => anonymous && setAnonAddress(e.target.value)}
            placeholder="Enter customer address"
            className={`w-full ${anonymous ? "bg-white" : "bg-gray-50"} border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-none`}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-1">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Customer Mobile {anonymous && <span className="text-gray-400 text-xs">(optional)</span>}
          </label>
          <div className="relative">
            <input
              value={anonymous ? anonMobile : (selectedCustomer?.mobile || mobileSearch)}
              onChange={(e) => anonymous ? setAnonMobile(e.target.value) : setMobileSearch(e.target.value)}
              placeholder="Enter customer mobile"
              className={`w-full ${anonymous ? "bg-white" : "bg-gray-50"} border border-gray-300 rounded-md px-3 py-2 pr-10 text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-none`}
            />
            <button
              type="button"
              onClick={() => {
                const phone = (anonymous ? anonMobile : (selectedCustomer?.mobile || mobileSearch) || "").replace(/\D/g, "");
                const intl = phone.startsWith("880") ? phone : phone.startsWith("0") ? "88" + phone.slice(1) : phone.length === 10 ? "880" + phone : phone;
                if (!intl) {
                  toast.error("কাস্টমারের মোবাইল নম্বর নেই");
                } else {
                  openWhatsApp(intl);
                }
              }}
              className="absolute right-1 top-1/2 -translate-y-1/2 p-1.5 rounded-md bg-emerald-500 hover:bg-emerald-600 text-white"
              title="Open WhatsApp"
            >
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.989 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.134 1.585 5.934L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Add Customer Modal */}
      {quickAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" onClick={() => setQuickAddOpen(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2 text-white">
                <UserPlus className="w-5 h-5" />
                <h3 className="font-bold">Add Customer / নতুন কাস্টমার</h3>
              </div>
              <button onClick={() => setQuickAddOpen(false)} className="text-white/80 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-3">
              <div>
                <label className="text-xs font-semibold text-gray-600">Name / নাম *</label>
                <input autoFocus className="mt-1 w-full px-3 py-2 border rounded-lg outline-none" value={qa.name} onChange={(e) => setQa({ ...qa, name: e.target.value })} />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600">Mobile / মোবাইল</label>
                <input className="mt-1 w-full px-3 py-2 border rounded-lg outline-none" value={qa.mobile} onChange={(e) => setQa({ ...qa, mobile: e.target.value })} />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600">Address / ঠিকানা</label>
                <input className="mt-1 w-full px-3 py-2 border rounded-lg outline-none" value={qa.address} onChange={(e) => setQa({ ...qa, address: e.target.value })} />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600">Opening Due / পূর্বের বকেয়া</label>
                <input type="number" className="mt-1 w-full px-3 py-2 border rounded-lg outline-none" value={qa.due} onChange={(e) => setQa({ ...qa, due: Number(e.target.value) })} />
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={() => setQuickAddOpen(false)} className="flex-1 py-2 rounded-lg border border-gray-300 font-medium text-gray-700 hover:bg-gray-50">Cancel</button>
                <button onClick={quickAddCustomer} className="flex-1 py-2 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold shadow-md hover:shadow-lg">Save</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Ledger Modal */}
      {ledgerOpen && (() => {
        const fmtDate = (d: string) => {
          if (!d) return "";
          const dt = new Date(d);
          if (isNaN(dt.getTime())) return d;
          const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
          return `${String(dt.getDate()).padStart(2,"0")}-${months[dt.getMonth()]}-${dt.getFullYear()}`;
        };
        const todayStr = new Date().toISOString().slice(0,10);
        const filtered = ledgerRows.filter((s) => {
          const d = String(s.sale_date || "").slice(0,10);
          if (ledgerFilter === "today") return d === todayStr;
          if (ledgerFilter === "custom") return ledgerCustomDate ? d === ledgerCustomDate : true;
          if (ledgerFilter === "range") {
            if (ledgerFromDate && d < ledgerFromDate) return false;
            if (ledgerToDate && d > ledgerToDate) return false;
            return true;
          }
          return true;
        });
        const totalPages = Math.max(1, Math.ceil(filtered.length / ledgerPageSize));
        const currentPage = Math.min(ledgerPage, totalPages);
        const pageRows = filtered.slice((currentPage - 1) * ledgerPageSize, currentPage * ledgerPageSize);
        const custCode = selectedCustomer ? `CUST${String(sortedCustomers.findIndex((c) => c.id === selectedCustomer.id) + 1).padStart(6, "0")}` : "";
        return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" onClick={() => setLedgerOpen(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="bg-gradient-to-r from-amber-500 to-orange-600 px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2 text-white">
                <BookOpen className="w-5 h-5" />
                <div>
                  <h3 className="font-bold">Customer Ledger</h3>
                  <p className="text-xs opacity-90">{selectedCustomer?.name} • Due ৳{Math.round(prevDue)}</p>
                </div>
              </div>
              <button onClick={() => setLedgerOpen(false)} className="text-white/80 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 overflow-auto">
              {/* Filter tabs */}
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <button onClick={() => { setLedgerFilter("all"); setLedgerPage(1); }}
                  className={`px-4 py-1.5 rounded-md text-sm font-medium ${ledgerFilter === "all" ? "bg-indigo-500 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}>All</button>
                <button onClick={() => { setLedgerFilter("today"); setLedgerPage(1); }}
                  className={`px-4 py-1.5 rounded-md text-sm font-medium ${ledgerFilter === "today" ? "bg-indigo-500 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}>Today</button>
                <button onClick={() => { setLedgerFilter("custom"); setLedgerPage(1); }}
                  className={`px-4 py-1.5 rounded-md text-sm font-medium ${ledgerFilter === "custom" ? "bg-indigo-500 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}>Custom Date</button>
                <button onClick={() => { setLedgerFilter("range"); setLedgerPage(1); }}
                  className={`px-4 py-1.5 rounded-md text-sm font-medium ${ledgerFilter === "range" ? "bg-indigo-500 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}>Date Range</button>
                {ledgerFilter === "custom" && (
                  <input type="date" value={ledgerCustomDate} onChange={(e) => { setLedgerCustomDate(e.target.value); setLedgerPage(1); }}
                    className="border rounded px-2 py-1 text-sm" />
                )}
                {ledgerFilter === "range" && (
                  <>
                    <input type="date" value={ledgerFromDate} onChange={(e) => { setLedgerFromDate(e.target.value); setLedgerPage(1); }} className="border rounded px-2 py-1 text-sm" />
                    <span className="text-sm text-gray-500">to</span>
                    <input type="date" value={ledgerToDate} onChange={(e) => { setLedgerToDate(e.target.value); setLedgerPage(1); }} className="border rounded px-2 py-1 text-sm" />
                  </>
                )}
              </div>
              {/* Show entries */}
              <div className="flex items-center gap-2 mb-3 text-sm text-gray-700">
                <span>Show:</span>
                <select value={ledgerPageSize} onChange={(e) => { setLedgerPageSize(Number(e.target.value)); setLedgerPage(1); }}
                  className="border rounded px-2 py-1">
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
                <span>entries</span>
              </div>

              {ledgerLoading ? (
                <div className="text-center py-8 text-gray-500">Loading...</div>
              ) : filtered.length === 0 ? (
                <div className="text-center py-8 text-gray-500">No transactions</div>
              ) : (
                <>
                <div className="overflow-x-auto border rounded-md">
                  <table className="w-full text-sm">
                    <thead className="bg-[#e8eef5] text-gray-800">
                      <tr>
                        <th className="p-2 text-left font-bold">Invoice</th>
                        <th className="p-2 text-left font-bold">Date</th>
                        <th className="p-2 text-left font-bold">Customer Id</th>
                        <th className="p-2 text-left font-bold">Customer Info</th>
                        <th className="p-2 text-center font-bold">Mobile</th>
                        <th className="p-2 text-right font-bold">Total Due</th>
                        <th className="p-2 text-right font-bold">Paid</th>
                        <th className="p-2 text-right font-bold">Due</th>
                        <th className="p-2 text-center font-bold">Details</th>
                        <th className="p-2 text-center font-bold">Return</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pageRows.map((s) => (
                        <tr key={s.id} className="border-t hover:bg-amber-50">
                          <td className="p-2">{s.invoice_no}</td>
                          <td className="p-2">{fmtDate(String(s.sale_date))}</td>
                          <td className="p-2">{custCode}</td>
                          <td className="p-2 text-blue-700">{selectedCustomer?.name}</td>
                          <td className="p-2 text-center">{selectedCustomer?.mobile || 0}</td>
                          <td className="p-2 text-right">{Math.round(Number(s.total_amount))}</td>
                          <td className="p-2 text-right">{Math.round(Number(s.paid_amount))}</td>
                          <td className="p-2 text-right">{Math.round(Number(s.due_amount))}</td>
                          <td className="p-2 text-center">
                            <button onClick={() => {
                              const pm = new Map(products.map((p) => [p.id, p as any]));
                              const html = buildSaleInvoiceHtml(s as any, (selectedCustomer as any) || undefined, pm as any, { preview: true });
                              const w = window.open("", "_blank");
                              if (w) { w.document.open(); w.document.write(html); w.document.close(); }
                            }}
                              className="bg-slate-700 text-white px-3 py-1 rounded text-xs hover:bg-slate-800">Details</button>
                          </td>
                          <td className="p-2 text-center">
                            <button onClick={() => toast.info("Return Sale — open from Sales History")}
                              className="bg-slate-700 text-white px-3 py-1 rounded text-xs hover:bg-slate-800">Return Sale</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {ledgerDetailId && (() => {
                  const s = filtered.find((x) => x.id === ledgerDetailId);
                  if (!s) return null;
                  return (
                    <div className="mt-3 p-3 border rounded bg-gray-50 text-sm">
                      <div className="font-semibold mb-1">Invoice #{s.invoice_no}</div>
                      <div>Date: {fmtDate(String(s.sale_date))}</div>
                      <div>Total: ৳{Math.round(Number(s.total_amount))} • Paid: ৳{Math.round(Number(s.paid_amount))} • Due: ৳{Math.round(Number(s.due_amount))}</div>
                    </div>
                  );
                })()}
                {/* Pagination */}
                <div className="flex items-center justify-end gap-3 mt-4 text-sm">
                  <button onClick={() => setLedgerPage(Math.max(1, currentPage - 1))} disabled={currentPage === 1}
                    className="px-2 py-1 border rounded disabled:opacity-40">«</button>
                  <span>Page {currentPage} of {totalPages}</span>
                  <button onClick={() => setLedgerPage(Math.min(totalPages, currentPage + 1))} disabled={currentPage === totalPages}
                    className="px-2 py-1 border rounded disabled:opacity-40">»</button>
                  <span className="ml-3">Jump to:</span>
                  <input type="number" min={1} max={totalPages} value={currentPage}
                    onChange={(e) => setLedgerPage(Math.max(1, Math.min(totalPages, Number(e.target.value) || 1)))}
                    className="border rounded w-16 px-2 py-1" />
                </div>
                </>
              )}
            </div>
          </div>
        </div>
        );
      })()}

      {/* Products table */}
      <div className="overflow-x-auto bg-white rounded-md border border-gray-300">
        <table className="w-full text-sm border-collapse [&_th]:border [&_th]:border-gray-300 [&_td]:border [&_td]:border-gray-300">
          <thead className="bg-[#c7d5e0] text-gray-800">
            <tr>
              <th className="p-2 text-center w-10">SI</th>
              <th className="p-2 min-w-[220px] text-center">Product Name</th>
              <th className="p-2 text-center">Stock Q / Feet</th>
              <th className="p-2 text-center">Purchase Price</th>
              <th className="p-2 text-center">Caton</th>
              <th className="p-2 text-center">Pcs</th>
              <th className="p-2 text-center">Sell Q / Feet</th>
              <th className="p-2 text-center">Sell Price</th>
              <th className="p-2 text-center">Total</th>
              <th className="p-2 text-center w-20">Remove</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => {
              const c = computed[i];
              const lowStock = c.p && c.p.stock_pieces < c.pieces;
              return (
                <tr key={i} className={`${lowStock ? "bg-red-50" : "hover:bg-blue-50/30"}`}>
                  <td className="p-2 font-bold text-center">{i + 1}</td>
                  <td className="p-1">
                    <SearchSelect
                      placeholder="Search product..."
                      value={r.productId}
                      onChange={(v) => updateRow(i, { productId: v })}
                      options={products.map((p) => ({
                        value: p.id,
                        label: `${p.name}${p.size ? ` ${p.size}` : ""}${p.company ? ` • ${p.company}` : ""}`,
                        hint: `stk ${p.stock_pieces}`,
                      }))}
                    />
                  </td>
                  <td className="p-2 text-right">{r.productId ? c.stockFeet.toFixed(2) : ""}</td>
                  <td className="p-2 text-right">{r.productId && c.p ? Number(c.p.purchase_price_per_piece).toFixed(2) : ""}</td>
                  <td className="p-1 text-center">{r.productId ? (
                    <input type="number" min={0} className="border rounded p-1 w-16 text-center" value={r.cartons || ""}
                      onChange={(e) => updateRow(i, { cartons: parseInt(e.target.value) || 0 })} />
                  ) : null}</td>
                  <td className="p-1 text-center">{r.productId ? (
                    <input type="number" min={0} className="border rounded p-1 w-16 text-center" value={r.extraPcs || ""}
                      onChange={(e) => updateRow(i, { extraPcs: parseInt(e.target.value) || 0 })} />
                  ) : null}</td>
                  <td className="p-2 text-right font-semibold text-blue-700">{r.productId ? c.feet.toFixed(2) : ""}</td>
                  <td className="p-1 text-center">{r.productId ? (
                    <input type="number" min={0} step="0.01" className="border rounded p-1 w-20 text-center" value={r.price || ""}
                      onChange={(e) => updateRow(i, { price: parseFloat(e.target.value) || 0 })} />
                  ) : null}</td>
                  <td className="p-2 text-right font-bold">{r.productId ? `৳${Math.round(c.total)}` : ""}</td>
                  <td className="p-1 text-center">
                    <button onClick={() => removeRow(i)} className="bg-red-500 hover:bg-red-600 text-white text-xs px-3 py-1 rounded">Remove</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Totals rows — match the screenshot layout */}
      <div className="bg-white border border-gray-200 rounded-md p-4 space-y-3 text-sm">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-x-6 gap-y-2">
          <div className="text-center"><span className="font-semibold">Total Carton:</span> {totalCartonsAll}</div>
          <div className="text-center"><span className="font-semibold">Total Feet:</span> {totalFeetAll.toFixed(2)}</div>
          <div className="text-center flex items-center justify-center gap-2">
            <span className="font-semibold">Labor:</span>
            <input type="number" min={0} className="w-20 border rounded p-1 text-center" value={labor === 0 || labor === "0" ? "" : labor}
              onChange={(e) => setLabor(e.target.value === "" ? "" : parseFloat(e.target.value))} />
          </div>
          <div className="text-center"><span className="font-semibold">Amount:</span> {Math.round(laborAmount)}</div>
          <div className="text-center"><span className="font-semibold">Total:</span> {Math.round(subtotal + laborAmount)}</div>
          <div className="text-center flex items-center justify-center gap-2">
            <span className="font-semibold">Transport Cost:</span>
            <input type="number" min={0} className="w-20 border rounded p-1 text-center" value={transport === 0 || transport === "0" ? "" : transport}
              onChange={(e) => setTransport(e.target.value === "" ? "" : parseFloat(e.target.value))} />
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-7 gap-x-4 gap-y-2 items-center pt-2 border-t border-gray-200">
          <div><span className="font-semibold">Subtotal:</span> <span className="text-red-600 font-semibold">{Math.round(subtotal)}</span></div>
          <div className="flex items-center gap-2">
            <span className="font-semibold">Discount:</span>
            <input type="number" min={0} className="w-20 border rounded p-1 text-center" value={discountAmt === 0 || discountAmt === "0" ? "" : discountAmt}
              onChange={(e) => setDiscountAmt(e.target.value === "" ? "" : parseFloat(e.target.value))} />
          </div>
          <div><span className="font-semibold">Grand Total:</span> {Math.round(grandTotal)}</div>
          <div><span className="font-semibold">Previous Due:</span> {Math.round(prevDue)}</div>
          <div><span className="font-semibold">Total Due:</span> {Math.round(payableWithPrev)}</div>
          <div className="flex items-center gap-2">
            <span className="font-semibold">Paid:</span>
            <input type="number" min={0} className="w-24 border rounded p-1 text-center" value={paid === 0 || paid === "0" ? "" : paid}
              onChange={(e) => setPaid(e.target.value === "" ? "" : parseFloat(e.target.value))} />
          </div>
          <div><span className="font-semibold">Due:</span> <span className="text-red-600 font-bold">{Math.round(dueNow)}</span></div>
        </div>

        {!anonymous && selectedCustomer && (
          <label className="flex items-center gap-2 text-xs text-gray-700 pt-2 border-t border-gray-200">
            <input type="checkbox" checked={includePrevDue} onChange={(e) => setIncludePrevDue(e.target.checked)} />
            Add previous due (৳{Math.round(prevDue)}) to payable
          </label>
        )}
      </div>

      {/* Action buttons (left column like screenshot) */}
      <div className="flex flex-col items-start gap-2 max-w-[200px]">
        <button onClick={addRow}
          className="w-full px-4 py-2 rounded-md bg-[#6b8aa8] hover:bg-[#5a7a98] text-white text-sm font-semibold shadow">
          Add Product
        </button>
        <button onClick={() => performSave("save")}
          className="w-full px-4 py-2 rounded-md bg-[#3b5a80] hover:bg-[#2f4a6c] text-white text-sm font-semibold shadow">
          Submit
        </button>
        <button onClick={resetForm}
          className="w-full px-4 py-2 rounded-md bg-[#3b5a80] hover:bg-[#2f4a6c] text-white text-sm font-semibold shadow">
          Clear
        </button>
        <div className="flex gap-2 mt-1 flex-wrap">
          <button onClick={() => {
            const items = rows.filter((r) => r.productId);
            if (!items.length) return toast.error("Add at least one product / পণ্য যোগ করুন");
            const invoiceNo = String(currentInvoiceNumber);
            const custName = anonymous ? (anonName || "Walk-in") : (selectedCustomer?.name || "—");
            const custMobile = anonymous ? anonMobile : (selectedCustomer?.mobile || "");
            const custAddress = anonymous ? anonAddress : (selectedCustomer?.address || "");
            const html = buildInvoiceHtml(invoiceNo, custName, custMobile, custAddress)
              .replace(/<script>[\s\S]*?<\/script>/g, "");
            const w = window.open("", "_blank");
            if (w) { w.document.open(); w.document.write(html); w.document.close(); }
          }}

            className="px-3 py-1.5 rounded-md bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold">
            👁 Preview
          </button>
          <button onClick={() => performSave("print")}
            className="px-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold">
            🖨 Print
          </button>
          <button onClick={() => performSave("whatsapp")}
            className="px-3 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold">
            📱 WhatsApp
          </button>
        </div>

      </div>
    </div>
  );
}



// SaleHistory moved to src/components/SaleHistory.tsx
// ReturnHistory moved to src/components/ReturnHistory.tsx


function MyStock({ userId, products: sourceProducts, categories, companies: allCompanies, purchases, sales, stockCuts, suppliers, refresh }: { userId: string; products: Product[]; categories: Category[]; companies: Company[]; purchases: Purchase[]; sales: Sale[]; stockCuts: StockCut[]; suppliers: Supplier[]; refresh: () => void }) {
  const [overrides, setOverrides] = useState<Record<string, StockPatch>>({});
  useEffect(() => {
    setOverrides((current) => {
      const next = { ...current };
      for (const p of sourceProducts) {
        const patch = next[p.id];
        if (patch && Object.entries(patch).every(([key, value]) => p[key as keyof Product] === value)) delete next[p.id];
      }
      return next;
    });
  }, [sourceProducts]);
  const products = sourceProducts.map((p) => ({ ...p, ...overrides[p.id] }));
  const latestProducts = useRef(products);
  latestProducts.current = products;
  const saveQueue = useRef<Promise<void>>(Promise.resolve());
  const [search, setSearch] = useState("");
  const [coFilter, setCoFilter] = useState("all");
  const [storeType, setStoreType] = useState<"in" | "out" | "all">("in");
  const [editing, setEditing] = useState<Record<string, number>>({});
  const [savingId, setSavingId] = useState<string | null>(null);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [historyRow, setHistoryRow] = useState<{ p: Product; list: Product[] } | null>(null);

  const companiesList = Array.from(new Set(products.map((p) => p.company).filter(Boolean))) as string[];

  // Group products by name (same product name merged into one row)
  const groups = new Map<string, Product[]>();
  for (const p of products) {
    const key = (p.name || "").trim().toLowerCase();
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)?.push(p);
  }

  const rows = Array.from(groups.values())
    .map((list) => {
      const p = list[0];
      const perCarton = Number(p.pcs_per_carton) || 1;
      const sqftPer = Number(p.sqft_per_piece) || 0;
      const stockPcs = list.reduce((s, x) => s + (Number(x.stock_pieces) || 0), 0);
      const cartons = Math.floor(stockPcs / perCarton);
      const looseP = stockPcs - cartons * perCarton;
      const totalFeet = stockPcs * sqftPer;
      const purchase = Math.max(0, ...list.map((x) => Number(x.purchase_price_per_piece) || 0));
      const totalPrice = totalFeet * purchase;
      const minFeet = Number(p.min_label_feet ?? 0);
      const isLow = minFeet > 0 && totalFeet > 0 && totalFeet < minFeet;
      const isFalse = purchase <= 0 || stockPcs < 0;
      return { p, list, perCarton, sqftPer, stockPcs, cartons, looseP, totalFeet, purchase, totalPrice, minFeet, isLow, isFalse };
    })
    .sort((a, b) => {
      const c = (a.p.company || "").localeCompare(b.p.company || "");
      return c !== 0 ? c : (a.p.name || "").localeCompare(b.p.name || "");
    });

  const filtered = rows.filter(({ p, stockPcs }) => {
    const q = search.trim().toLowerCase();
    if (q && !p.name.toLowerCase().includes(q)) return false;
    if (coFilter !== "all" && p.company !== coFilter) return false;
    if (storeType === "in" && stockPcs <= 0) return false;
    if (storeType === "out" && stockPcs > 0) return false;
    return true;
  });

  const saveMinFeet = async (row: { p: Product; list: Product[] }) => {
    const id = row.p.id;
    const val = editing[id];
    if (val === undefined) return;
    setSavingId(id);
    const ids = row.list.map((x) => x.id);
    const { error } = await supabase.from("products").update({ min_label_feet: val }).in("id", ids);
    setSavingId(null);
    if (error) return toast.error(error.message);
    toast.success("Saved");
    setEditing((e) => { const n = { ...e }; delete n[id]; return n; });
    row.list.forEach((x) => { (x as Product).min_label_feet = val; });
  };

  const saveStockCell = (ids: string[], field: StockField, value: string) => {
    const task = saveQueue.current.catch(() => {}).then(async () => {
      const list = latestProducts.current.filter((p) => ids.includes(p.id));
      const update = stockEditPatch(list, field, value);
      const { data, error } = await supabase.from("products").update(update.patch)
        .in("id", update.ids).select("id");
      if (error) throw new Error(error.message);
      if (data?.length !== update.ids.length) throw new Error("পণ্য সেভ হয়নি; আবার চেষ্টা করুন");
      latestProducts.current = latestProducts.current.map((p) => update.ids.includes(p.id) ? { ...p, ...update.patch } : p);
      setOverrides((current) => {
        const next = { ...current };
        for (const id of update.ids) next[id] = { ...next[id], ...update.patch };
        return next;
      });
      refresh();
    });
    saveQueue.current = task;
    return task;
  };

  const printReport = () => {
    const storeLabel = storeType === "in" ? "In Stock Product" : storeType === "out" ? "Out of Stock Product" : "All Product";
    const rowsHtml = filtered.map((r, i) => {
      const bg = r.isFalse ? "background:#fecaca;" : r.isLow ? "background:#fef08a;" : "";
      return `<tr style="${bg}">
        <td style="text-align:center">${i + 1}</td>
        <td style="text-align:left">${r.p.name ?? ""}</td>
        <td style="text-align:left">${r.p.company ?? "—"}</td>
        <td style="text-align:right">${r.totalFeet.toFixed(2)}</td>
        <td style="text-align:center">${r.cartons}</td>
        <td style="text-align:center">${r.looseP}</td>
        <td style="text-align:right">${r.purchase.toFixed(2)}</td>
        <td style="text-align:right">${r.totalPrice.toFixed(2)}</td>
      </tr>`;
    }).join("");
    const totalSum = filtered.reduce((s, r) => s + r.totalPrice, 0);
    const html = `<!doctype html><html><head><meta charset="utf-8"/><title>Store Print</title>
      <style>
        @page { size: A4 portrait; margin: 7mm; }
        * { box-sizing: border-box; }
        body { font-family: 'Noto Sans Bengali', Arial, sans-serif; color:#111; margin:0; padding:0; }
        .shop { text-align:center; }
        .shop h1 { margin:0; font-size:18px; line-height:22px; font-weight:700; }
        .shop .addr { font-size:11px; line-height:14px; }
        .shop .title { font-size:12px; line-height:15px; margin-top:2px; font-weight:600; }
        .shop .sub { font-size:10px; line-height:12px; color:#444; margin-bottom:4px; }
        table { width:100%; table-layout:fixed; border-collapse:collapse; font-size:10px; line-height:16px; }
        th, td { border:1px solid #555; padding:1px 3px; overflow-wrap:anywhere; vertical-align:middle; }
        td:nth-child(n+4) { white-space:nowrap; }
        tr { break-inside:avoid; page-break-inside:avoid; }
        thead { display:table-header-group; }
        thead th { background:#f3f4f6; text-align:center; font-weight:600; }
        .grand-total td { font-weight:bold; background:#f9fafb; }
        @media screen { body { max-width:196mm; margin:7mm auto; } }
      </style></head><body>
      <div class="shop">
        <h1>আলম টাইলস</h1>
        <div class="addr">কালি বাড়ি রোড, টাঙ্গাইল</div>
        <div class="title">Store Print</div>
        <div class="sub">storeItemType: ${storeLabel}</div>
      </div>
      <table>
        <colgroup><col style="width:5%"/><col style="width:24%"/><col style="width:17%"/><col style="width:11%"/><col style="width:7%"/><col style="width:5%"/><col style="width:15%"/><col style="width:16%"/></colgroup>
        <thead><tr>
          <th>SI</th><th>Product Name</th><th>Company Name</th><th>Quantity</th><th>Carton</th><th>Pcs</th><th>Last Purchase Price</th><th>Total</th>
        </tr></thead>
        <tbody>${rowsHtml}
        <tr class="grand-total">
          <td colspan="7" style="text-align:right">Grand Total</td>
          <td style="text-align:right">${totalSum.toFixed(2)}</td>
        </tr></tbody>
      </table>
      <script>window.onload=function(){setTimeout(function(){window.print();},300);}</script>
      </body></html>`;
    const w = window.open("", "_blank");
    if (!w) return toast.error("Popup blocked");
    w.document.write(html);
    w.document.close();
  };

  const cell = "border border-gray-300 px-3 py-2 text-sm";
  const head = "border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 bg-gray-50 text-left";

  return (
    <div className="space-y-4 max-w-[1400px] mx-auto">
      <h1 className="text-center text-2xl font-semibold text-gray-700 mt-2">My Stock List</h1>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-6 text-sm text-gray-700 px-1">
        <div className="flex items-center gap-2">
          <span className="inline-block w-4 h-4 rounded-sm bg-red-400 border border-red-500" />
          <span>লাল কালার: মিথ্যা পার্সেজ করা হয়েছে</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-block w-4 h-4 rounded-sm bg-yellow-300 border border-yellow-400" />
          <span>হলুদ কালার: সর্বনিম্ন লেবেল থেকে কম আছে</span>
        </div>
      </div>

      {/* Print */}
      <div className="flex items-center gap-3 print:hidden">
        <button onClick={printReport} className="text-blue-600 hover:underline text-sm">Print</button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 print:hidden">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by product name"
          className="flex-1 min-w-[240px] px-4 py-2 rounded-lg border border-gray-300 bg-white text-sm placeholder-gray-400 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-none"
        />
        <div className="flex items-center gap-2">
          <label className="text-sm text-gray-600">Company:</label>
          <select value={coFilter} onChange={(e) => setCoFilter(e.target.value)}
            className="px-3 py-2 rounded-lg border border-gray-300 bg-white text-sm">
            <option value="all">All Companies</option>
            {companiesList.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-sm text-gray-600">Store Type:</label>
          <select value={storeType} onChange={(e) => setStoreType(e.target.value as "in" | "out" | "all")}
            className="px-3 py-2 rounded-lg border border-gray-300 bg-white text-sm">
            <option value="in">In Stock</option>
            <option value="out">Out of Stock</option>
            <option value="all">All</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto bg-white rounded-lg">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className={head}>Sl</th>
              <th className="w-[60px] min-w-[60px] border border-border px-1 py-2 text-sm font-semibold text-foreground bg-muted text-center">Photo</th>
              <th className={head}>Product Name</th>
              <th className={head}>Company Name</th>
              <th className={head}>Feet</th>
              <th className={head}>Caton</th>
              <th className={head}>Pcs</th>
              <th className={head}>Last Purchase Price</th>
              <th className={head}>Total Price</th>
              <th className={head}>Min Label (Feet)</th>
              <th className={head}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={11} className="border border-gray-300 p-6 text-center text-gray-400">No products</td></tr>
            )}
            {filtered.map((r, i) => {
              const rowBg = r.isFalse ? "bg-red-100" : r.isLow ? "bg-yellow-100" : "";
              const editable = (field: StockField, label: string, value: string, numeric = false, integer = false) => (
                <StockEditableCell label={`${label}: ${r.p.name}`} value={value} numeric={numeric} integer={integer}
                  onSave={(next) => saveStockCell(r.list.map((p) => p.id), field, next)} />
              );
              return (
                <tr key={r.p.id} className={rowBg}>
                  <td className={cell}>{i + 1}</td>
                  <td className="relative h-[60px] w-[60px] min-w-[60px] border border-border p-0">
                    <StockImageCell name={r.p.name} productIds={r.list.map((p) => p.id)}
                      imagePath={r.list.find((p) => p.image_path)?.image_path ?? null} userId={userId} onSaved={refresh} />
                  </td>
                  <td className={cell}>
                    <ProductNameCell name={r.p.name} label={`Product Name: ${r.p.name}`}
                      onSave={(next) => saveStockCell(r.list.map((p) => p.id), "name", next)}
                      onHistory={() => setHistoryRow({ p: r.p, list: r.list })} />
                  </td>
                  <td className={cell}>{editable("company", "Company Name", r.p.company ?? "")}</td>
                  <td className={cell}>{editable("feet", "Feet", r.totalFeet.toFixed(2), true)}</td>
                  <td className={cell}>{editable("cartons", "Caton", String(r.cartons), true, true)}</td>
                  <td className={cell}>{editable("pcs", "Pcs", String(r.looseP), true, true)}</td>
                  <td className={cell}>{editable("purchase", "Last Purchase Price", String(r.purchase), true)}</td>
                  <td className={cell}>{r.totalPrice.toFixed(2)}</td>
                  <td className={cell}>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        defaultValue={r.minFeet}
                        onChange={(e) => setEditing((s) => ({ ...s, [r.p.id]: Number(e.target.value) }))}
                        className="w-16 border border-gray-300 rounded px-2 py-0.5 text-sm"
                      />
                      <button
                        disabled={savingId === r.p.id || editing[r.p.id] === undefined || editing[r.p.id] === r.minFeet}
                        onClick={() => saveMinFeet(r)}
                        className="text-blue-600 hover:underline text-sm disabled:text-gray-400 disabled:no-underline"
                      >Update</button>
                    </div>
                  </td>
                  <td className={cell}>
                    <div className="flex items-center justify-center gap-2">
                      <button onClick={() => setEditProduct(r.p)} className="text-blue-600 hover:text-blue-800" title="Edit">
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={async () => {
                          const names = r.list.map((x) => x.name).join(", ");
                          if (!confirm(`Delete ${r.list.length} product(s): "${names}"?`)) return;
                          const ids = r.list.map((x) => x.id);
                          const { error } = await supabase.from("products").delete().in("id", ids);
                          if (error) return toast.error(error.message);
                          toast.success("Deleted");
                          refresh();
                        }}
                        className="text-red-600 hover:text-red-800"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {editProduct && (
        <EditProductModal
          product={editProduct}
          categories={categories}
          companies={allCompanies}
          onClose={() => setEditProduct(null)}
          onSaved={() => { setEditProduct(null); refresh(); }}
        />
      )}
      {historyRow && (
        <ProductHistoryModal
          row={historyRow}
          purchases={purchases}
          sales={sales}
          stockCuts={stockCuts}
          suppliers={suppliers}
          onClose={() => setHistoryRow(null)}
        />
      )}
    </div>
  );
}

// ----- Product Name: নীল লেখা, একবার চাপ = History, দুইবার চাপ = নাম বদলানো -----
function ProductNameCell({ name, label, onSave, onHistory }: {
  name: string; label: string; onSave: (value: string) => Promise<void>; onHistory: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(name);
  const [saving, setSaving] = useState(false);
  const clickTimer = useRef<number | null>(null);
  useEffect(() => { if (!editing) setDraft(name); }, [name, editing]);
  useEffect(() => () => { if (clickTimer.current) window.clearTimeout(clickTimer.current); }, []);

  const openHistory = () => {
    if (clickTimer.current) window.clearTimeout(clickTimer.current);
    clickTimer.current = window.setTimeout(() => { clickTimer.current = null; onHistory(); }, 250);
  };
  const startEdit = () => {
    if (clickTimer.current) { window.clearTimeout(clickTimer.current); clickTimer.current = null; }
    setEditing(true);
  };

  const commit = async () => {
    const next = draft.trim();
    if (!next || next === name) { setEditing(false); return; }
    setSaving(true);
    try {
      await onSave(next);
      setEditing(false);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "সেভ হয়নি, আবার চেষ্টা করুন");
    } finally {
      setSaving(false);
    }
  };

  if (editing) {
    return <input autoFocus aria-label={label} title={label} value={draft} disabled={saving}
      onChange={(event) => setDraft(event.target.value)}
      onBlur={() => { void commit(); }}
      onKeyDown={(event) => {
        if (event.key === "Enter") event.currentTarget.blur();
        if (event.key === "Escape") { setDraft(name); setEditing(false); }
      }}
      className="no-spin w-full min-w-0 rounded-sm border border-ring bg-background py-1 pr-1 text-sm text-foreground outline-none" />;
  }

  return <button type="button" onClick={openHistory} onDoubleClick={startEdit}
    title="একবার চাপ দিলে মালের History, দুইবার চাপ দিলে নাম বদলানো যাবে"
    className="w-full truncate text-left text-sm font-semibold text-blue-600 underline-offset-2 hover:underline">
    {name}
  </button>;
}

// ----- Product History (ক্রয় / বিক্রয় / ড্যামেজ) -----
function ProductHistoryModal({ row, purchases, sales, stockCuts, suppliers, onClose }: {
  row: { p: Product; list: Product[] };
  purchases: Purchase[]; sales: Sale[]; stockCuts: StockCut[]; suppliers: Supplier[];
  onClose: () => void;
}) {
  const ids = new Set(row.list.map((p) => p.id));
  const supplierName = (id: string | null) => suppliers.find((s) => s.id === id)?.name ?? "—";

  const purchaseRows = purchases
    .filter((pu) => pu.product_id && ids.has(pu.product_id))
    .sort((a, b) => (b.purchase_date || "").localeCompare(a.purchase_date || ""));

  const saleRows = sales
    .map((s) => {
      const items = (Array.isArray(s.items) ? s.items : []).filter((it) => it && ids.has(it.productId));
      if (!items.length) return null;
      return { sale: s, pieces: items.reduce((sum, it) => sum + (Number(it.pieces) || 0), 0), amount: items.reduce((sum, it) => sum + (Number(it.totalPrice) || 0), 0) };
    })
    .filter((x): x is NonNullable<typeof x> => x !== null)
    .sort((a, b) => (b.sale.sale_date || "").localeCompare(a.sale.sale_date || ""));

  const cutRows = stockCuts
    .filter((c) => c.product_id && ids.has(c.product_id))
    .sort((a, b) => (b.cut_date || "").localeCompare(a.cut_date || ""));

  const th = "border border-gray-300 px-2 py-1 text-xs font-semibold text-gray-700 bg-gray-50 text-left";
  const td = "border border-gray-300 px-2 py-1 text-xs";

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl p-5 w-full max-w-2xl max-h-[85vh] overflow-y-auto space-y-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold">{row.p.name} — মালের History</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800 text-sm">✕ বন্ধ করুন</button>
        </div>

        <div>
          <h4 className="font-semibold text-sm mb-1">মাল আসা (ক্রয়) — {purchaseRows.length} বার</h4>
          {purchaseRows.length === 0 ? <p className="text-xs text-gray-400">কোনো ক্রয়ের রেকর্ড নেই</p> : (
            <table className="w-full border-collapse">
              <thead><tr><th className={th}>তারিখ</th><th className={th}>সাপ্লায়ার</th><th className={th}>পিস</th><th className={th}>দর</th><th className={th}>মোট</th></tr></thead>
              <tbody>
                {purchaseRows.map((pu) => (
                  <tr key={pu.id}>
                    <td className={td}>{pu.purchase_date}</td>
                    <td className={td}>{supplierName(pu.supplier_id)}</td>
                    <td className={td}>{pu.pieces}</td>
                    <td className={td}>{Number(pu.cost_per_piece).toFixed(2)}</td>
                    <td className={td}>{Number(pu.total_cost).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div>
          <h4 className="font-semibold text-sm mb-1">মাল বিক্রি — {saleRows.length} বার</h4>
          {saleRows.length === 0 ? <p className="text-xs text-gray-400">কোনো বিক্রির রেকর্ড নেই</p> : (
            <table className="w-full border-collapse">
              <thead><tr><th className={th}>তারিখ</th><th className={th}>মেমো নং</th><th className={th}>পিস</th><th className={th}>মোট টাকা</th><th className={th}>অবস্থা</th></tr></thead>
              <tbody>
                {saleRows.map(({ sale, pieces, amount }) => (
                  <tr key={sale.id}>
                    <td className={td}>{sale.sale_date}</td>
                    <td className={td}>{sale.invoice_no}</td>
                    <td className={td}>{pieces}</td>
                    <td className={td}>{amount.toFixed(2)}</td>
                    <td className={td}>{sale.is_returned ? "ফেরত" : "বিক্রি"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div>
          <h4 className="font-semibold text-sm mb-1">ড্যামেজ / কাট — {cutRows.length} বার</h4>
          {cutRows.length === 0 ? <p className="text-xs text-gray-400">কোনো ড্যামেজের রেকর্ড নেই</p> : (
            <table className="w-full border-collapse">
              <thead><tr><th className={th}>তারিখ</th><th className={th}>পিস</th><th className={th}>কারণ</th></tr></thead>
              <tbody>
                {cutRows.map((c) => (
                  <tr key={c.id}>
                    <td className={td}>{c.cut_date}</td>
                    <td className={td}>{c.pieces}</td>
                    <td className={td}>{c.reason ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

// GodownStatus moved to src/components/GodownStatus.tsx

// ----- Customers -----
function AddCustomer({ userId, customers, refresh }: { userId: string; customers: Customer[]; refresh: () => void }) {
  const [name, setName] = useState(""); const [mobile, setMobile] = useState(""); const [address, setAddress] = useState("");
  const add = async () => {
    if (!name.trim()) return toast.error("Name required");
    const { error } = await supabase.from("customers").insert({ user_id: userId, name, mobile, address });
    if (error) return toast.error(error.message);
    toast.success("Customer added");
    setName(""); setMobile(""); setAddress(""); refresh();
  };
  return (
    <div className="bg-white p-5 rounded-2xl shadow-sm space-y-3">
      <h2 className="text-xl font-bold">Add Customer</h2>
      <input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} className="border p-2 w-full rounded" />
      <input placeholder="Mobile" value={mobile} onChange={(e) => setMobile(e.target.value)} className="border p-2 w-full rounded" />
      <textarea placeholder="Address" value={address} onChange={(e) => setAddress(e.target.value)} className="border p-2 w-full rounded" />
      <button onClick={add} className="bg-blue-600 text-white px-4 py-2 rounded">Add Customer</button>
      <hr className="my-4" />
      <h3 className="font-semibold">Customer List</h3>
      <ul className="space-y-1">{customers.map((c) => (
        <li key={c.id} className="flex justify-between border-b py-1"><span>{c.name} — {c.mobile}</span><span className="text-red-600">Due: ৳{Number(c.due_amount).toFixed(2)}</span></li>
      ))}</ul>
    </div>
  );
}

function CustomerReportLegacy({ customers, sales }: { customers: Customer[]; sales: Sale[] }) {
  // overdue = due > 5000 AND oldest unpaid sale > 15 days
  const now = Date.now();
  const FIFTEEN_DAYS = 15 * 24 * 60 * 60 * 1000;
  const overdue = customers.filter((c) => {
    if (Number(c.due_amount) <= 5000) return false;
    const oldestUnpaid = sales
      .filter((s) => s.customer_id === c.id && Number(s.due_amount) > 0)
      .map((s) => new Date(s.sale_date).getTime())
      .sort((a, b) => a - b)[0];
    return oldestUnpaid !== undefined && now - oldestUnpaid > FIFTEEN_DAYS;
  });

  const sendDemoSMS = (c: Customer) => {
    // Demo: simulates triggering an SMS gateway (e.g. Twilio). In production
    // this would call a server function to dispatch the SMS.
    const msg = `Dear ${c.name}, your due balance of BDT ${Number(c.due_amount).toFixed(2)} at Alam Tiles is overdue. Please clear it soon. Thank you.`;
    console.log("[Demo SMS]", { to: c.mobile, message: msg });
    toast.success(`Demo SMS sent to ${c.name} (${c.mobile ?? "no mobile"})`);
  };

  const sendAllDemoSMS = () => {
    if (!overdue.length) return toast.info("No overdue customers");
    overdue.forEach(sendDemoSMS);
  };

  return (
    <div className="space-y-5">
      {/* Overdue automation card */}
      <div className="bg-orange-50 border-l-8 border-orange-500 p-5 rounded-2xl shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <MessageSquare className="w-5 h-5 text-orange-600" />
          <h3 className="font-bold text-lg">Auto SMS — Overdue Customers</h3>
          <span className="ml-auto text-xs text-gray-600">Trigger: due &gt; ৳5000 &amp; unpaid &gt; 15 days</span>
        </div>
        {overdue.length === 0 ? (
          <p className="text-sm text-green-700">No customers meet the overdue criteria. ✓</p>
        ) : (
          <>
            <table className="w-full text-sm mb-3">
              <thead><tr className="border-b text-left text-gray-600">
                <th className="p-2">Name</th><th className="p-2">Mobile</th><th className="p-2">Due ৳</th><th className="p-2">Action</th>
              </tr></thead>
              <tbody>{overdue.map((c) => (
                <tr key={c.id} className="border-b">
                  <td className="p-2 font-medium">{c.name}</td>
                  <td className="p-2">{c.mobile ?? "—"}</td>
                  <td className="p-2 text-red-600 font-bold">{Number(c.due_amount).toFixed(2)}</td>
                  <td className="p-2">
                    <button onClick={() => sendDemoSMS(c)} className="bg-orange-600 text-white px-3 py-1 rounded text-xs hover:bg-orange-700">
                      Send Demo SMS
                    </button>
                  </td>
                </tr>
              ))}</tbody>
            </table>
            <button onClick={sendAllDemoSMS} className="bg-orange-600 text-white px-4 py-2 rounded hover:bg-orange-700 text-sm">
              Send Demo SMS to All ({overdue.length})
            </button>
          </>
        )}
      </div>

      {/* Full customer report */}
      <div className="bg-white p-5 rounded-2xl shadow-sm">
        <h2 className="text-xl font-bold mb-3">Customer Report</h2>
        <table className="w-full text-sm">
          <thead><tr className="border-b text-left"><th className="p-2">Name</th><th className="p-2">Mobile</th><th className="p-2">Due ৳</th></tr></thead>
          <tbody>{customers.map((c) => (
            <tr key={c.id} className="border-b"><td className="p-2">{c.name}</td><td className="p-2">{c.mobile}</td><td className="p-2 text-red-600">{Number(c.due_amount).toFixed(2)}</td></tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}

// ----- Categories -----
function AddCategory({ userId, categories, refresh }: { userId: string; categories: Category[]; refresh: () => void }) {
  const [name, setName] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [query, setQuery] = useState("");

  const add = async () => {
    if (!name.trim()) return;
    const { error } = await supabase.from("categories").insert({ user_id: userId, name });
    if (error) return toast.error(error.message);
    setName("");
    setShowForm(false);
    toast.success("Category যোগ হয়েছে");
    refresh();
  };

  const startEdit = (c: Category) => {
    setEditingId(c.id);
    setEditName(c.name);
  };

  const saveEdit = async () => {
    if (!editingId || !editName.trim()) return;
    const { error } = await supabase.from("categories").update({ name: editName.trim() }).eq("id", editingId);
    if (error) return toast.error(error.message);
    setEditingId(null);
    setEditName("");
    refresh();
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditName("");
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this category? / এই ক্যাটাগরি ডিলিট করবেন?")) return;
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) return toast.error(error.message);
    refresh();
  };

  const filtered = categories.filter((c) => c.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="space-y-4">
      <div>
        <button onClick={() => setShowForm((v) => !v)} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-5 py-2.5 rounded shadow">
          Add Category
        </button>
      </div>

      {showForm && (
        <div className="bg-white p-5 rounded-2xl shadow-sm space-y-3 max-w-2xl">
          <h3 className="font-bold text-lg">New Category</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input placeholder="Category Name" value={name} onChange={(e) => setName(e.target.value)} className="border p-2 rounded" />
          </div>
          <div className="flex gap-2">
            <button onClick={add} className="bg-blue-600 text-white px-4 py-2 rounded">Save</button>
            <button onClick={() => setShowForm(false)} className="bg-gray-200 px-4 py-2 rounded">Cancel</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-center">
        <input placeholder="Search by name" value={query} onChange={(e) => setQuery(e.target.value)} className="border bg-white p-2.5 rounded shadow-sm" />
        <button onClick={() => setQuery("")} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-4 py-2.5 rounded shadow w-fit">Clear Filter</button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 text-gray-700 uppercase text-xs">
              <th className="p-3 text-left w-16">SL</th>
              <th className="p-3 text-left">Category Name</th>
              <th className="p-3 text-center w-32">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={3} className="p-6 text-center text-gray-400">No categories found</td></tr>
            ) : filtered.map((c, i) => (
              <tr key={c.id} className="border-t hover:bg-gray-50">
                <td className="p-3">{i + 1}</td>
                <td className="p-3 font-medium">
                  {editingId === c.id ? (
                    <input value={editName} onChange={(e) => setEditName(e.target.value)} className="border p-1 rounded w-full max-w-xs" />
                  ) : (
                    c.name
                  )}
                </td>
                <td className="p-3 text-center">
                  {editingId === c.id ? (
                    <div className="flex justify-center gap-2">
                      <button onClick={saveEdit} className="bg-green-600 text-white px-2 py-1 rounded text-xs">Save</button>
                      <button onClick={cancelEdit} className="bg-gray-400 text-white px-2 py-1 rounded text-xs">Cancel</button>
                    </div>
                  ) : (
                    <div className="flex justify-center gap-2">
                      <button onClick={() => startEdit(c)} className="text-blue-600 hover:bg-blue-50 p-1 rounded" title="Edit"><Pencil className="w-4 h-4" /></button>
                      <button onClick={() => remove(c.id)} className="text-red-600 hover:bg-red-50 p-1 rounded" title="Delete"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ----- Products (Bulk Excel-style Add) -----
const SIZE_PRESETS: Record<string, number> = {
  "8x12": 0.67, "10x16": 1.11, "12x18": 1.5, "12x24": 2,
  "12x12": 1, "16x16": 1.78, "24x24": 4, "32x32": 7.11,
};
function sqftFromSize(size: string): number {
  const key = size.trim().toLowerCase().replace(/\s|inch|"/g, "");
  if (SIZE_PRESETS[key]) return SIZE_PRESETS[key];
  const m = key.match(/^(\d+(?:\.\d+)?)x(\d+(?:\.\d+)?)$/);
  if (m) return +((parseFloat(m[1]) * parseFloat(m[2])) / 144).toFixed(3);
  return 0;
}

type DraftRow = {
  name: string; category: string; company: string; size: string;
  sqft_per_piece: number; pcs_per_carton: number | "";
};
const emptyRow = (): DraftRow => ({
  name: "", category: "", company: "", size: "",
  sqft_per_piece: 0, pcs_per_carton: "",
});
const DRAFT_KEY = "addProductDraft_v1";

function AddProduct({ userId, categories, companies, products, refresh }: { userId: string; categories: Category[]; companies: Company[]; products: Product[]; refresh: () => void }) {
  const [rows, setRows] = useState<DraftRow[]>([emptyRow()]);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [editProduct, setEditProduct] = useState<Product | null>(null);


  useEffect(() => {
    try {
      const d = localStorage.getItem(DRAFT_KEY);
      if (d) {
        const parsed = JSON.parse(d);
        if (Array.isArray(parsed) && parsed.length) setRows(parsed);
      }
    } catch { /* ignore */ }
  }, []);
  useEffect(() => {
    const t = setTimeout(() => localStorage.setItem(DRAFT_KEY, JSON.stringify(rows)), 400);
    return () => clearTimeout(t);
  }, [rows]);

  const existingNames = new Set(products.map((p) => p.name.trim().toLowerCase()));

  const updateRow = (i: number, patch: Partial<DraftRow>) => {
    setRows((rs) => rs.map((r, idx) => {
      if (idx !== i) return r;
      const next = { ...r, ...patch };
      if (patch.size !== undefined) {
        const auto = sqftFromSize(patch.size);
        if (auto > 0) next.sqft_per_piece = auto;
      }
      return next;
    }));
  };
  const addRow = () => setRows((rs) => [...rs, emptyRow()]);
  const removeRow = (i: number) => setRows((rs) => rs.length > 1 ? rs.filter((_, idx) => idx !== i) : rs);
  const duplicateRow = (i: number) => setRows((rs) => [...rs.slice(0, i + 1), { ...rs[i], name: "" }, ...rs.slice(i + 1)]);

  const validRows = rows.filter((r) => r.name.trim());

  const submitAll = async () => {
    if (!validRows.length) return toast.error("কমপক্ষে একটি প্রোডাক্ট লিখুন / Add at least one product");
    const dups = validRows.filter((r) => existingNames.has(r.name.trim().toLowerCase()));
    if (dups.length) {
      return toast.error(`ইতিমধ্যে আছে: ${dups.map((d) => d.name).join(", ")}`);
    }
    const seen = new Set<string>();
    const rowDups = validRows.filter((r) => {
      const key = r.name.trim().toLowerCase();
      if (seen.has(key)) return true;
      seen.add(key);
      return false;
    });
    if (rowDups.length) {
      return toast.error(`একই ফর্মে ডুপ্লিকেট: ${rowDups.map((d) => d.name).join(", ")}`);
    }
    setSaving(true);
    const payload = validRows.map((r) => ({ user_id: userId, ...r, pcs_per_carton: r.pcs_per_carton === "" ? 0 : Number(r.pcs_per_carton) }));
    const { error } = await supabase.from("products").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(`${validRows.length}টি প্রোডাক্ট সফলভাবে যোগ হয়েছে ✓`);
    localStorage.removeItem(DRAFT_KEY);
    setRows([emptyRow()]);
    refresh();
  };

  const clearAll = () => {
    if (!confirm("সব রো মুছবেন?")) return;
    localStorage.removeItem(DRAFT_KEY);
    setRows([emptyRow()]);
  };

  const [companySearch, setCompanySearch] = useState("");
  const filteredProducts = products.filter((p) => {
    const okName = !search || p.name.toLowerCase().includes(search.toLowerCase());
    const okCo = !companySearch || (p.company || "").toLowerCase().includes(companySearch.toLowerCase());
    return okName && okCo;
  });


  return (
    <div className="space-y-4 pb-4">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-5 rounded-2xl shadow-lg flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold">📦 Bulk Add Product / একসাথে প্রোডাক্ট যোগ</h2>
          <p className="text-sm opacity-90">Excel-style entry • Auto draft save • Size → Sqft auto-calc</p>
        </div>
        <div className="flex gap-2 text-sm">
          <span className="bg-white/20 px-3 py-1 rounded-full">Rows: {rows.length}</span>
          <span className="bg-white/20 px-3 py-1 rounded-full">Valid: {validRows.length}</span>
        </div>
      </div>


      <div className="bg-white p-4 rounded-2xl shadow-sm overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-700">
            <tr>
              <th className="p-2 text-left w-8">#</th>
              <th className="p-2 text-left">Product Name *</th>
              <th className="p-2 text-left">Category</th>
              <th className="p-2 text-left">Company / Brand</th>
              <th className="p-2 text-left">Size</th>
              <th className="p-2 text-right">Sqft/Pc</th>
              <th className="p-2 text-right">Pcs/Carton</th>
              <th className="p-2 w-20"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => {
              const dupName = !!r.name.trim() && existingNames.has(r.name.trim().toLowerCase());
              return (
                <tr key={i} className={`border-b hover:bg-indigo-50/30 ${dupName ? "bg-amber-50" : ""}`}>
                  <td className="p-1 text-center text-gray-400">{i + 1}</td>
                  <td className="p-1">
                    <input value={r.name} onChange={(e) => updateRow(i, { name: e.target.value })}
                      placeholder="e.g. Premium Glossy" className="border p-1.5 rounded w-44 focus:ring-2 focus:ring-indigo-300 outline-none" />
                    {dupName && <p className="text-[10px] text-amber-700 mt-0.5">⚠ duplicate</p>}
                  </td>
                  <td className="p-1">
                    <select value={r.category} onChange={(e) => updateRow(i, { category: e.target.value })} className="border p-1.5 rounded w-32">
                      <option value="">—</option>
                      {categories.map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}
                    </select>
                  </td>
                  <td className="p-1">
                    <input list="company-list-bulk" value={r.company} onChange={(e) => updateRow(i, { company: e.target.value })}
                      className="border p-1.5 rounded w-32" placeholder="Brand" />
                  </td>
                  <td className="p-1">
                    <input list="size-list" value={r.size} onChange={(e) => updateRow(i, { size: e.target.value })}
                      className="border p-1.5 rounded w-24" placeholder="24x24" />
                  </td>
                  <td className="p-1"><input type="number" step="0.01" value={r.sqft_per_piece} onChange={(e) => updateRow(i, { sqft_per_piece: parseFloat(e.target.value) || 0 })} className="border p-1.5 rounded w-20 text-right" /></td>
                  <td className="p-1"><input type="number" value={r.pcs_per_carton} onChange={(e) => updateRow(i, { pcs_per_carton: parseInt(e.target.value) || 0 })} className="border p-1.5 rounded w-20 text-right" /></td>
                  <td className="p-1">
                    <div className="flex gap-1">
                      <button onClick={() => duplicateRow(i)} title="Duplicate" className="text-blue-600 hover:bg-blue-100 w-6 h-6 rounded">⎘</button>
                      <button onClick={() => removeRow(i)} title="Remove" className="text-red-600 hover:bg-red-100 w-6 h-6 rounded">✕</button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <datalist id="company-list-bulk">{companies.map((c) => <option key={c.id} value={c.name} />)}</datalist>
        <datalist id="size-list">{Object.keys(SIZE_PRESETS).map((s) => <option key={s} value={s} />)}</datalist>
      </div>

      <div className="sticky bottom-2 bg-white p-3 rounded-2xl shadow-lg border flex flex-wrap items-center gap-2 z-10">
        <button onClick={addRow} className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-1 hover:bg-blue-700">
          <Plus className="w-4 h-4" /> Add Row / আরও রো
        </button>
        <button onClick={clearAll} className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300">Clear All</button>
        <span className="text-xs text-gray-500 ml-2">💾 Draft auto-saved</span>
        <button onClick={submitAll} disabled={saving || !validRows.length}
          className="ml-auto bg-gradient-to-r from-emerald-600 to-green-600 text-white px-6 py-2.5 rounded-lg font-bold shadow-md hover:shadow-lg disabled:opacity-50">
          {saving ? "Saving..." : `💾 Save All (${validRows.length})`}
        </button>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-3">
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by product name" className="border p-2 rounded" />
          <input disabled placeholder="Search by supplier name" className="border p-2 rounded bg-gray-50 text-gray-400" />
          <input value={companySearch} onChange={(e) => setCompanySearch(e.target.value)} placeholder="Search by company name" className="border p-2 rounded" />
        </div>
        <div className="text-xs text-gray-500 mb-2">{filteredProducts.length} / {products.length}</div>
        <div className="overflow-auto max-h-[60vh] border border-gray-300">
          <table className="w-full text-sm border-collapse">
            <thead className="bg-gray-50 sticky top-0">
              <tr>
                <th className="border border-gray-300 p-2 text-left">SI</th>
                <th className="border border-gray-300 p-2 text-left">Product Name</th>
                <th className="border border-gray-300 p-2 text-left">Company Name</th>
                <th className="border border-gray-300 p-2 text-left">Category</th>
                <th className="border border-gray-300 p-2 text-left">Size</th>
                <th className="border border-gray-300 p-2 text-left">Pcs/Feet</th>
                <th className="border border-gray-300 p-2 text-left">Carton/Pcs</th>
                
                <th className="border border-gray-300 p-2 text-center">Edit</th>
                <th className="border border-gray-300 p-2 text-center">Delete</th>
              </tr>
            </thead>
            <tbody>
              {[...filteredProducts].sort((a, b) => {
                const cmp = (a.company || "").localeCompare(b.company || "");
                if (cmp !== 0) return cmp;
                return (a.name || "").localeCompare(b.name || "");
              }).map((p, i) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="border border-gray-300 p-2">{i + 1}</td>
                  <td className="border border-gray-300 p-2 font-medium">{p.name}</td>
                  <td className="border border-gray-300 p-2">{p.company || ""}</td>
                  <td className="border border-gray-300 p-2">{p.category || ""}</td>
                  <td className="border border-gray-300 p-2">{p.size || ""}</td>
                  <td className="border border-gray-300 p-2">{Number(p.sqft_per_piece || 0)}</td>
                  <td className="border border-gray-300 p-2">{p.pcs_per_carton}</td>
                  
                  <td className="border border-gray-300 p-2 text-center">
                    <button onClick={() => setEditProduct(p)} className="text-blue-600 hover:text-blue-800" title="Edit">
                      <Pencil className="w-4 h-4 inline" />
                    </button>
                  </td>
                  <td className="border border-gray-300 p-2 text-center">
                    <button
                      onClick={async () => {
                        if (!confirm(`Delete "${p.name}"?`)) return;
                        const { error } = await supabase.from("products").delete().eq("id", p.id);
                        if (error) return toast.error(error.message);
                        toast.success("Deleted");
                        refresh();
                      }}
                      className="text-red-600 hover:text-red-800"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4 inline" />
                    </button>
                  </td>
                </tr>
              ))}
              {!filteredProducts.length && (
                <tr><td colSpan={9} className="border border-gray-300 p-6 text-center text-gray-400">No products</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {editProduct && (
        <EditProductModal
          product={editProduct}
          categories={categories}
          companies={companies}
          onClose={() => setEditProduct(null)}
          onSaved={() => { setEditProduct(null); refresh(); }}
        />
      )}
    </div>
  );
}

function EditProductModal({ product, categories, companies, onClose, onSaved }: { product: Product; categories: Category[]; companies: Company[]; onClose: () => void; onSaved: () => void }) {
  
  const [name, setName] = useState(product.name);
  const [category, setCategory] = useState(product.category || "");
  const [company, setCompany] = useState(product.company || "");
  const [size, setSize] = useState(product.size || "");
  const [pcsPerCarton, setPcsPerCarton] = useState(product.pcs_per_carton);
  const [stockCartons, setStockCartons] = useState((product.pcs_per_carton || 1) > 0 ? (product.stock_pieces || 0) / (product.pcs_per_carton || 1) : 0);
  const [purchasePrice, setPurchasePrice] = useState(product.purchase_price_per_piece);
  const [sellPrice, setSellPrice] = useState(product.sell_price_per_piece);
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!name.trim()) return toast.error("Name required");
    setSaving(true);
    const { error } = await supabase.from("products").update({
      name: name.trim(),
      category: category || null,
      company: company || null,
      size: size || null,
      pcs_per_carton: Number(pcsPerCarton) || 1,
      stock_pieces: Math.round((Number(stockCartons) || 0) * (Number(pcsPerCarton) || 1)),
      purchase_price_per_piece: Number(purchasePrice) || 0,
      sell_price_per_piece: Number(sellPrice) || 0,
    }).eq("id", product.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Updated");
    onSaved();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl p-5 w-full max-w-lg space-y-3" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-lg font-bold">Edit Product / প্রোডাক্ট সম্পাদনা</h3>
        <div className="grid grid-cols-2 gap-3">
          <label className="text-sm">Name
            <input value={name} onChange={(e) => setName(e.target.value)} className="border p-2 rounded w-full mt-1" />
          </label>
          <label className="text-sm">Category
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="border p-2 rounded w-full mt-1">
              <option value="">--</option>
              {categories.map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}
            </select>
          </label>
          <label className="text-sm">Company
            <select value={company} onChange={(e) => setCompany(e.target.value)} className="border p-2 rounded w-full mt-1">
              <option value="">--</option>
              {companies.map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}
            </select>
          </label>
          <label className="text-sm">Size
            <input value={size} onChange={(e) => setSize(e.target.value)} className="border p-2 rounded w-full mt-1" />
          </label>
          <label className="text-sm">Pcs/Carton
            <input type="number" value={pcsPerCarton} onChange={(e) => setPcsPerCarton(Number(e.target.value))} className="border p-2 rounded w-full mt-1" />
          </label>
          <label className="text-sm">Stock (Carton)
            <input type="number" value={stockCartons} onChange={(e) => setStockCartons(Number(e.target.value))} className="border p-2 rounded w-full mt-1" />
          </label>
          <label className="text-sm">Purchase Price
            <input type="number" value={purchasePrice} onChange={(e) => setPurchasePrice(Number(e.target.value))} className="border p-2 rounded w-full mt-1" />
          </label>
          <label className="text-sm">Sell Price
            <input type="number" value={sellPrice} onChange={(e) => setSellPrice(Number(e.target.value))} className="border p-2 rounded w-full mt-1" />
          </label>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <button onClick={onClose} className="px-4 py-2 rounded border">Cancel</button>
          <button onClick={save} disabled={saving} className="px-4 py-2 rounded bg-blue-600 text-white disabled:opacity-50">{saving ? "Saving..." : "Save"}</button>
        </div>
      </div>
    </div>
  );
}


// ----- Companies -----
function AddCompany({ userId, companies, refresh }: { userId: string; companies: Company[]; refresh: () => void }) {
  const [name, setName] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [query, setQuery] = useState("");

  const add = async () => {
    if (!name.trim()) return;
    const { error } = await supabase.from("companies").insert({ user_id: userId, name });
    if (error) return toast.error(error.message);
    toast.success("Company যোগ হয়েছে");
    setName("");
    setShowForm(false);
    refresh();
  };

  const startEdit = (c: Company) => {
    setEditingId(c.id);
    setEditName(c.name);
  };

  const saveEdit = async () => {
    if (!editingId || !editName.trim()) return;
    const { error } = await supabase.from("companies").update({ name: editName.trim() }).eq("id", editingId);
    if (error) return toast.error(error.message);
    setEditingId(null);
    setEditName("");
    refresh();
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditName("");
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this company? / এই কোম্পানি ডিলিট করবেন?")) return;
    const { error } = await supabase.from("companies").delete().eq("id", id);
    if (error) return toast.error(error.message);
    refresh();
  };

  const filtered = companies.filter((c) => c.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="space-y-4">
      <div>
        <button onClick={() => setShowForm((v) => !v)} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-5 py-2.5 rounded shadow">
          Add Company
        </button>
      </div>

      {showForm && (
        <div className="bg-white p-5 rounded-2xl shadow-sm space-y-3 max-w-2xl">
          <h3 className="font-bold text-lg">New Company</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input placeholder="Company Name" value={name} onChange={(e) => setName(e.target.value)} className="border p-2 rounded" />
          </div>
          <div className="flex gap-2">
            <button onClick={add} className="bg-blue-600 text-white px-4 py-2 rounded">Save</button>
            <button onClick={() => setShowForm(false)} className="bg-gray-200 px-4 py-2 rounded">Cancel</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-center">
        <input placeholder="Search by name" value={query} onChange={(e) => setQuery(e.target.value)} className="border bg-white p-2.5 rounded shadow-sm" />
        <button onClick={() => setQuery("")} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-4 py-2.5 rounded shadow w-fit">Clear Filter</button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 text-gray-700 uppercase text-xs">
              <th className="p-3 text-left w-16">SL</th>
              <th className="p-3 text-left">Company Name</th>
              <th className="p-3 text-center w-32">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={3} className="p-6 text-center text-gray-400">No companies found</td></tr>
            ) : filtered.map((c, i) => (
              <tr key={c.id} className="border-t hover:bg-gray-50">
                <td className="p-3">{i + 1}</td>
                <td className="p-3 font-medium">
                  {editingId === c.id ? (
                    <input value={editName} onChange={(e) => setEditName(e.target.value)} className="border p-1 rounded w-full max-w-xs" />
                  ) : (
                    c.name
                  )}
                </td>
                <td className="p-3 text-center">
                  {editingId === c.id ? (
                    <div className="flex justify-center gap-2">
                      <button onClick={saveEdit} className="bg-green-600 text-white px-2 py-1 rounded text-xs">Save</button>
                      <button onClick={cancelEdit} className="bg-gray-400 text-white px-2 py-1 rounded text-xs">Cancel</button>
                    </div>
                  ) : (
                    <div className="flex justify-center gap-2">
                      <button onClick={() => startEdit(c)} className="text-blue-600 hover:bg-blue-50 p-1 rounded" title="Edit"><Pencil className="w-4 h-4" /></button>
                      <button onClick={() => remove(c.id)} className="text-red-600 hover:bg-red-50 p-1 rounded" title="Delete"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ----- Company Report -----

// ----- Purchases: see src/components/PurchaseProduct.tsx and PurchaseHistory.tsx -----

// ----- Suppliers -----
function AddSupplier({ userId, suppliers, refresh }: { userId: string; suppliers: Supplier[]; refresh: () => void }) {
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [company, setCompany] = useState("");
  const [mobile, setMobile] = useState("");
  const [address, setAddress] = useState("");
  const [qName, setQName] = useState("");
  const [qCompany, setQCompany] = useState("");
  const [qMobile, setQMobile] = useState("");

  const add = async () => {
    if (!name.trim()) return toast.error("Name দিন");
    const { error } = await supabase.from("suppliers").insert({ user_id: userId, name, mobile, address, company } as never);
    if (error) return toast.error(error.message);
    setName(""); setCompany(""); setMobile(""); setAddress(""); setShowForm(false); refresh();
    toast.success("Supplier যোগ হয়েছে");
  };

  const remove = async (id: string) => {
    if (!confirm("Supplier মুছে ফেলবেন?")) return;
    const { error } = await supabase.from("suppliers").delete().eq("id", id);
    if (error) return toast.error(error.message);
    refresh();
  };

  const clearFilter = () => { setQName(""); setQCompany(""); setQMobile(""); };

  const filtered = suppliers.filter((s) => {
    const n = (s.name || "").toLowerCase();
    const c = ((s as Supplier).company || "").toLowerCase();
    const m = (s.mobile || "").toLowerCase();
    return n.includes(qName.toLowerCase()) && c.includes(qCompany.toLowerCase()) && m.includes(qMobile.toLowerCase());
  });

  const printList = () => {
    const w = window.open("", "_blank"); if (!w) return;
    const rows = filtered.map((s, i) => `<tr><td>${i + 1}</td><td>${s.name}</td><td>${(s as Supplier).company || ""}</td><td>${s.mobile || ""}</td></tr>`).join("");
    w.document.write(`<html><head><title>Suppliers</title><style>body{font-family:Arial;padding:20px}h2{text-align:center}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:8px;text-align:left}th{background:#f3f4f6}</style></head><body><h2>Alam Tiles — Supplier List</h2><table><thead><tr><th>SL</th><th>Supplier Name</th><th>Company Name</th><th>Mobile Number</th></tr></thead><tbody>${rows}</tbody></table><script>window.print()</script></body></html>`);
    w.document.close();
  };

  return (
    <div className="space-y-4">
      <div>
        <button onClick={() => setShowForm((v) => !v)} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-5 py-2.5 rounded shadow">
          Add Supplier
        </button>
      </div>

      {showForm && (
        <div className="bg-white p-5 rounded-2xl shadow-sm space-y-3 max-w-2xl">
          <h3 className="font-bold text-lg">New Supplier</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input placeholder="Supplier Name" value={name} onChange={(e) => setName(e.target.value)} className="border p-2 rounded" />
            <input placeholder="Company Name" value={company} onChange={(e) => setCompany(e.target.value)} className="border p-2 rounded" />
            <input placeholder="Mobile Number" value={mobile} onChange={(e) => setMobile(e.target.value)} className="border p-2 rounded" />
            <input placeholder="Address" value={address} onChange={(e) => setAddress(e.target.value)} className="border p-2 rounded" />
          </div>
          <div className="flex gap-2">
            <button onClick={add} className="bg-blue-600 text-white px-4 py-2 rounded">Save</button>
            <button onClick={() => setShowForm(false)} className="bg-gray-200 px-4 py-2 rounded">Cancel</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-center">
        <input placeholder="Search by name" value={qName} onChange={(e) => setQName(e.target.value)} className="border bg-white p-2.5 rounded shadow-sm" />
        <input placeholder="Search by Company" value={qCompany} onChange={(e) => setQCompany(e.target.value)} className="border bg-white p-2.5 rounded shadow-sm" />
        <input placeholder="Search by Mobile" value={qMobile} onChange={(e) => setQMobile(e.target.value)} className="border bg-white p-2.5 rounded shadow-sm" />
        <button onClick={clearFilter} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-4 py-2.5 rounded shadow">Clear Filter</button>
      </div>

      <button onClick={printList} className="text-sm text-gray-700 underline">Print</button>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 text-gray-700 uppercase text-xs">
              <th className="p-3 text-left w-16">SL</th>
              <th className="p-3 text-left">Supplier Name</th>
              <th className="p-3 text-left">Company Name</th>
              <th className="p-3 text-left">Mobile Number</th>
              <th className="p-3 text-center w-20">Delete</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={5} className="p-6 text-center text-gray-400">No suppliers found</td></tr>
            ) : filtered.map((s, i) => (
              <tr key={s.id} className="border-t hover:bg-gray-50">
                <td className="p-3">{i + 1}</td>
                <td className="p-3 font-medium">{s.name}</td>
                <td className="p-3">{(s as Supplier).company || ""}</td>
                <td className="p-3">{s.mobile || ""}</td>
                <td className="p-3 text-center">
                  <button onClick={() => remove(s.id)} className="text-red-600 hover:text-red-800" title="Delete">🗑️</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}


// Cost Report moved to src/components/CostReport.tsx



function StockCutManager({ userId, products, stockCuts, refresh }: { userId: string | null; products: Product[]; stockCuts: StockCut[]; refresh: () => void }) {
  const [productId, setProductId] = useState("");
  const [pieces, setPieces] = useState(0);
  const [reason, setReason] = useState("");
  const [cutDate, setCutDate] = useState(new Date().toISOString().slice(0, 10));

  const selectedProduct = products.find((p) => p.id === productId);

  const add = async () => {
    if (!userId) return;
    if (!productId) return toast.error("Product select করুন");
    if (pieces <= 0) return toast.error("Pieces দিন");
    if (selectedProduct && pieces > selectedProduct.stock_pieces) {
      return toast.error(`Stock-এ ${selectedProduct.stock_pieces} pcs আছে, ${pieces} কাটা যাবে না`);
    }
    const { error } = await supabase.from("stock_cuts").insert({
      user_id: userId,
      product_id: productId,
      pieces,
      reason: reason.trim() || null,
      cut_date: cutDate,
    });
    if (error) return toast.error(error.message);
    if (selectedProduct) {
      await supabase.from("products").update({ stock_pieces: selectedProduct.stock_pieces - pieces }).eq("id", productId);
    }
    toast.success("Damage List সম্পন্ন");
    setProductId("");
    setPieces(0);
    setReason("");
    refresh();
  };

  const remove = async (cut: StockCut) => {
    if (!confirm("মুছে ফেলবেন? স্টক ফিরিয়ে আনা হবে।")) return;
    const product = products.find((p) => p.id === cut.product_id);
    const { error } = await supabase.from("stock_cuts").delete().eq("id", cut.id);
    if (error) return toast.error(error.message);
    if (product) {
      await supabase.from("products").update({ stock_pieces: product.stock_pieces + cut.pieces }).eq("id", product.id);
    }
    toast.success("মুছে ফেলা হয়েছে");
    refresh();
  };

  const totalCutPieces = stockCuts.reduce((s, c) => s + Number(c.pieces), 0);
  const totalCutValue = stockCuts.reduce((s, c) => {
    const p = products.find((pr) => pr.id === c.product_id);
    return s + Number(c.pieces) * Number(p?.purchase_price_per_piece || 0);
  }, 0);

  return (
    <div className="space-y-4 max-w-[1400px] mx-auto">
      <h1 className="text-center text-2xl font-semibold text-gray-700 mt-2">Damage List</h1>

      {/* Form */}
      <div className="bg-white p-5 rounded-2xl shadow-sm space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <label className="text-xs font-semibold text-gray-600">Product</label>
            <SearchSelect
              placeholder="Select product..."
              value={productId}
              onChange={(v) => setProductId(v)}
              options={products.map((p) => ({
                value: p.id,
                label: `${p.name}${p.size ? ` ${p.size}` : ""}${p.company ? ` • ${p.company}` : ""}`,
                hint: `stk ${p.stock_pieces} pcs`,
              }))}
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-600">Pieces</label>
            <input type="number" min={1} className="mt-1 w-full px-3 py-2 border rounded-lg outline-none" value={pieces || ""} onChange={(e) => setPieces(parseInt(e.target.value) || 0)} />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-600">Reason</label>
            <input placeholder="e.g. ভাঙা, নষ্ট" className="mt-1 w-full px-3 py-2 border rounded-lg outline-none" value={reason} onChange={(e) => setReason(e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-600">Date</label>
            <input type="date" className="mt-1 w-full px-3 py-2 border rounded-lg outline-none" value={cutDate} onChange={(e) => setCutDate(e.target.value)} />
          </div>
        </div>
        <button onClick={add} className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium">Damage List</button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-2xl shadow-sm">
          <p className="text-sm text-gray-500">মোট কাটুন (বার)</p>
          <p className="text-xl font-bold">{stockCuts.length}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm">
          <p className="text-sm text-gray-500">মোট কাটুন (পিস)</p>
          <p className="text-xl font-bold">{totalCutPieces}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm">
          <p className="text-sm text-gray-500">মোট মূল্য</p>
          <p className="text-xl font-bold">৳{totalCutValue.toFixed(2)}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm">
          <p className="text-sm text-gray-500">আজকের কাটুন</p>
          <p className="text-xl font-bold">{stockCuts.filter((c) => c.cut_date === new Date().toISOString().slice(0, 10)).length}</p>
        </div>
      </div>

      {/* History */}
      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full border-collapse text-sm">
          <thead className="bg-gray-50 text-gray-700">
            <tr>
              <th className="border border-gray-300 px-3 py-2 text-left">Date</th>
              <th className="border border-gray-300 px-3 py-2 text-left">Product</th>
              <th className="border border-gray-300 px-3 py-2 text-left">Pieces</th>
              <th className="border border-gray-300 px-3 py-2 text-left">Reason</th>
              <th className="border border-gray-300 px-3 py-2 text-left">Value</th>
              <th className="border border-gray-300 px-3 py-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {stockCuts.length === 0 && (
              <tr><td colSpan={6} className="border border-gray-300 p-6 text-center text-gray-400">কোনো Damage List নেই</td></tr>
            )}
            {stockCuts.map((cut) => {
              const p = products.find((pr) => pr.id === cut.product_id);
              const val = Number(cut.pieces) * Number(p?.purchase_price_per_piece || 0);
              return (
                <tr key={cut.id} className="border-b hover:bg-gray-50">
                  <td className="border border-gray-300 px-3 py-2">{cut.cut_date}</td>
                  <td className="border border-gray-300 px-3 py-2">{p?.name ?? "—"}</td>
                  <td className="border border-gray-300 px-3 py-2">{cut.pieces}</td>
                  <td className="border border-gray-300 px-3 py-2">{cut.reason ?? "—"}</td>
                  <td className="border border-gray-300 px-3 py-2">৳{val.toFixed(2)}</td>
                  <td className="border border-gray-300 px-3 py-2 text-center">
                    <button onClick={() => remove(cut)} className="text-red-600 hover:text-red-800 text-xs">Delete</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}


function CashInOut({ userId, cashTx, refresh }: { userId: string; cashTx: CashTx[]; refresh: () => void }) {
  const [type, setType] = useState<"in" | "out">("in"); const [amount, setAmount] = useState(0); const [reason, setReason] = useState("");
  const add = async () => {
    if (amount <= 0) return;
    const { error } = await supabase.from("cash_transactions").insert({ user_id: userId, type, amount, reason });
    if (error) return toast.error(error.message);
    setAmount(0); setReason(""); refresh();
  };
  const totalIn = cashTx.filter((t) => t.type === "in").reduce((s, t) => s + Number(t.amount), 0);
  const totalOut = cashTx.filter((t) => t.type === "out").reduce((s, t) => s + Number(t.amount), 0);
  return (
    <div className="bg-white p-5 rounded-2xl shadow-sm space-y-3">
      <h2 className="text-xl font-bold">Cash Transactions</h2>
      <div className="grid grid-cols-3 gap-3 mb-3">
        <div className="bg-green-50 p-3 rounded"><p className="text-sm">Cash In</p><p className="font-bold">৳{totalIn.toFixed(2)}</p></div>
        <div className="bg-red-50 p-3 rounded"><p className="text-sm">Cash Out</p><p className="font-bold">৳{totalOut.toFixed(2)}</p></div>
        <div className="bg-blue-50 p-3 rounded"><p className="text-sm">Balance</p><p className="font-bold">৳{(totalIn - totalOut).toFixed(2)}</p></div>
      </div>
      <select value={type} onChange={(e) => setType(e.target.value as any)} className="border p-2 w-full rounded">
        <option value="in">Cash In</option><option value="out">Cash Out</option>
      </select>
      <input type="number" placeholder="Amount" value={amount} onChange={(e) => setAmount(parseFloat(e.target.value) || 0)} className="border p-2 w-full rounded" />
      <input placeholder="Reason" value={reason} onChange={(e) => setReason(e.target.value)} className="border p-2 w-full rounded" />
      <button onClick={add} className="bg-blue-600 text-white px-4 py-2 rounded">Record</button>
      <hr />
      <h3 className="font-semibold">History</h3>
      <ul className="text-sm space-y-1 max-h-60 overflow-auto">{cashTx.map((t) => (
        <li key={t.id} className="flex justify-between border-b py-1"><span>{t.trans_date} — {t.reason}</span><span className={t.type === "in" ? "text-green-600" : "text-red-600"}>{t.type === "in" ? "+" : "-"}৳{Number(t.amount).toFixed(2)}</span></li>
      ))}</ul>
    </div>
  );
}

// ----- Dashboard -----
function Dashboard({ products, customers, suppliers, sales, purchases, costs, cashTx, stockCuts, onNavigate, onViewDueCustomers }: {
  products: Product[]; customers: Customer[]; suppliers: Supplier[];
  sales: Sale[]; purchases: Purchase[]; costs: Cost[]; cashTx: CashTx[]; stockCuts: StockCut[];
  onNavigate: (m: string) => void;
  onViewDueCustomers: () => void;
}) {
  const today = new Date().toISOString().slice(0, 10);
  const monthStart = today.slice(0, 7);

  const todaysSales = sales.filter((s) => (s.sale_date || "").slice(0, 10) === today);
  const monthSales = sales.filter((s) => (s.sale_date || "").slice(0, 7) === monthStart);

  const todaysSaleAmount = todaysSales.reduce((a, s) => a + Number(s.total_amount || 0), 0);
  const todaysCollected = todaysSales.reduce((a, s) => a + Number(s.paid_amount || 0), 0);
  const monthSaleAmount = monthSales.reduce((a, s) => a + Number(s.total_amount || 0), 0);

  const totalCustomerDue = customers.reduce((a, c) => a + Number(c.due_amount || 0), 0);
  const totalSupplierDue = suppliers.reduce((a, s) => a + Number(s.total_due || 0), 0);

  const totalStockPieces = products.reduce((a, p) => a + Number(p.stock_pieces || 0), 0);
  const stockValue = products.reduce((a, p) => a + Number(p.stock_pieces || 0) * Number(p.purchase_price_per_piece || 0), 0);
  const lowStock = products.filter((p) => Number(p.stock_pieces || 0) <= Number(p.min_label_feet || 0)).length;
  const totalStockCutPieces = stockCuts.reduce((a, sc) => a + Number(sc.pieces || 0), 0);

  const productMapDash = new Map(products.map((p) => [p.id, p]));
  const totalStockCartons = Math.round(products.reduce((a, p) => a + Number(p.stock_pieces || 0) / Number(p.pcs_per_carton || 1), 0));
  const totalStockCutCartons = Math.round(stockCuts.reduce((a, sc) => {
    const prod = sc.product_id ? productMapDash.get(sc.product_id) : null;
    return a + Number(sc.pieces || 0) / Number(prod?.pcs_per_carton || 1);
  }, 0));

  const todaysCost = costs.filter((c) => (c.cost_date || "").slice(0, 10) === today)
    .reduce((a, c) => a + Number(c.amount || 0), 0);
  const monthCost = costs.filter((c) => (c.cost_date || "").slice(0, 7) === monthStart)
    .reduce((a, c) => a + Number(c.amount || 0), 0);

  const cashIn = cashTx.filter((t) => t.type === "in").reduce((a, t) => a + Number(t.amount || 0), 0);
  const cashOut = cashTx.filter((t) => t.type === "out").reduce((a, t) => a + Number(t.amount || 0), 0);
  const cashBalance = cashIn - cashOut;

  const recentSales = [...sales].slice(0, 5);

  const stats: { label: string; value: string; detail?: string; color: string; menu?: string; icon: any }[] = [
    { label: "আজকের বিক্রি", value: `৳${todaysSaleAmount.toFixed(0)}`, color: "from-blue-500 to-blue-700", menu: "saleHistory", icon: FileText },
    { label: "আজকের কালেকশন", value: `৳${todaysCollected.toFixed(0)}`, color: "from-emerald-500 to-emerald-700", menu: "saleHistory", icon: Wallet },
    { label: "এই মাসের বিক্রি", value: `৳${monthSaleAmount.toFixed(0)}`, color: "from-indigo-500 to-indigo-700", menu: "saleHistory", icon: BarChart3 },
    { label: "মোট কাস্টমার বকেয়া", value: `৳${totalCustomerDue.toFixed(0)}`, color: "from-orange-500 to-orange-700", menu: "customerReport", icon: User },
    { label: "মোট সাপ্লায়ার বকেয়া", value: `৳${totalSupplierDue.toFixed(0)}`, color: "from-rose-500 to-rose-700", menu: "supplierPayment", icon: Truck },
    { label: "ক্যাশ ব্যালান্স", value: `৳${cashBalance.toFixed(0)}`, color: "from-teal-500 to-teal-700", menu: "cashInOut", icon: ArrowLeftRight },
    { label: "আজকের খরচ", value: `৳${todaysCost.toFixed(0)}`, color: "from-amber-500 to-amber-700", menu: "costReport", icon: Coins },
    { label: "এই মাসের খরচ", value: `৳${monthCost.toFixed(0)}`, color: "from-yellow-500 to-yellow-700", menu: "costReport", icon: PieChart },
    { label: "স্টক ভ্যালু", value: `৳${stockValue.toFixed(0)}`, color: "from-purple-500 to-purple-700", menu: "myStock", icon: Boxes },
    { label: "মোট স্টক (কাটুন)", value: `${totalStockCartons}`, detail: `কাটুন: ${totalStockCutCartons}`, color: "from-fuchsia-500 to-fuchsia-700", menu: "godownStatus", icon: Warehouse },
    { label: "প্রোডাক্ট সংখ্যা", value: `${products.length}`, color: "from-cyan-500 to-cyan-700", menu: "addProduct", icon: Package },
    { label: "লো-স্টক প্রোডাক্ট", value: `${lowStock}`, color: "from-red-500 to-red-700", menu: "myStock", icon: Sparkles },
    { label: "মোট কাস্টমার", value: `${customers.length}`, color: "from-sky-500 to-sky-700", menu: "addCustomer", icon: UserPlus },
    { label: "মোট সাপ্লায়ার", value: `${suppliers.length}`, color: "from-slate-500 to-slate-700", menu: "addSupplier", icon: TruckIcon },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Dashboard</h2>
          <p className="text-sm text-gray-500">আজ {new Date().toLocaleDateString("en-GB")} — এক নজরে আপনার দোকান</p>
        </div>
        <button onClick={() => onNavigate("saleForm")} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 shadow">
          <Plus className="w-4 h-4" /> নতুন বিক্রি
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <button key={s.label} onClick={() => s.menu && onNavigate(s.menu)}
              className={`text-left bg-gradient-to-br ${s.color} text-white p-4 rounded-2xl shadow-md hover:shadow-xl hover:scale-[1.02] transition-all`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium opacity-90">{s.label}</span>
                <Icon className="w-5 h-5 opacity-80" />
              </div>
              <div className="text-2xl font-bold">{s.value}</div>
              {s.detail && <div className="text-xs mt-1 opacity-80">{s.detail}</div>}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl shadow p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-800">সাম্প্রতিক বিক্রি</h3>
            <button onClick={() => onNavigate("saleHistory")} className="text-xs text-blue-600 hover:underline">সব দেখুন</button>
          </div>
          {recentSales.length === 0 ? (
            <p className="text-sm text-gray-500">কোনো বিক্রি নেই</p>
          ) : (
            <ul className="divide-y">
              {recentSales.map((s) => {
                const cust = customers.find((c) => c.id === s.customer_id);
                return (
                  <li key={s.id} className="py-2 flex justify-between text-sm">
                    <div>
                      <div className="font-medium text-gray-800">#{s.invoice_no} — {cust?.name ?? "Walk-in"}</div>
                      <div className="text-xs text-gray-500">{(s.sale_date || "").slice(0, 10)}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-gray-800">৳{Number(s.total_amount).toFixed(0)}</div>
                      {Number(s.due_amount) > 0 && <div className="text-xs text-orange-600">বকেয়া ৳{Number(s.due_amount).toFixed(0)}</div>}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-800">টপ বকেয়া কাস্টমার</h3>
            <button
              onClick={() => { onViewDueCustomers(); onNavigate("customerReport"); }}
              className="text-xs font-medium text-blue-600 hover:text-blue-800 hover:underline"
            >
              সব দেখুন →
            </button>
          </div>
          {customers.filter((c) => Number(c.due_amount) > 0).length === 0 ? (
            <p className="text-sm text-gray-500">কোনো বকেয়া নেই 🎉</p>
          ) : (
            <ul className="divide-y">
              {[...customers].filter((c) => Number(c.due_amount) > 0)
                .sort((a, b) => Number(b.due_amount) - Number(a.due_amount))
                .slice(0, 5)
                .map((c) => (
                  <li key={c.id} className="py-2 flex justify-between text-sm">
                    <div>
                      <div className="font-medium text-gray-800">{c.name}</div>
                      <div className="text-xs text-gray-500">{c.mobile ?? ""}</div>
                    </div>
                    <div className="font-semibold text-orange-600">৳{Number(c.due_amount).toFixed(0)}</div>
                  </li>
                ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

