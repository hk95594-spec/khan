import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AlertTriangle, ArrowLeft, Package, MessageSquare } from "lucide-react";

const WHATSAPP_NUMBER = "8801757770796";
const toBn = (s: string | number) => String(s).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);

function buildStockHtml(products: Product[]): string {
  const today = new Date().toLocaleDateString("en-GB");
  const totalPieces = products.reduce((s, p) => s + Number(p.stock_pieces || 0), 0);
  const rows = products.map((p, i) => {
    const cartons = p.pcs_per_carton > 0 ? (p.stock_pieces / p.pcs_per_carton).toFixed(2) : "-";
    return `<tr>
      <td class="c">${toBn(i + 1)}</td>
      <td>${p.name}${p.size ? " " + p.size : ""}</td>
      <td>${p.company ?? ""}</td>
      <td class="r">${toBn(p.stock_pieces)}</td>
      <td class="r">${cartons === "-" ? "-" : toBn(cartons)}</td>
      <td class="r">${toBn(p.sell_price_per_piece)}</td>
    </tr>`;
  }).join("");
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Stock ${today}</title>
<style>
@page { size: A4 portrait; margin: 10mm; }
body { font-family: "Noto Sans Bengali","SolaimanLipi","Kalpurush",Arial,sans-serif; color:#000; margin:0; padding:0; font-size:12px; }
h1 { text-align:center; margin:4px 0; font-size:22px; }
.sub { text-align:center; margin-bottom:8px; font-size:13px; color:#444; }
table { width:100%; border-collapse:collapse; }
th, td { border:1px solid #333; padding:4px 6px; font-size:12px; }
th { background:#f3f4f6; text-align:left; font-size:13px; }
td.c { text-align:center; } td.r { text-align:right; }
.tot { margin-top:8px; font-size:13px; font-weight:700; text-align:right; }
@media print { body { -webkit-print-color-adjust: exact; } }
</style></head><body>
<h1>আলম টাইলস — স্টক রিপোর্ট</h1>
<div class="sub">তারিখ: ${toBn(today)} | মোট পণ্য: ${toBn(products.length)}</div>
<table>
<thead><tr><th style="width:12mm">নং</th><th>পণ্য</th><th>কোম্পানি</th><th style="width:22mm" class="r">স্টক (পিস)</th><th style="width:22mm" class="r">কাটুন</th><th style="width:20mm" class="r">দর</th></tr></thead>
<tbody>${rows}</tbody>
</table>
<div class="tot">সর্বমোট পিস: ${toBn(totalPieces)}</div>
<script>window.onload=function(){setTimeout(function(){window.print();},300);}</script>
</body></html>`;
}

export const Route = createFileRoute("/stock-alert")({
  head: () => ({
    meta: [
      { title: "Low Stock Alert — Alam Tiles" },
      { name: "description", content: "Check current low stock items and inventory alerts for Alam Tiles to ensure your shop stays well-supplied and never runs out." },
      { property: "og:title", content: "Low Stock Alert — Alam Tiles" },
      { property: "og:description", content: "Check current low stock items and inventory alerts for Alam Tiles to ensure your shop stays well-supplied and never runs out." },
      { property: "og:url", content: "https://tilewise-buddy.lovable.app/stock-alert" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [
      { rel: "canonical", href: "https://tilewise-buddy.lovable.app/stock-alert" },
    ],
  }),
  component: StockAlertPage,
});

type Product = {
  id: string;
  name: string;
  category: string | null;
  company: string | null;
  size: string | null;
  stock_pieces: number;
  pcs_per_carton: number;
  sqft_per_piece: number;
  sell_price_per_piece: number;
};

function StockAlertPage() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [threshold, setThreshold] = useState<number>(20);

  useEffect(() => {
    (async () => {
      const { data: session } = await supabase.auth.getSession();
      if (!session.session) {
        navigate({ to: "/auth" });
        return;
      }
      const { data } = await supabase
        .from("products")
        .select("id,name,category,company,size,stock_pieces,pcs_per_carton,sqft_per_piece,sell_price_per_piece")
        .order("stock_pieces", { ascending: true });
      setProducts((data as Product[]) ?? []);
      setLoading(false);
    })();
  }, [navigate]);

  const low = products.filter((p) => p.stock_pieces <= threshold);
  const out = low.filter((p) => p.stock_pieces <= 0).length;

  async function sendStockToWhatsApp() {
    const list = products.filter((p) => Number(p.stock_pieces) > 0);
    const today = new Date().toLocaleDateString("en-GB");

    // Build a hidden DOM element with the stock report and convert it to PDF
    const html = buildStockHtml(list).replace(/<script[\s\S]*?<\/script>/g, "");
    const container = document.createElement("div");
    container.style.position = "fixed";
    container.style.left = "-10000px";
    container.style.top = "0";
    container.style.width = "210mm";
    container.innerHTML = html;
    document.body.appendChild(container);

    try {
      const html2pdf = (await import("html2pdf.js")).default;
      await html2pdf()
        .from(container)
        .set({
          margin: 10,
          filename: `stock-${today.replace(/\//g, "-")}.pdf`,
          image: { type: "jpeg", quality: 0.95 },
          html2canvas: { scale: 2, useCORS: true },
          jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
        })
        .save();
    } finally {
      container.remove();
    }

    const lines = [
      `*আলম টাইলস — স্টক রিপোর্ট*`,
      `তারিখ: ${today}`,
      `মোট পণ্য: ${list.length}`,
      ``,
      ...list.slice(0, 40).map((p, i) => {
        const cartons = p.pcs_per_carton > 0 ? (p.stock_pieces / p.pcs_per_carton).toFixed(2) : "-";
        return `${i + 1}. ${p.name}${p.size ? " " + p.size : ""} — ${p.stock_pieces} পিস (${cartons} কার্টন)`;
      }),
    ];
    if (list.length > 40) lines.push(`...আরও ${list.length - 40} টি পণ্য (PDF দেখুন)`);
    lines.push(``, `সদ্য ডাউনলোড হওয়া PDF এই চ্যাটে অ্যাটাচ করে পাঠান।`);
    const msg = encodeURIComponent(lines.join("\n"));
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, "_blank");
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
          <Link to="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> হোমে ফিরে যান
          </Link>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={sendStockToWhatsApp}
              disabled={loading || products.length === 0}
              className="inline-flex items-center gap-2 rounded-md bg-emerald-600 px-3 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-50"
            >
              <MessageSquare className="h-4 w-4" /> Send Today's Stock to WhatsApp
            </button>
            <label className="text-sm">সীমা (পিস):</label>
            <input
              type="number"
              value={threshold}
              onChange={(e) => setThreshold(Number(e.target.value) || 0)}
              className="w-20 rounded-md border border-input bg-background px-2 py-1 text-sm"
            />
          </div>
        </div>


        <div className="flex items-center gap-3 mb-6">
          <div className="rounded-full bg-destructive/10 p-3">
            <AlertTriangle className="h-6 w-6 text-destructive" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Low Stock Alert</h1>
            <p className="text-sm text-muted-foreground">
              {low.length} টি পণ্য কম স্টকে — {out} টি একদম শেষ
            </p>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">লোড হচ্ছে...</div>
        ) : low.length === 0 ? (
          <div className="text-center py-12 rounded-lg border border-border bg-card">
            <Package className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
            <p className="text-muted-foreground">সব পণ্যের স্টক ভালো অবস্থায় আছে।</p>
          </div>
        ) : (
          <div className="rounded-lg border border-border bg-card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left p-3">পণ্য</th>
                  <th className="text-left p-3">কোম্পানি</th>
                  <th className="text-left p-3">সাইজ</th>
                  <th className="text-right p-3">স্টক (পিস)</th>
                  <th className="text-right p-3">কাটুন</th>
                  <th className="text-right p-3">দর</th>
                  <th className="text-center p-3">অবস্থা</th>
                </tr>
              </thead>
              <tbody>
                {low.map((p) => {
                  const cartons = p.pcs_per_carton > 0 ? (p.stock_pieces / p.pcs_per_carton).toFixed(2) : "-";
                  const isOut = p.stock_pieces <= 0;
                  return (
                    <tr key={p.id} className="border-t border-border">
                      <td className="p-3 font-medium">{p.name}</td>
                      <td className="p-3 text-muted-foreground">{p.company || "-"}</td>
                      <td className="p-3 text-muted-foreground">{p.size || "-"}</td>
                      <td className="p-3 text-right font-mono">{p.stock_pieces}</td>
                      <td className="p-3 text-right font-mono">{cartons}</td>
                      <td className="p-3 text-right font-mono">{p.sell_price_per_piece}</td>
                      <td className="p-3 text-center">
                        <span
                          className={`inline-block rounded-full px-2 py-0.5 text-xs font-semibold ${
                            isOut
                              ? "bg-destructive text-destructive-foreground"
                              : "bg-yellow-100 text-yellow-900 dark:bg-yellow-900/30 dark:text-yellow-200"
                          }`}
                        >
                          {isOut ? "শেষ" : "কম"}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
