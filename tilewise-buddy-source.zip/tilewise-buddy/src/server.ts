import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => ((m as { default?: ServerEntry }).default ?? (m as unknown as ServerEntry)),
    );
  }
  return serverEntryPromise;
}

function formatError(error: unknown): Record<string, unknown> {
  if (error instanceof Error) {
    return {
      name: error.name,
      message: error.message,
      stack: error.stack,
      cause: error.cause ? formatError(error.cause) : undefined,
    };
  }
  return { value: String(error), raw: error };
}

function logDetailed(context: string, request: Request, extra: Record<string, unknown>) {
  const url = new URL(request.url);
  console.error(
    JSON.stringify(
      {
        tag: "[SSR_ERROR]",
        context,
        timestamp: new Date().toISOString(),
        method: request.method,
        path: url.pathname + url.search,
        host: url.host,
        userAgent: request.headers.get("user-agent"),
        referer: request.headers.get("referer"),
        ...extra,
      },
      null,
      2,
    ),
  );
}

function brandedErrorResponse(): Response {
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

function isCatastrophicSsrErrorBody(body: string, responseStatus: number): boolean {
  let payload: unknown;
  try {
    payload = JSON.parse(body);
  } catch {
    return false;
  }

  if (!payload || Array.isArray(payload) || typeof payload !== "object") {
    return false;
  }

  const fields = payload as Record<string, unknown>;
  const expectedKeys = new Set(["message", "status", "unhandled"]);
  if (!Object.keys(fields).every((key) => expectedKeys.has(key))) {
    return false;
  }

  return (
    fields.unhandled === true &&
    fields.message === "HTTPError" &&
    (fields.status === undefined || fields.status === responseStatus)
  );
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(
  request: Request,
  response: Response,
): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!isCatastrophicSsrErrorBody(body, response.status)) {
    return response;
  }

  const captured = consumeLastCapturedError();
  logDetailed("h3_swallowed_ssr_error", request, {
    responseStatus: response.status,
    responseBody: body,
    capturedError: captured ? formatError(captured) : null,
    note: captured
      ? "Original error recovered from error-capture global handler."
      : "No original error captured — check route loaders, server functions, and render code.",
  });
  return brandedErrorResponse();
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    const startedAt = Date.now();
    try {
      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      if (response.status >= 500) {
        logDetailed("ssr_5xx_response", request, {
          responseStatus: response.status,
          durationMs: Date.now() - startedAt,
        });
      }
      return await normalizeCatastrophicSsrResponse(request, response);
    } catch (error) {
      logDetailed("ssr_thrown_error", request, {
        durationMs: Date.now() - startedAt,
        error: formatError(error),
      });
      return brandedErrorResponse();
    }
  },
};
