/// <reference types="bun" />
import { describe, expect, test } from "bun:test";
import { buildInvoiceHtml } from "@/components/SaleHistory";

const BN = { "০": "0", "১": "1", "২": "2", "৩": "3", "৪": "4", "৫": "5", "৬": "6", "৭": "7", "৮": "8", "৯": "9" } as Record<string, string>;
const toAscii = (s: string) => s.replace(/[০-৯]/g, (d) => BN[d] ?? "");

function grossBoxValue(html: string): number | null {
  const m = html.match(/<tr class="sum-gross">[\s\S]*?<td class="sumval">([\s\S]*?)<\/td>/);
  return m ? Number(toAscii(m[1])) : null;
}
function labelled(html: string, label: string): number | null {
  const m = html.match(new RegExp(`<td class="sumlbl[^"]*"[^>]*>${label}[\\s\\S]*?<td class="sumval[^"]*">([\\s\\S]*?)</td>`));
  return m ? Number(toAscii(m[1])) : null;
}

const product = {
  id: "p1", name: "Tile", size: "12x12", company: "Kungfu",
  sqft_per_piece: 1, pcs_per_carton: 10, stock_pieces: 100,
  purchase_price_per_piece: 40, sell_price_per_piece: 50,
};
const productMap = new Map([[product.id, product]]);

const sale = {
  id: "s1", invoice_no: "3001", customer_id: "c1",
  total_amount: 500, paid_amount: 100, due_amount: 600,
  items: [{ productId: "p1", pieces: 10, totalPrice: 500, cartons: 1, feet: 10, rate: 50 }],
  is_returned: false, returned_amount: 0, sale_date: "2026-10-01",
  labor: 0, transport: 0, discount: 0,
};
const saleNoPrev = { ...sale, due_amount: 400 };
const customer = { id: "c1", name: "Rahim", mobile: "01700000000", address: "Tangail", due_amount: 600 };

describe("সর্বমোট box in bill memo", () => {
  test("shows total money plus previous due in its own box", () => {
    const html = buildInvoiceHtml(sale as any, customer as any, productMap as any, { preview: true });
    const total = labelled(html, "মোট টাকাঃ");
    const prev = labelled(html, "পূর্বের বাকিঃ");
    const gross = grossBoxValue(html);
    expect(total).toBe(500);
    expect(prev).toBe(200);
    expect(gross).toBe(700);
    expect(gross).toBe((total ?? 0) + (prev ?? 0));
  });

  test("box is omitted when there is no previous due", () => {
    const html = buildInvoiceHtml(saleNoPrev as any, { ...customer, due_amount: 400 } as any, productMap as any, { preview: true });
    expect(grossBoxValue(html)).toBeNull();
    expect(html).not.toContain("সর্বমোট");
  });

  test("box includes discount added back to the money total", () => {
    const discounted = { ...sale, discount: 50 };
    const html = buildInvoiceHtml(discounted as any, customer as any, productMap as any, { preview: true });
    const total = labelled(html, "মোট টাকাঃ");
    const prev = labelled(html, "পূর্বের বাকিঃ");
    expect(total).toBe(550);
    expect(prev).toBe(200);
    expect(grossBoxValue(html)).toBe(750);
  });
});
