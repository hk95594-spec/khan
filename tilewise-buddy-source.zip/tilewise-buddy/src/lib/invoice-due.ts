type InvoiceAmounts = {
  total_amount: number;
  paid_amount: number;
  due_amount: number;
};

// Saved due can already include the previous balance added to this memo.
export function invoicePreviousDue(sale: InvoiceAmounts, customerDue = 0): number {
  const includedDue = Math.max(0, Number(sale.due_amount) + Number(sale.paid_amount) - Number(sale.total_amount));
  if (includedDue > 0) return includedDue;
  return Math.max(0, Number(customerDue) - Number(sale.due_amount));
}