export type ProfitItem = {
  productId: string; pieces: number; totalPrice: number; feet?: number;
  costPerSqft?: number; costFeet?: number;
};
export type ProfitSale = {
  invoice_no: string; total_amount: number; is_returned: boolean;
  returned_amount: number; items: ProfitItem[];
};
export type ProfitProduct = {
  id: string; name: string; purchase_price_per_piece: number;
  sqft_per_piece?: number; size?: string | null;
};

const number = (value: unknown) => Number.isFinite(Number(value)) ? Number(value) : 0;

export function productFeetPerPiece(product?: ProfitProduct) {
  const match = product?.size?.match(/(\d+(?:\.\d+)?)\s*[x×*X]\s*(\d+(?:\.\d+)?)/);
  if (match) return Number(match[1]) * Number(match[2]) / 144;
  return number(product?.sqft_per_piece) || 1;
}

// PurchaseProduct stores its purchase rate per square foot, despite the column name.
export function calculateInvoiceProfit(sale: ProfitSale, products: Record<string, ProfitProduct>) {
  const returnMemo = /^RET-/i.test(sale.invoice_no);
  const total = number(sale.total_amount);
  const returned = sale.is_returned ? number(sale.returned_amount) : 0;
  const netSale = returnMemo ? -returned : total - returned;
  // Legacy original invoices store only a return amount, not item quantities.
  const retained = !returnMemo && sale.is_returned && total > 0
    ? Math.max(0, Math.min(1, 1 - returned / total)) : 1;
  const sign = returnMemo ? -1 : retained;
  let estimatedCost = false;
  const rows = (sale.items || []).map(item => {
    const product = products[item.productId];
    const hasSnapshot = item.costPerSqft !== undefined && Number.isFinite(Number(item.costPerSqft));
    if (!hasSnapshot) estimatedCost = true;
    const feet = item.costFeet !== undefined ? number(item.costFeet)
      : item.feet !== undefined ? number(item.feet)
      : number(item.pieces) * productFeetPerPiece(product);
    const cost = feet * (hasSnapshot ? number(item.costPerSqft) : number(product?.purchase_price_per_piece)) * sign;
    const revenue = number(item.totalPrice) * sign;
    return { name: product?.name || "—", pieces: number(item.pieces), unit: number(item.pieces) ? number(item.totalPrice) / number(item.pieces) : 0, sale: revenue, cogs: cost, profit: revenue - cost };
  });
  const cogs = rows.reduce((sum, row) => sum + row.cogs, 0);
  const adjustment = netSale - rows.reduce((sum, row) => sum + row.sale, 0);
  const estimatedReturn = !returnMemo && returned > 0 && retained > 0;
  return { sale: netSale, cogs, profit: netSale - cogs, rows, adjustment, estimated: estimatedCost || estimatedReturn || returnMemo, returnMemo };
}