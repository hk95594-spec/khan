// Opens WhatsApp Web (web.whatsapp.com) on desktop, wa.me on mobile.
export function openWhatsApp(phone: string, text?: string) {
  const digits = (phone || "").replace(/\D/g, "");
  const isMobile = typeof navigator !== "undefined" && /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  const encoded = text ? encodeURIComponent(text) : "";
  let url: string;
  if (isMobile) {
    url = digits
      ? `https://wa.me/${digits}${text ? `?text=${encoded}` : ""}`
      : `https://wa.me/?text=${encoded}`;
  } else {
    url = digits
      ? `https://web.whatsapp.com/send?phone=${digits}${text ? `&text=${encoded}` : ""}`
      : `https://web.whatsapp.com/send?text=${encoded}`;
  }
  window.open(url, "_blank");
}
