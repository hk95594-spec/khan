/// <reference types="bun" />
import { describe, expect, test } from "bun:test";
import { invoicePreviousDue } from "./invoice-due";

describe("previous due in invoice preview", () => {
  test("recovers previous due already included in the saved memo balance", () => {
    expect(invoicePreviousDue({ total_amount: 500, paid_amount: 100, due_amount: 600 }, 600)).toBe(200);
  });
  test("no previous balance produces zero", () => {
    expect(invoicePreviousDue({ total_amount: 500, paid_amount: 100, due_amount: 400 }, 400)).toBe(0);
  });
  test("an included previous balance is unchanged by later customer balance changes", () => {
    expect(invoicePreviousDue({ total_amount: 500, paid_amount: 100, due_amount: 600 }, 0)).toBe(200);
  });
  test("preserves separate customer balance for memos without an included balance", () => {
    expect(invoicePreviousDue({ total_amount: 500, paid_amount: 100, due_amount: 400 }, 600)).toBe(200);
  });
});