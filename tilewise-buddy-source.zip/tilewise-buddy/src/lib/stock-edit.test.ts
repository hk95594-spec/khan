/// <reference types="bun" />
import { describe, expect, test } from "bun:test";
import { stockEditPatch } from "./stock-edit";

const product = { id: "a", name: "Tile", company: "Company", stock_pieces: 27, pcs_per_carton: 10, sqft_per_piece: 2, purchase_price_per_piece: 50 };
describe("inline stock editing", () => {
  test("Feet updates pieces using the product conversion", () => {
    expect(stockEditPatch([product], "feet", "60").patch).toEqual({ stock_pieces: 30 });
  });
  test("Carton retains loose pieces", () => {
    expect(stockEditPatch([product], "cartons", "3").patch).toEqual({ stock_pieces: 37 });
  });
  test("Pcs retains complete cartons", () => {
    expect(stockEditPatch([product], "pcs", "5").patch).toEqual({ stock_pieces: 25 });
  });
  test("Last Purchase Price saves the entered price", () => {
    expect(stockEditPatch([product], "purchase", "55.5").patch).toEqual({ purchase_price_per_piece: 55.5 });
  });
  test("Name updates all grouped products", () => {
    expect(stockEditPatch([product, { ...product, id: "b" }], "name", "New Tile")).toEqual({ ids: ["a", "b"], patch: { name: "New Tile" } });
  });
  test("Company updates without requiring a separate save action", () => {
    expect(stockEditPatch([product], "company", "New Company").patch).toEqual({ company: "New Company" });
  });
  test("Grouped quantities apply the delta only once", () => {
    expect(stockEditPatch([product, { ...product, id: "b", stock_pieces: 3 }], "feet", "80")).toEqual({ ids: ["a"], patch: { stock_pieces: 37 } });
  });
  test("Invalid quantities cannot overwrite stock", () => {
    expect(() => stockEditPatch([product], "pcs", "-1")).toThrow();
    expect(() => stockEditPatch([product], "cartons", "1.5")).toThrow();
    expect(() => stockEditPatch([product], "feet", "")).toThrow();
  });
});