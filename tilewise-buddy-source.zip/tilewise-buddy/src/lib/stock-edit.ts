export type StockField = "name" | "company" | "feet" | "cartons" | "pcs" | "purchase";
export type EditableStock = {
  id: string; name: string; company: string | null; stock_pieces: number;
  pcs_per_carton: number; sqft_per_piece: number; purchase_price_per_piece: number;
};
export type StockPatch = Partial<Pick<EditableStock, "name" | "company" | "stock_pieces" | "purchase_price_per_piece">>;

export function stockEditPatch(list: EditableStock[], field: StockField, value: string): { ids: string[]; patch: StockPatch } {
  const first = list[0];
  if (!first) throw new Error("পণ্যটি পাওয়া যায়নি");
  const ids = list.map((p) => p.id);
  if (field === "name") {
    if (!value.trim()) throw new Error("পণ্যের নাম খালি রাখা যাবে না");
    return { ids, patch: { name: value.trim() } };
  }
  if (field === "company") return { ids, patch: { company: value.trim() || null } };
  const number = Number(value);
  if (!value.trim() || !Number.isFinite(number) || number < 0) throw new Error("সঠিক শূন্য বা ধনাত্মক সংখ্যা দিন");
  if (field === "purchase") return { ids, patch: { purchase_price_per_piece: number } };
  const perCarton = Number(first.pcs_per_carton) || 1;
  const total = list.reduce((sum, p) => sum + Number(p.stock_pieces), 0);
  const cartons = Math.floor(total / perCarton);
  const loose = total - cartons * perCarton;
  let target: number;
  if (field === "feet") {
    if (!(Number(first.sqft_per_piece) > 0)) throw new Error("আগে পণ্যের প্রতি পিসের ফিট ঠিক করুন");
    target = Math.round(number / Number(first.sqft_per_piece));
  } else {
    if (!Number.isInteger(number)) throw new Error("কার্টন ও পিস পূর্ণ সংখ্যা হতে হবে");
    target = field === "cartons" ? number * perCarton + loose : cartons * perCarton + number;
  }
  // Change only one member by the aggregate delta, preserving every other member's stock.
  const member = list.reduce((best, p) => Number(p.stock_pieces) > Number(best.stock_pieces) ? p : best, first);
  if (Number(member.stock_pieces) + target - total < 0) {
    throw new Error("একই নামে একাধিক পণ্য আছে; স্টক কমাতে পৃথক পণ্যের Edit ব্যবহার করুন");
  }
  return { ids: [member.id], patch: { stock_pieces: Number(member.stock_pieces) + target - total } };
}