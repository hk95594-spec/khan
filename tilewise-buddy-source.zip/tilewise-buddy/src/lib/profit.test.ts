/// <reference types="bun" />
import { describe, expect, test } from "bun:test";
import { calculateInvoiceProfit } from "./profit";

const products = { tile: { id: "tile", name: "Tile", purchase_price_per_piece: 40, sqft_per_piece: 1, size: "12×24" } };
const sale = { invoice_no: "3002", total_amount: 495, is_returned: false, returned_amount: 0, items: [{ productId: "tile", pieces: 5, feet: 10, totalPrice: 500, costPerSqft: 30, costFeet: 10 }] };
describe("profit accounting", () => {
  test("500 merchandise less 5 discount gives 495 revenue, with discount counted once", () => {
    const result = calculateInvoiceProfit(sale, products);
    expect(result.sale).toBe(495);
    expect(result.cogs).toBe(300);
    expect(result.profit).toBe(195);
    expect(result.adjustment).toBe(-5);
  });
  test("later purchase rate changes do not alter snapshotted sale cost", () => {
    expect(calculateInvoiceProfit(sale, { tile: { ...products.tile, purchase_price_per_piece: 99 } }).cogs).toBe(300);
  });
  test("separate return memo reverses both revenue and returned stock cost", () => {
    const result = calculateInvoiceProfit({ ...sale, invoice_no: "RET-1", is_returned: true, returned_amount: 495 }, products);
    expect(result.sale).toBe(-495);
    expect(result.cogs).toBe(-300);
    expect(result.profit).toBe(-195);
    expect(calculateInvoiceProfit(sale, products).profit + result.profit).toBe(0);
  });
  test("fully returned original invoice has zero remaining revenue and COGS", () => {
    const result = calculateInvoiceProfit({ ...sale, is_returned: true, returned_amount: 495 }, products);
    expect(result.sale).toBe(0);
    expect(result.cogs).toBe(0);
  });
  test("legacy cost uses saved feet and is marked estimated", () => {
    const result = calculateInvoiceProfit({ ...sale, items: [{ productId: "tile", pieces: 5, feet: 10, totalPrice: 500 }] }, products);
    expect(result.cogs).toBe(400);
    expect(result.estimated).toBe(true);
  });
  test("missing feet uses tile size, not stale stored square-foot conversion", () => {
    expect(calculateInvoiceProfit({ ...sale, items: [{ productId: "tile", pieces: 5, totalPrice: 500 }] }, products).cogs).toBe(400);
  });
  test("customer charges reconcile detail totals with invoice total", () => {
    const result = calculateInvoiceProfit({ ...sale, total_amount: 525 }, products);
    expect(result.adjustment).toBe(25);
    expect(result.rows.reduce((sum, row) => sum + row.profit, 0) + result.adjustment).toBe(result.profit);
  });
  test("unlinked partial returns remain visibly estimated", () => {
    const result = calculateInvoiceProfit({ ...sale, is_returned: true, returned_amount: 99 }, products);
    expect(result.sale).toBe(396);
    expect(result.cogs).toBe(240);
    expect(result.estimated).toBe(true);
  });
  test("period net profit subtracts expenses once after return reversal", () => {
    const returned = calculateInvoiceProfit({ ...sale, invoice_no: "RET-2", is_returned: true, total_amount: 99, returned_amount: 99, items: [{ ...sale.items[0], pieces: 1, feet: 2, costFeet: 2, totalPrice: 100 }] }, products);
    expect(calculateInvoiceProfit(sale, products).profit + returned.profit - 20).toBe(136);
  });
});