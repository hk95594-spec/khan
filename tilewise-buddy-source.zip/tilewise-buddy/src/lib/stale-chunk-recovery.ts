// Auto-recover from stale dynamic-import failures after a new preview/deploy.
// When the browser holds an old HTML referencing chunk URLs that no longer
// exist on the server, dynamic imports reject with messages like
// "Failed to fetch dynamically imported module" or
// "error loading dynamically imported module". These rejections often
// happen at the framework boundary (e.g. virtual:tanstack-start-client-entry)
// before any React error boundary mounts, so we listen at the window level.

if (typeof window !== "undefined") {
  const STORAGE_KEY = "__chunk_reload_at";
  const COOLDOWN_MS = 10_000;

  const isStaleChunkMessage = (msg: string) =>
    msg.includes("Failed to fetch dynamically imported module") ||
    msg.includes("Importing a module script failed") ||
    msg.includes("error loading dynamically imported module") ||
    msg.includes("Loading chunk ") ||
    msg.includes("Loading CSS chunk ");

  const maybeReload = (msg: string) => {
    if (!isStaleChunkMessage(msg)) return;
    try {
      const last = Number(sessionStorage.getItem(STORAGE_KEY) || "0");
      if (Date.now() - last < COOLDOWN_MS) return;
      sessionStorage.setItem(STORAGE_KEY, String(Date.now()));
    } catch {
      // sessionStorage unavailable — reload anyway
    }
    window.location.reload();
  };

  window.addEventListener("unhandledrejection", (event) => {
    const reason = (event as PromiseRejectionEvent).reason;
    const msg =
      (reason && typeof reason === "object" && "message" in reason
        ? String((reason as { message?: unknown }).message ?? "")
        : String(reason ?? ""));
    maybeReload(msg);
  });

  window.addEventListener("error", (event) => {
    maybeReload(String((event as ErrorEvent).message ?? ""));
  });
}

export {};
