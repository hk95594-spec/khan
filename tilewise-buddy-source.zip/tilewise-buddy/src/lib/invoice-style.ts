// Shared invoice CSS + logo. Locked so every invoice (Sale form + Sale History) renders identically on A5.
import logoAsset from "@/assets/alam-tiles-logo.asset.json";
const logoUrl = typeof window !== "undefined" ? `${window.location.origin}${logoAsset.url}` : logoAsset.url;
export const INVOICE_LOGO_SVG = `<img src="${logoUrl}" alt="Alam Tiles" style="width:100%;height:100%;object-fit:contain;" />`;

export const INVOICE_CSS = `
  @page { size: A5 portrait; margin: 5mm; }
  * { box-sizing: border-box; }
  html, body { width: 148mm; margin: 0; padding: 0; }
  body { font-family: "SolaimanLipi", "Noto Sans Bengali", "Kalpurush", "Siyam Rupali", Arial, sans-serif; color:#000; font-size:12px; padding: 0; }
  .wrap { width: 138mm; max-width: 138mm; margin: 0 auto; padding: 5mm; }
  table { table-layout: fixed; word-wrap: break-word; }
  .items { table-layout: fixed; }
  .meta { table-layout: fixed; }
  img, svg { max-width: 100%; }

  /* Header */
  .top { display:flex; justify-content:space-between; align-items:flex-start; padding: 0; }
  .logo { width:90px; height:90px; display:flex; align-items:center; justify-content:center; }
  .logo svg { width:100%; height:100%; }
  .center { text-align:center; flex:1; }
  .center .bil { font-size:14px; margin-bottom:1px; }
  .center .name { font-size:40px; font-weight:700; line-height:1.1; margin:1px 0; }
  .center .en { font-size:28px; letter-spacing:2px; font-weight:900; }
  .center .tagline { font-size:16px; font-weight:400; }
  .right { text-align:right; font-size:15px; line-height:1.35; }
  .right .addr { font-size:15px; }
  .right .mob { font-size:15px; }
  .tag { text-align:center; font-size:16px; font-weight:700; padding: 1mm; line-height:1.2; }

  /* Customer / Meta */
  table { width:100%; border-collapse: collapse; }
  .meta td { border:1px solid #000; padding: 1px 4px; font-size:14px; }
  .meta .cust-name { font-size:13px; font-weight:700; }
  .meta .lbl { width:18mm; font-weight:700; }
  .meta .date-lbl { width:14mm; font-weight:700; }
  .meta .date-val { width:26mm; }
  .billno { text-align:center; border:0.5px solid #888; border-top:0; padding:3px; font-weight:700; font-size:14px; }

  /* Items table */
  .items { border-collapse: collapse; width:100%; }
  .items th, .items td { border:1px solid #000; padding: 2px 4px; }
  .items th { background:#e0e0e0; font-weight:700; text-align:center; font-size:17px; line-height:1.15; height:22px; }
  .items td { font-size:15px; height:16px; }
  .items td.c { text-align:center; }
  .items td.r { text-align:center; }
  .items td:nth-child(2) { width: 45mm; text-align:center; }
  .items td.shade, .items tr.shade-row td { background:#e0e0e0; }
  .billno { background:#e0e0e0; }

  /* Summary */
  .sumlbl { text-align:center; font-weight:700; padding-right:4px; font-size:15px; }
  .sumval { text-align:center; width:24mm; font-weight:700; font-size:15px; }
  .sum-net .sumlbl, .sum-net .sumval,
  .sum-due .sumlbl, .sum-due .sumval { font-size:15px; font-weight:700; }
  .sum-gross td { background:#e0e0e0; border-top:2px solid #000; border-bottom:2px solid #000; }
  .sum-gross .sumlbl, .sum-gross .sumval { font-size:16px; font-weight:700; }

  /* Amount in words */
  .katha { padding: 3px 5px; font-size:14px; }
  .katha b { font-size:14px; font-weight:700; }

  /* Footer */
  .foot-note { text-align:center; font-size:12px; margin-top:1mm; }
  .sign { display:flex; justify-content:space-between; margin-top:0.5mm; font-size:14px; }
  .sign .hasan { font-size:14px; font-weight:700; }
  .page { text-align:center; font-size:10px; margin-top:1mm; }

  .page-break { page-break-after: always; break-after: page; }
  .page-break:last-child { page-break-after: auto; break-after: auto; }

  @media print { @page { size: A5 portrait; margin: 5mm; } .no-print { display:none; } html, body { width:138mm; margin:0; padding:0; overflow:visible; } body { -webkit-print-color-adjust: exact; padding:0; } .wrap { width:138mm; max-width:138mm; min-height:0 !important; height:auto !important; max-height:none !important; margin:0; padding:0; page-break-inside: avoid; break-inside: avoid; overflow:visible; } .page-break { page-break-after: always; break-after: page; } .page-break:last-child { page-break-after: auto; break-after: auto; } tr, td, th { page-break-inside: avoid; } }
`;
