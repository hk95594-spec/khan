export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      cash_transactions: {
        Row: {
          amount: number
          created_at: string
          id: string
          reason: string | null
          trans_date: string
          type: string
          user_id: string
        }
        Insert: {
          amount?: number
          created_at?: string
          id?: string
          reason?: string | null
          trans_date?: string
          type: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          reason?: string | null
          trans_date?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      categories: {
        Row: {
          created_at: string
          id: string
          name: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          user_id?: string
        }
        Relationships: []
      }
      companies: {
        Row: {
          created_at: string
          id: string
          name: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          user_id?: string
        }
        Relationships: []
      }
      costs: {
        Row: {
          amount: number
          cost_date: string
          created_at: string
          description: string
          id: string
          user_id: string
        }
        Insert: {
          amount?: number
          cost_date?: string
          created_at?: string
          description: string
          id?: string
          user_id: string
        }
        Update: {
          amount?: number
          cost_date?: string
          created_at?: string
          description?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      customers: {
        Row: {
          address: string | null
          created_at: string
          due_amount: number
          id: string
          mobile: string | null
          name: string
          user_id: string
        }
        Insert: {
          address?: string | null
          created_at?: string
          due_amount?: number
          id?: string
          mobile?: string | null
          name: string
          user_id: string
        }
        Update: {
          address?: string | null
          created_at?: string
          due_amount?: number
          id?: string
          mobile?: string | null
          name?: string
          user_id?: string
        }
        Relationships: []
      }
      due_payments: {
        Row: {
          created_at: string
          customer_id: string
          id: string
          kind: string
          memo_no: string
          paid_amount: number
          previous_due: number
          reason: string | null
          remaining_due: number
          user_id: string
        }
        Insert: {
          created_at?: string
          customer_id: string
          id?: string
          kind?: string
          memo_no: string
          paid_amount?: number
          previous_due?: number
          reason?: string | null
          remaining_due?: number
          user_id: string
        }
        Update: {
          created_at?: string
          customer_id?: string
          id?: string
          kind?: string
          memo_no?: string
          paid_amount?: number
          previous_due?: number
          reason?: string | null
          remaining_due?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "due_payments_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          category: string | null
          company: string | null
          created_at: string
          id: string
          image_path: string | null
          min_label_feet: number
          name: string
          pcs_per_carton: number
          product_code: string | null
          purchase_price_per_piece: number
          sell_price_per_piece: number
          size: string | null
          sqft_per_piece: number
          stock_pieces: number
          user_id: string
        }
        Insert: {
          category?: string | null
          company?: string | null
          created_at?: string
          id?: string
          image_path?: string | null
          min_label_feet?: number
          name: string
          pcs_per_carton?: number
          product_code?: string | null
          purchase_price_per_piece?: number
          sell_price_per_piece?: number
          size?: string | null
          sqft_per_piece?: number
          stock_pieces?: number
          user_id: string
        }
        Update: {
          category?: string | null
          company?: string | null
          created_at?: string
          id?: string
          image_path?: string | null
          min_label_feet?: number
          name?: string
          pcs_per_carton?: number
          product_code?: string | null
          purchase_price_per_piece?: number
          sell_price_per_piece?: number
          size?: string | null
          sqft_per_piece?: number
          stock_pieces?: number
          user_id?: string
        }
        Relationships: []
      }
      purchases: {
        Row: {
          cost_per_piece: number
          created_at: string
          id: string
          pieces: number
          product_id: string | null
          purchase_date: string
          supplier_id: string | null
          total_cost: number
          user_id: string
        }
        Insert: {
          cost_per_piece?: number
          created_at?: string
          id?: string
          pieces?: number
          product_id?: string | null
          purchase_date?: string
          supplier_id?: string | null
          total_cost?: number
          user_id: string
        }
        Update: {
          cost_per_piece?: number
          created_at?: string
          id?: string
          pieces?: number
          product_id?: string | null
          purchase_date?: string
          supplier_id?: string | null
          total_cost?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "purchases_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchases_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      sales: {
        Row: {
          created_at: string
          customer_id: string | null
          discount: number
          due_amount: number
          id: string
          invoice_no: string
          is_returned: boolean
          items: Json
          labor: number
          paid_amount: number
          returned_amount: number
          sale_date: string
          total_amount: number
          transport: number
          user_id: string
        }
        Insert: {
          created_at?: string
          customer_id?: string | null
          discount?: number
          due_amount?: number
          id?: string
          invoice_no: string
          is_returned?: boolean
          items?: Json
          labor?: number
          paid_amount?: number
          returned_amount?: number
          sale_date?: string
          total_amount?: number
          transport?: number
          user_id: string
        }
        Update: {
          created_at?: string
          customer_id?: string | null
          discount?: number
          due_amount?: number
          id?: string
          invoice_no?: string
          is_returned?: boolean
          items?: Json
          labor?: number
          paid_amount?: number
          returned_amount?: number
          sale_date?: string
          total_amount?: number
          transport?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sales_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      stock_cuts: {
        Row: {
          created_at: string
          cut_date: string
          id: string
          pieces: number
          product_id: string | null
          reason: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          cut_date?: string
          id?: string
          pieces?: number
          product_id?: string | null
          reason?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          cut_date?: string
          id?: string
          pieces?: number
          product_id?: string | null
          reason?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "stock_cuts_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      suppliers: {
        Row: {
          address: string | null
          advance: number
          company: string | null
          created_at: string
          id: string
          mobile: string | null
          name: string
          total_due: number
          user_id: string
        }
        Insert: {
          address?: string | null
          advance?: number
          company?: string | null
          created_at?: string
          id?: string
          mobile?: string | null
          name: string
          total_due?: number
          user_id: string
        }
        Update: {
          address?: string | null
          advance?: number
          company?: string | null
          created_at?: string
          id?: string
          mobile?: string | null
          name?: string
          total_due?: number
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
