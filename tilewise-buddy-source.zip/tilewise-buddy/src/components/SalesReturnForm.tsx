import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { X } from "lucide-react";
import { INVOICE_CSS, INVOICE_LOGO_SVG } from "@/lib/invoice-style";

type Product = {
  id: string; name: string; size: string | null; company: string | null; category: string | null;
  sqft_per_piece: number; pcs_per_carton: number; stock_pieces: number;
  purchase_price_per_piece: number; sell_price_per_piece: number;
};
type Customer = { id: string; name: string; mobile: string | null; address: string | null; due_amount: number };

type Row = {
  productId: string;
  search: string;
  showList: boolean;
  sellQ: number;       // Sell Q / Feet (display)
  sellPrice: number;   // Sell Price per piece
  carton: number;
  pcs: number;
  returnQ: number;     // Return Q / Feet
  total: number;
};

function emptyRow(): Row {
  return { productId: "", search: "", showList: false, sellQ: 0, sellPrice: 0, carton: 0, pcs: 0, returnQ: 0, total: 0 };
}

export default function SalesReturnForm({
  customer, code, products, userId, onClose, refresh,
}: {
  customer: Customer;
  code: string;
  products: Product[];
  userId: string;
  onClose: () => void;
  refresh: () => void;
}) {
  const [rows, setRows] = useState<Row[]>([emptyRow(), emptyRow(), emptyRow(), emptyRow(), emptyRow(), emptyRow(), emptyRow()]);
  const [discount, setDiscount] = useState<number>(0);
  const [paid, setPaid] = useState<number>(0);
  const [saving, setSaving] = useState(false);

  const productMap = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);

  function updateRow(i: number, patch: Partial<Row>) {
    setRows((rs) => rs.map((r, idx) => {
      if (idx !== i) return r;
      const merged = { ...r, ...patch };
      // recompute pieces from carton+pcs if those changed; total from pieces*sellPrice
      const p = productMap.get(merged.productId);
      const pcsPerCarton = p?.pcs_per_carton || 1;
      const pieces = (Number(merged.carton) || 0) * pcsPerCarton + (Number(merged.pcs) || 0);
      const sqftPerPiece = p?.sqft_per_piece || 1;
      // returnQ in feet = pieces * sqftPerPiece (if not manually overridden by returnQ patch)
      if (!("returnQ" in patch)) merged.returnQ = Number((pieces * sqftPerPiece).toFixed(2));
      merged.total = Number(((Number(merged.returnQ) || 0) * (Number(merged.sellPrice) || 0)).toFixed(2));
      return merged;
    }));
  }

  function pickProduct(i: number, p: Product) {
    setRows((rs) => rs.map((r, idx) => idx === i ? {
      ...r,
      productId: p.id,
      search: `${p.name}${p.size ? " " + p.size : ""}`,
      showList: false,
      sellQ: 0,
      sellPrice: Number(p.sell_price_per_piece) || 0,
      carton: 0, pcs: 0, returnQ: 0, total: 0,
    } : r));
  }

  function removeRow(i: number) {
    setRows((rs) => rs.length > 1 ? rs.filter((_, idx) => idx !== i) : [emptyRow()]);
  }
  function addRow() { setRows((rs) => [...rs, emptyRow()]); }
  function clearAll() {
    setRows([emptyRow(), emptyRow(), emptyRow(), emptyRow(), emptyRow(), emptyRow(), emptyRow()]);
    setDiscount(0); setPaid(0);
  }

  const subtotal = rows.reduce((s, r) => s + (r.productId ? Number(r.total) : 0), 0);
  const grandTotal = Math.max(0, subtotal - (Number(discount) || 0));
  const currentDue = Number(customer.due_amount) || 0;
  const dueAfter = Math.max(0, currentDue - grandTotal - (Number(paid) || 0));

  const toBn = (s: string | number) => String(s).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
  function numToBnWords(num: number): string {
    num = Math.round(num);
    if (num === 0) return "শূন্য";
    const ones = ["", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়", "দশ", "এগারো", "বারো", "তেরো", "চৌদ্দ", "পনেরো", "ষোলো", "সতেরো", "আঠারো", "ঊনিশ", "বিশ", "একুশ", "বাইশ", "তেইশ", "চব্বিশ", "পঁচিশ", "ছাব্বিশ", "সাতাশ", "আঠাশ", "ঊনত্রিশ", "ত্রিশ", "একত্রিশ", "বত্রিশ", "তেত্রিশ", "চৌত্রিশ", "পঁইত্রিশ", "ছত্রিশ", "সাঁইত্রিশ", "আটত্রিশ", "ঊনচল্লিশ", "চল্লিশ", "একচল্লিশ", "বিয়াল্লিশ", "তেতাল্লিশ", "চুয়াল্লিশ", "পঁইতাল্লিশ", "ছিচল্লিশ", "সাতচল্লিশ", "আটচল্লিশ", "ঊনপঞ্চাশ", "পঞ্চাশ", "একান্ন", "বায়ান্ন", "তিপ্পান্ন", "চুয়ান্ন", "পঞ্চান্ন", "ছাপ্পান্ন", "সাতান্ন", "আটান্ন", "ঊনষাট", "ষাট", "একষট্টি", "বাষট্টি", "তেষট্টি", "চৌষট্টি", "পঁইষট্টি", "ছিষট্টি", "সাতষট্টি", "আটষট্টি", "ঊনসত্তর", "সত্তর", "একাত্তর", "বাহাত্তর", "তিয়াত্তর", "চুয়াত্তর", "পঁচাত্তর", "ছিয়াত্তর", "সাতাত্তর", "আটাত্তর", "ঊনআশি", "আশি", "একাশি", "বিরাশি", "তিরাশি", "চুরাশি", "পঁচাশি", "ছিয়াশি", "সাতাশি", "আটাশি", "ঊননব্বই", "নব্বই", "একানব্বই", "বিরানব্বই", "তিরানব্বই", "চুরানব্বই", "পঁচানব্বই", "ছিয়ানব্বই", "সাতানব্বই", "আটানব্বই", "নিরানব্বই"];
    const below1000 = (n: number): string => {
      if (n < 100) return ones[n];
      const h = Math.floor(n / 100), r = n % 100;
      return ones[h] + "শ" + (r ? " " + ones[r] : "");
    };
    const parts: string[] = [];
    const crore = Math.floor(num / 10000000); num %= 10000000;
    const lakh = Math.floor(num / 100000); num %= 100000;
    const thousand = Math.floor(num / 1000); num %= 1000;
    if (crore) parts.push(below1000(crore) + " কোটি");
    if (lakh) parts.push(below1000(lakh) + " লক্ষ");
    if (thousand) parts.push(below1000(thousand) + " হাজার");
    if (num) parts.push(below1000(num));
    return parts.join(" ");
  }

  function printReturnInvoice(invoiceNo: string, filled: Row[]) {
    const dateStr = new Date().toLocaleDateString("en-GB");
    const invNum = invoiceNo.replace(/\D/g, "").slice(-4) || invoiceNo;
    const itemRows = filled.map((r, i) => {
      const p = productMap.get(r.productId);
      return `<tr>
        <td class="c">${toBn(i + 1)}</td>
        <td>${p ? p.name + (p.size ? " " + p.size : "") : ""}</td>
        <td class="c">${toBn(Number(r.returnQ).toFixed(0))}</td>
        <td class="c">${toBn(r.carton || 0)}</td>
        <td class="c">${toBn(r.pcs || 0)}</td>
        <td class="c">${toBn(Number(r.sellPrice).toFixed(0))}</td>
        <td class="r">${toBn(Number(r.total).toFixed(0))}</td>
      </tr>`;
    }).join("");
    const discountAmt = Number(discount) || 0;
    const paidAmt = Number(paid) || 0;
    const totalFeet = filled.reduce((sum, r) => sum + Number(r.returnQ || 0), 0);
    const summaryRowsCount = 2 + (discountAmt > 0 ? 1 : 0) + (currentDue > 0 ? 1 : 0) + (paidAmt > 0 ? 1 : 0) + (dueAfter > 0 ? 1 : 0);
    const emptyCount = Math.max(0, 11 - summaryRowsCount - filled.length);
    const emptyHtml = Array.from({ length: emptyCount }).map(() =>
      `<tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>`).join("");
    const discountHtml = discountAmt > 0 ? `<tr class="shade-row"><td colspan="4"></td><td class="sumlbl" colspan="2">ছাড়ঃ</td><td class="sumval">${toBn(discountAmt.toFixed(0))}</td></tr>` : "";
    const currentDueHtml = currentDue > 0 ? `<tr class="shade-row"><td colspan="4"></td><td class="sumlbl" colspan="2">পূর্বের বাকিঃ</td><td class="sumval">${toBn(currentDue.toFixed(0))}</td></tr>` : "";
    const paidHtml = paidAmt > 0 ? `<tr class="shade-row"><td colspan="4"></td><td class="sumlbl" colspan="2">জমাঃ</td><td class="sumval">${toBn(paidAmt.toFixed(0))}</td></tr>` : "";
    const dueHtml = dueAfter > 0 ? `<tr class="sum-due shade-row"><td colspan="4"></td><td class="sumlbl" colspan="2">বাকিঃ</td><td class="sumval">${toBn(dueAfter.toFixed(0))}</td></tr>` : "";
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${invoiceNo}</title>
<style>${INVOICE_CSS}
@media print { .no-print { display:none !important; } }
</style></head><body>
<div class="wrap">
  <div class="top">
    <div class="logo">${INVOICE_LOGO_SVG}</div>
    <div class="center">
      <div class="bil">বিল মেমো (ফেরত)</div>
      <div class="name">আলম টাইলস</div>
      <div class="en">ALAM TILES</div>
    </div>
    <div class="right">
      <div>মোবাইলঃ</div>
      <div>হাসানঃ 0175-7770796</div>
      <div>0162-1176784</div>
      <div>বড় কালি বাড়ি রোড,</div>
      <div>টাংগাইল।</div>
    </div>
  </div>
  <div class="tag">সকল প্রকার টাইলস, মার্বেল পাথর, সিনারী, বর্ডার সামগ্রী পাইকারী ও খুচরা বিক্রেতা<br>এবং সরবরাহকারক। ডিলারঃ কুংফু সিরামিক্স, তুষার সিরামিক্স।</div>
  <table class="meta">
    <tr><td class="lbl">নামঃ</td><td>${customer.name || ""}</td><td class="date-lbl">তারিখঃ</td><td class="date-val">${toBn(dateStr)}</td></tr>
    <tr><td class="lbl">মোবাইলঃ</td><td colspan="3">${toBn(customer.mobile || "")}</td></tr>
    <tr><td class="lbl">ঠিকানাঃ</td><td colspan="3">${customer.address || ""}</td></tr>
  </table>
  <div class="billno">ফেরত বিল নং ${toBn(invNum)}</div>
  <table class="items" style="table-layout:fixed">
    <colgroup>
      <col style="width:8mm" /><col style="width:45mm" /><col style="width:14mm" /><col style="width:14mm" /><col style="width:10mm" /><col style="width:10mm" /><col style="width:22mm" />
    </colgroup>
    <thead><tr>
      <th>নং</th><th>বিবরণ</th><th>ফুট</th>
      <th>কাটুন</th><th>পিছ</th>
      <th>দর</th><th>মোট টাকা</th>
    </tr></thead>
    <tbody>
      ${itemRows}
      ${emptyHtml}
      <tr class="sum-net"><td></td><td class="sumlbl">মোট ফিটঃ</td><td class="c">${toBn(totalFeet.toFixed(2))}</td><td></td><td class="sumlbl shade" colspan="2">মোট টাকাঃ</td><td class="sumval shade">${toBn(grandTotal.toFixed(0))}</td></tr>
      <tr class="shade-row"><td colspan="4" class="katha">কথায়: ${numToBnWords(grandTotal)} টাকা মাত্র</td><td class="sumlbl" colspan="2">ফেরতঃ</td><td class="sumval">${toBn(grandTotal.toFixed(0))}</td></tr>
      ${discountHtml}
      ${currentDueHtml}
      ${paidHtml}
      ${dueHtml}
    </tbody>
  </table>
  <div class="foot-note">এই বিলটি ফেরত হিসেবে গণ্য — অভিযোগের জন্য মূল বিলের সাথে সংরক্ষণ করুন</div>
  <div class="sign">
    <div>গ্রাহকের স্বাক্ষর</div>
    <div style="text-align:right"><span class="hasan">Hasan</span><br>পক্ষেঃ আলম টাইলস</div>
  </div>
  <div class="page">পৃষ্ঠা ${toBn(1)} / ${toBn(1)}</div>
</div>
<script>window.onload=function(){setTimeout(function(){window.print();},300);}</script>
</body></html>`;
    const w = window.open("", "_blank");
    if (w) { w.document.open(); w.document.write(html); w.document.close(); }
  }


  async function handleSubmit() {
    const filled = rows.filter((r) => r.productId && r.total > 0);
    if (!filled.length) return toast.error("Add at least one product");
    if (saving) return;
    setSaving(true);
    try {
      // restore stock for each returned product
      for (const r of filled) {
        const p = productMap.get(r.productId); if (!p) continue;
        const pcsPerCarton = p.pcs_per_carton || 1;
        const pieces = (r.carton || 0) * pcsPerCarton + (r.pcs || 0);
        if (pieces > 0) {
          await supabase.from("products").update({ stock_pieces: (p.stock_pieces || 0) + pieces }).eq("id", p.id);
        }
      }

      const invoiceNo = `RET-${Date.now().toString().slice(-8)}`;
      const items = filled.map((r) => {
        const p = productMap.get(r.productId);
        const pcsPerCarton = p?.pcs_per_carton || 1;
        const pieces = (r.carton || 0) * pcsPerCarton + (r.pcs || 0);
        return {
          productId: r.productId, pieces, totalPrice: r.total,
          cartons: r.carton, feet: r.returnQ, rate: r.sellPrice,
          costPerSqft: Number(p?.purchase_price_per_piece) || 0,
          costFeet: pieces * (Number(p?.sqft_per_piece) || 1),
        };
      });

      const { error } = await supabase.from("sales").insert({
        user_id: userId,
        invoice_no: invoiceNo,
        customer_id: customer.id,
        total_amount: grandTotal,
        paid_amount: Number(paid) || 0,
        due_amount: 0,
        items,
        is_returned: true,
        returned_amount: grandTotal,
        sale_date: new Date().toISOString().slice(0, 10),
      });
      if (error) throw error;

      // adjust customer due
      await supabase.from("customers").update({ due_amount: dueAfter }).eq("id", customer.id);

      // cash out for paid refund
      if ((Number(paid) || 0) > 0) {
        await supabase.from("cash_transactions").insert({
          user_id: userId, type: "out", amount: Number(paid),
          reason: `Sales return refund — ${customer.name} (${invoiceNo})`,
        });
      }

      // Print return invoice (image 2 layout)
      printReturnInvoice(invoiceNo, filled);

      toast.success("Sales return saved");
      refresh();
      onClose();
    } catch (e: any) {
      toast.error(e?.message || "Failed to save");
    } finally {
      setSaving(false);
    }
  }

  const inputCls = "w-full px-2 py-2 rounded border border-gray-300 bg-white text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-none";
  const labelCls = "block text-xs text-gray-500 mb-1";

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 backdrop-blur-sm overflow-y-auto" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-[1400px] my-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-3 border-b">
          <div className="flex-1 flex justify-center">
            <div className="px-4 py-1 bg-blue-500 text-white text-base font-semibold rounded">Sales Return Form</div>
          </div>
          <button onClick={onClose} className="p-1 rounded hover:bg-gray-100"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-5 space-y-4">
          {/* Customer info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className={labelCls}>Customer Id <span className="text-red-500">*</span></label>
              <input value={code} readOnly className={inputCls + " bg-gray-50"} />
              <label className={labelCls + " mt-3"}>Customer Mobile</label>
              <input value={customer.mobile || ""} readOnly className={inputCls + " bg-gray-50"} />
            </div>
            <div>
              <label className={labelCls}>Customer Name <span className="text-red-500">*</span></label>
              <input value={customer.name} readOnly className={inputCls + " bg-gray-50"} />
            </div>
            <div>
              <label className={labelCls}>Customer Address <span className="text-red-500">*</span></label>
              <input value={customer.address || ""} readOnly className={inputCls + " bg-gray-50"} />
            </div>
          </div>

          {/* Items table */}
          <div className="overflow-x-auto border border-gray-200 rounded-lg">
            <table className="w-full text-sm border-collapse">
              <thead className="bg-slate-200 text-slate-700">
                <tr>
                  <th className="px-2 py-3 text-left font-semibold">SI</th>
                  <th className="px-2 py-3 text-left font-semibold min-w-[200px]">Product Name</th>
                  <th className="px-2 py-3 text-center font-semibold">Sell Q / Feet</th>
                  <th className="px-2 py-3 text-center font-semibold">Sell Price</th>
                  <th className="px-2 py-3 text-center font-semibold">Carton</th>
                  <th className="px-2 py-3 text-center font-semibold">Pcs</th>
                  <th className="px-2 py-3 text-center font-semibold">Return Q / Feet</th>
                  <th className="px-2 py-3 text-right font-semibold">Total</th>
                  <th className="px-2 py-3 text-center font-semibold">Remove</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => {
                  const matches = r.search.trim() && !r.productId
                    ? products.filter((p) => (p.name + " " + (p.size || "")).toLowerCase().includes(r.search.toLowerCase())).slice(0, 8)
                    : [];
                  return (
                    <tr key={i} className="border-t border-gray-200">
                      <td className="px-2 py-2 text-gray-600">{i + 1}</td>
                      <td className="px-2 py-2 relative">
                        <input
                          value={r.search}
                          onChange={(e) => updateRow(i, { search: e.target.value, productId: "", showList: true })}
                          onFocus={() => updateRow(i, { showList: true })}
                          placeholder="Search product..."
                          className={inputCls}
                        />
                        {r.showList && matches.length > 0 && (
                          <div className="absolute z-10 left-2 right-2 mt-1 bg-white border border-gray-200 rounded shadow max-h-60 overflow-y-auto">
                            {matches.map((p) => (
                              <button key={p.id} onClick={() => pickProduct(i, p)}
                                className="block w-full text-left px-3 py-2 hover:bg-blue-50 text-sm">
                                {p.name} {p.size ? `(${p.size})` : ""} <span className="text-xs text-gray-500">— Stock: {p.stock_pieces}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-2 py-2">
                        <input type="number" value={r.sellQ || ""} readOnly className={inputCls + " bg-gray-50 text-center"} />
                      </td>
                      <td className="px-2 py-2">
                        <input type="number" value={r.sellPrice || ""} onChange={(e) => updateRow(i, { sellPrice: Number(e.target.value) || 0 })} className={inputCls + " text-center"} />
                      </td>
                      <td className="px-2 py-2">
                        <input type="number" value={r.carton || ""} onChange={(e) => updateRow(i, { carton: Number(e.target.value) || 0 })} className={inputCls + " text-center"} />
                      </td>
                      <td className="px-2 py-2">
                        <input type="number" value={r.pcs || ""} onChange={(e) => updateRow(i, { pcs: Number(e.target.value) || 0 })} className={inputCls + " text-center"} />
                      </td>
                      <td className="px-2 py-2">
                        <input type="number" value={r.returnQ || ""} onChange={(e) => updateRow(i, { returnQ: Number(e.target.value) || 0 })} className={inputCls + " text-center"} />
                      </td>
                      <td className="px-2 py-2 text-right font-medium">{r.total ? r.total.toFixed(0) : ""}</td>
                      <td className="px-2 py-2 text-center">
                        <button onClick={() => removeRow(i)} className="px-3 py-1.5 bg-red-500 hover:bg-red-600 text-white text-xs rounded">Remove</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Totals row - inline label+value like reference */}
          <div className="flex flex-wrap items-center gap-x-6 gap-y-3 pt-2 text-sm">
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-800">Subtotal:</span>
              <input readOnly value={subtotal.toFixed(0)} className="w-20 px-2 py-1 rounded border border-gray-300 bg-white text-sm" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-800">Discount Cut:</span>
              <input type="number" value={discount || ""} onChange={(e) => setDiscount(Number(e.target.value) || 0)} className="w-20 px-2 py-1 rounded border border-gray-300 bg-white text-sm" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-800">Grand Total:</span>
              <input readOnly value={grandTotal.toFixed(0)} className="w-20 px-2 py-1 rounded border border-gray-300 bg-white text-sm" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-800">Current Due</span>
              <input readOnly value={currentDue.toFixed(0)} className="w-20 px-2 py-1 rounded border border-gray-300 bg-white text-sm" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-800">Return</span>
              <input readOnly value={grandTotal.toFixed(0)} className="w-20 px-2 py-1 rounded border border-gray-300 bg-white text-sm" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-800">Paid:</span>
              <input type="number" value={paid || ""} onChange={(e) => setPaid(Number(e.target.value) || 0)} className="w-20 px-2 py-1 rounded border border-gray-300 bg-white text-sm" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-800">Due:</span>
              <input readOnly value={dueAfter.toFixed(0)} className="w-20 px-2 py-1 rounded border border-gray-300 bg-white text-sm" />
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-2 pt-3 max-w-[200px]">
            <button onClick={addRow} className="px-4 py-2 bg-slate-300 hover:bg-slate-400 text-slate-800 rounded font-medium text-sm">Add Product</button>
            <button onClick={handleSubmit} disabled={saving} className="px-4 py-2 bg-slate-700 hover:bg-slate-800 text-white rounded font-medium text-sm disabled:opacity-60">{saving ? "Saving..." : "Submit"}</button>
            <button onClick={clearAll} className="px-4 py-2 bg-slate-600 hover:bg-slate-700 text-white rounded font-medium text-sm">Clear</button>
          </div>
        </div>
      </div>
    </div>
  );
}
