import { useMemo, useState } from "react";
import jsPDF from "jspdf";
import { calculateInvoiceProfit, type ProfitItem, type ProfitProduct } from "@/lib/profit";
import {
  Calendar, TrendingUp, TrendingDown, Wallet, Coins, ShoppingCart, FileText,
  Download, MessageSquare, BarChart3, PieChart as PieIcon, Activity, AlertTriangle,
  ArrowUpCircle, ArrowDownCircle, Banknote,
} from "lucide-react";

type Sale = { id: string; invoice_no: string; total_amount: number; paid_amount: number; due_amount: number; is_returned: boolean; returned_amount: number; sale_date: string; items: ProfitItem[] };
type Purchase = { id: string; product_id: string | null; pieces: number; cost_per_piece: number; total_cost: number; purchase_date: string };
type Cost = { id: string; description: string; amount: number; cost_date: string };
type CashTx = { id: string; type: "in" | "out"; amount: number; reason: string | null; trans_date: string };
type Product = ProfitProduct;

type Meta = { category: string; name?: string; method?: string; note?: string };
const META_KEY = "tiles_expense_meta_v1";
const loadMeta = (): Record<string, Meta> => { try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch { return {}; } };

const today = () => new Date().toISOString().slice(0, 10);
const ymd = (d: Date) => d.toISOString().slice(0, 10);

type Period = "today" | "yesterday" | "week" | "month" | "year" | "custom";

export default function DailyAccount({
  sales, purchases, costs, cashTx, products,
}: {
  sales: Sale[]; purchases: Purchase[]; costs: Cost[]; cashTx: CashTx[]; products: Product[];
}) {
  const [period, setPeriod] = useState<Period>("today");
  const [detailSale, setDetailSale] = useState<Sale | null>(null);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [monthSel, setMonthSel] = useState("");
  const [yearSel, setYearSel] = useState("");
  const [search, setSearch] = useState("");


  const meta = useMemo(() => loadMeta(), [costs]);
  const productMap = useMemo(() => Object.fromEntries(products.map((p) => [p.id, p])), [products]);

  const inRange = (d: string) => {
    const dt = new Date(d);
    const now = new Date();
    if (monthSel) { const [y, m] = monthSel.split("-"); return dt.getFullYear() === Number(y) && dt.getMonth() === Number(m) - 1; }
    if (yearSel) return dt.getFullYear() === Number(yearSel);
    if (period === "today") return d === today();
    if (period === "yesterday") { const y = new Date(); y.setDate(now.getDate() - 1); return d === ymd(y); }
    if (period === "week") { const w = new Date(); w.setDate(now.getDate() - 7); return dt >= w; }
    if (period === "month") return dt.getMonth() === now.getMonth() && dt.getFullYear() === now.getFullYear();
    if (period === "year") return dt.getFullYear() === now.getFullYear();
    if (period === "custom") {
      if (fromDate && dt < new Date(fromDate)) return false;
      if (toDate && dt > new Date(toDate)) return false;
      return true;
    }
    return true;
  };
  const beforePeriod = (d: string) => {
    const dt = new Date(d);
    const now = new Date();
    if (monthSel) { const [y, m] = monthSel.split("-"); return dt < new Date(Number(y), Number(m) - 1, 1); }
    if (yearSel) return dt.getFullYear() < Number(yearSel);
    if (period === "today") return d < today();
    if (period === "yesterday") { const y = new Date(); y.setDate(now.getDate() - 1); return d < ymd(y); }
    if (period === "week") { const w = new Date(); w.setDate(now.getDate() - 7); return dt < w; }
    if (period === "month") return dt < new Date(now.getFullYear(), now.getMonth(), 1);
    if (period === "year") return dt < new Date(now.getFullYear(), 0, 1);
    if (period === "custom") { if (fromDate) return dt < new Date(fromDate); return false; }
    return false;
  };

  const invoiceProfit = (s: Sale) => calculateInvoiceProfit(s, productMap);

  // ---- aggregations ----
  const fSales = sales.filter((s) => inRange(s.sale_date));
  const fPurchases = purchases.filter((p) => inRange(p.purchase_date));
  const fCosts = costs.filter((c) => inRange(c.cost_date));
  const fCash = cashTx.filter((t) => inRange(t.trans_date));

  const totalSale = fSales.reduce((a, s) => a + invoiceProfit(s).sale, 0);
  const totalPaid = fSales.reduce((a, s) => a + Number(s.paid_amount), 0);
  const totalDue = fSales.reduce((a, s) => a + Number(s.due_amount), 0);
  const totalPurchase = fPurchases.reduce((a, p) => a + Number(p.total_cost), 0);
  const totalExpense = fCosts.reduce((a, c) => a + Number(c.amount), 0);
  const prevDue = sales.filter((s) => beforePeriod(s.sale_date)).reduce((a, s) => a + Number(s.due_amount), 0);

  // One calculation drives every report and invoice detail.
  const cogs = fSales.reduce((sum, s) => sum + invoiceProfit(s).cogs, 0);
  const hasEstimatedProfit = fSales.some(s => invoiceProfit(s).estimated);

  const returnLoss = fSales.filter((s) => s.is_returned).reduce((a, s) => a + Number(s.returned_amount), 0);
  const grossProfit = totalSale - cogs;
  const netProfit = grossProfit - totalExpense;

  const cashIn = fCash.filter((t) => t.type === "in").reduce((a, t) => a + Number(t.amount), 0);
  const cashOut = fCash.filter((t) => t.type === "out").reduce((a, t) => a + Number(t.amount), 0);
  const cashInHand = cashIn - cashOut + totalPaid - totalExpense;

  const supplierPaid = fCash.filter((t) => t.type === "out" && (t.reason || "").toLowerCase().includes("supplier")).reduce((a, t) => a + Number(t.amount), 0);
  const dueCollection = fCash.filter((t) => t.type === "in" && (t.reason || "").toLowerCase().includes("due")).reduce((a, t) => a + Number(t.amount), 0);

  // expense by category
  const expenseByCat = useMemo(() => {
    const m: Record<string, number> = {};
    fCosts.forEach((c) => { const cat = meta[c.id]?.category || "অন্যান্য"; m[cat] = (m[cat] || 0) + Number(c.amount); });
    return Object.entries(m).sort((a, b) => b[1] - a[1]);
  }, [fCosts, meta]);

  // daily ledger table
  const byDate = useMemo(() => {
    const map: Record<string, { sale: number; purchase: number; expense: number; due: number; invoices: string[] }> = {};
    const ensure = (d: string) => (map[d] ||= { sale: 0, purchase: 0, expense: 0, due: 0, invoices: [] });
    fSales.forEach((s) => {
      const r = ensure(s.sale_date);
      const calculated = invoiceProfit(s);
      r.sale += calculated.sale;
      r.due += Number(s.due_amount);
      r.invoices.push(s.invoice_no);
      r.purchase += calculated.cogs;
    });
    fCosts.forEach((c) => { ensure(c.cost_date).expense += Number(c.amount); });
    return Object.entries(map)
      .map(([date, v]) => ({ date, ...v, profit: v.sale - v.purchase - v.expense }))
      .filter((r) => !search || r.date.includes(search) || r.invoices.some((i) => i.toLowerCase().includes(search.toLowerCase())))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [fSales, fCosts, productMap, search]);

  const maxDayProfit = Math.max(1, ...byDate.map((d) => Math.abs(d.profit)));

  // ---- monthly / yearly summary ----
  const now = new Date();
  const monthAgg = (mOffset = 0) => {
    const target = new Date(now.getFullYear(), now.getMonth() - mOffset, 1);
    const f = (d: string) => { const dt = new Date(d); return dt.getMonth() === target.getMonth() && dt.getFullYear() === target.getFullYear(); };
    const sa = sales.filter((s) => f(s.sale_date));
    const co = costs.filter((c) => f(c.cost_date));
    const saleA = sa.reduce((a, s) => a + invoiceProfit(s).sale, 0);
    const expA = co.reduce((a, c) => a + Number(c.amount), 0);
    const cogsA = sa.reduce((sum, s) => sum + invoiceProfit(s).cogs, 0);
    return { label: target.toLocaleString("default", { month: "short", year: "numeric" }), sale: saleA, expense: expA, profit: saleA - cogsA - expA };
  };
  const monthlyTrend = [5, 4, 3, 2, 1, 0].map(monthAgg);
  const maxMonthSale = Math.max(1, ...monthlyTrend.map((m) => m.sale));

  // year summary
  const yearAgg = () => {
    const y = now.getFullYear();
    const f = (d: string) => new Date(d).getFullYear() === y;
    const sa = sales.filter((s) => f(s.sale_date));
    const pu = purchases.filter((p) => f(p.purchase_date));
    const co = costs.filter((c) => f(c.cost_date));
    const saleY = sa.reduce((a, s) => a + invoiceProfit(s).sale, 0);
    const purY = pu.reduce((a, p) => a + Number(p.total_cost), 0);
    const expY = co.reduce((a, c) => a + Number(c.amount), 0);
    const cogsY = sa.reduce((sum, s) => sum + invoiceProfit(s).cogs, 0);
    return { sale: saleY, purchase: purY, expense: expY, profit: saleY - cogsY - expY, net: saleY - purY - expY };
  };
  const year = yearAgg();

  // ---- alerts ----
  const alerts: { type: "danger" | "warn" | "info"; msg: string }[] = [];
  if (hasEstimatedProfit) alerts.push({ type: "warn", msg: "আনুমানিক লাভ: পুরোনো বিক্রির তৎকালীন ক্রয়মূল্য বা আংশিক ফেরতের পণ্যের তথ্য সংরক্ষিত নেই।" });
  if (netProfit < 0) alerts.push({ type: "danger", msg: `এই সময়ে নিট লস: ৳${Math.abs(netProfit).toFixed(0)}` });
  if (totalDue > totalSale * 0.4 && totalSale > 0) alerts.push({ type: "warn", msg: `বকেয়া বিক্রয়ের ${((totalDue / totalSale) * 100).toFixed(0)}% — কালেকশন বাড়ান` });
  if (totalExpense > totalSale * 0.5 && totalSale > 0) alerts.push({ type: "warn", msg: `খরচ বিক্রয়ের ${((totalExpense / totalSale) * 100).toFixed(0)}% — খরচ বেশি` });
  if (cashInHand < 0) alerts.push({ type: "danger", msg: `ক্যাশ ঘাটতি: ৳${Math.abs(cashInHand).toFixed(0)}` });

  // ---- exports ----
  const exportPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(16); doc.text("Daily Account / Profit Report", 14, 18);
    doc.setFontSize(10);
    doc.text(`Period: ${period}${monthSel ? ` (${monthSel})` : ""}${yearSel ? ` (${yearSel})` : ""}`, 14, 26);
    const lines = [
      `Sale: BDT ${totalSale.toFixed(2)}`,
      `Purchase: BDT ${totalPurchase.toFixed(2)}`,
      `COGS: BDT ${cogs.toFixed(2)}`,
      `Expense: BDT ${totalExpense.toFixed(2)}`,
      `Returns (already reflected in sales): BDT ${returnLoss.toFixed(2)}`,
      `Cost basis: ${hasEstimatedProfit ? "Estimated for legacy records" : "Recorded at sale"}`,
      `Gross Profit: BDT ${grossProfit.toFixed(2)}`,
      `Net Profit: BDT ${netProfit.toFixed(2)}`,
      `Due: BDT ${totalDue.toFixed(2)}`,
      `Cash In Hand: BDT ${cashInHand.toFixed(2)}`,
    ];
    let y = 34; lines.forEach((l) => { doc.text(l, 14, y); y += 6; });
    y += 4; doc.setFont("helvetica", "bold"); doc.text("Date-wise Ledger", 14, y); y += 6; doc.setFont("helvetica", "normal");
    byDate.forEach((r) => {
      if (y > 280) { doc.addPage(); y = 20; }
      doc.text(`${r.date} | Sale ${r.sale.toFixed(0)} | Pur ${r.purchase.toFixed(0)} | Exp ${r.expense.toFixed(0)} | Profit ${r.profit.toFixed(0)} | Due ${r.due.toFixed(0)}`, 14, y);
      y += 5;
    });
    doc.save(`daily-account-${Date.now()}.pdf`);
  };

  const exportCSV = () => {
    const rows = [["তারিখ", "ইনভয়েস", "বিক্রয়", "ক্রয়", "খরচ", "লাভ", "বকেয়া"]];
    byDate.forEach((r) => rows.push([r.date, r.invoices.join("|"), String(r.sale), String(r.purchase), String(r.expense), String(r.profit), String(r.due)]));
    const csv = rows.map((r) => r.map((v) => `"${(v || "").replace(/"/g, '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = `daily-account-${Date.now()}.csv`; a.click();
  };

  const shareWA = () => {
    const t = `*দৈনিক হিসাব (${period})*\nবিক্রয়: ৳${totalSale.toFixed(0)}\nক্রয়: ৳${totalPurchase.toFixed(0)}\nখরচ: ৳${totalExpense.toFixed(0)}\nপ্রকৃত লাভ: ৳${grossProfit.toFixed(0)}\nনিট লাভ: ৳${netProfit.toFixed(0)}\nবকেয়া: ৳${totalDue.toFixed(0)}\nক্যাশ: ৳${cashInHand.toFixed(0)}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(t)}`, "_blank");
  };

  const kpis = [
    { label: "মোট বিক্রয়", value: totalSale, icon: ShoppingCart, grad: "from-blue-500 to-indigo-600" },
    { label: "মোট ক্রয়", value: totalPurchase, icon: Coins, grad: "from-amber-500 to-orange-600" },
    { label: "মোট খরচ", value: totalExpense, icon: Wallet, grad: "from-rose-500 to-pink-600" },
    { label: "নিট লাভ", value: netProfit, icon: TrendingUp, grad: netProfit >= 0 ? "from-emerald-500 to-green-600" : "from-red-500 to-rose-700" },
    { label: "বকেয়া", value: totalDue, icon: FileText, grad: "from-purple-500 to-fuchsia-600" },
    { label: "ক্যাশ ইন হ্যান্ড", value: cashInHand, icon: Banknote, grad: "from-teal-500 to-cyan-600" },
    { label: "ডিউ কালেকশন", value: dueCollection, icon: ArrowUpCircle, grad: "from-lime-500 to-emerald-600" },
    { label: "সাপ্লায়ার পেমেন্ট", value: supplierPaid, icon: ArrowDownCircle, grad: "from-slate-600 to-slate-800" },
  ];

  return (
    <div className="space-y-5">
      {/* Filters */}
      <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40 flex flex-wrap gap-3 items-end">
        <div>
          <label className="text-xs text-gray-600 block">পিরিয়ড</label>
          <select value={period} onChange={(e) => { setPeriod(e.target.value as Period); setMonthSel(""); setYearSel(""); }} className="border p-2 rounded-lg">
            <option value="today">আজ</option>
            <option value="yesterday">গতকাল</option>
            <option value="week">এই সপ্তাহ</option>
            <option value="month">এই মাস</option>
            <option value="year">এই বছর</option>
            <option value="custom">কাস্টম</option>
          </select>
        </div>
        {period === "custom" && (
          <>
            <div><label className="text-xs text-gray-600 block">শুরু</label><input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="border p-2 rounded-lg" /></div>
            <div><label className="text-xs text-gray-600 block">শেষ</label><input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="border p-2 rounded-lg" /></div>
          </>
        )}
        <div>
          <label className="text-xs text-gray-600 block">মাস</label>
          <input type="month" value={monthSel} onChange={(e) => { setMonthSel(e.target.value); setYearSel(""); }} className="border p-2 rounded-lg" />
        </div>
        <div>
          <label className="text-xs text-gray-600 block">বছর</label>
          <input type="number" placeholder="2026" value={yearSel} onChange={(e) => { setYearSel(e.target.value); setMonthSel(""); }} className="border p-2 rounded-lg w-24" />
        </div>
        <div>
          <label className="text-xs text-gray-600 block">খুঁজুন</label>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="তারিখ / ইনভয়েস" className="border p-2 rounded-lg" />
        </div>
        <div className="flex gap-2 ml-auto no-print">
          <button onClick={exportPDF} className="bg-red-600 text-white px-3 py-2 rounded-lg flex items-center gap-1 text-sm"><FileText className="w-4 h-4" />PDF</button>
          <button onClick={exportCSV} className="bg-emerald-600 text-white px-3 py-2 rounded-lg flex items-center gap-1 text-sm"><Download className="w-4 h-4" />Excel</button>
          <button onClick={shareWA} className="bg-green-500 text-white px-3 py-2 rounded-lg flex items-center gap-1 text-sm"><MessageSquare className="w-4 h-4" />শেয়ার</button>
          <button onClick={() => window.print()} className="bg-slate-700 text-white px-3 py-2 rounded-lg text-sm">প্রিন্ট</button>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {kpis.map((k) => (
          <div key={k.label} className={`bg-gradient-to-br ${k.grad} text-white p-4 rounded-2xl shadow-lg`}>
            <div className="flex items-center justify-between mb-2"><k.icon className="w-5 h-5 opacity-80" /><span className="text-xs opacity-80">{k.label}</span></div>
            <div className="text-2xl font-bold">৳{k.value.toFixed(0)}</div>
          </div>
        ))}
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-2">
          {alerts.map((a, i) => (
            <div key={i} className={`flex items-center gap-2 p-3 rounded-xl text-sm ${a.type === "danger" ? "bg-red-50 text-red-700 border border-red-200" : "bg-amber-50 text-amber-700 border border-amber-200"}`}>
              <AlertTriangle className="w-4 h-4" />{a.msg}
            </div>
          ))}
        </div>
      )}

      {/* Profit calculation breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 text-white p-4 rounded-2xl shadow-lg">
          <h3 className="font-bold mb-3 flex items-center gap-2"><Activity className="w-4 h-4" />লাভ গণনা</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="opacity-80">বিক্রয়</span><span>৳{totalSale.toFixed(0)}</span></div>
            <div className="flex justify-between"><span className="opacity-80">(-) COGS</span><span>৳{cogs.toFixed(0)}</span></div>
            <div className="flex justify-between border-t border-white/20 pt-2"><span>প্রকৃত লাভ</span><span className={grossProfit >= 0 ? "text-emerald-300" : "text-rose-300"}>৳{grossProfit.toFixed(0)}</span></div>
            <div className="flex justify-between"><span className="opacity-80">(-) খরচ</span><span>৳{totalExpense.toFixed(0)}</span></div>
            <div className="flex justify-between"><span className="opacity-80">ফেরত (বিক্রয়ে সমন্বিত)</span><span>৳{returnLoss.toFixed(0)}</span></div>
            <div className="flex justify-between border-t border-white/20 pt-2 text-base font-bold"><span>নিট লাভ</span><span className={netProfit >= 0 ? "text-emerald-300" : "text-rose-300"}>৳{netProfit.toFixed(0)}</span></div>
          </div>
        </div>

        <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
          <h3 className="font-bold mb-3 flex items-center gap-2"><PieIcon className="w-4 h-4 text-purple-600" />খরচ ক্যাটাগরি</h3>
          <div className="space-y-2 text-sm">
            {expenseByCat.length === 0 && <p className="text-gray-400">কোনো খরচ নেই</p>}
            {expenseByCat.map(([c, v]) => (
              <div key={c}>
                <div className="flex justify-between"><span>{c}</span><span className="font-semibold">৳{v.toFixed(0)}</span></div>
                <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden"><div className="h-full bg-gradient-to-r from-purple-500 to-pink-500" style={{ width: `${totalExpense ? (v / totalExpense) * 100 : 0}%` }} /></div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
          <h3 className="font-bold mb-3 flex items-center gap-2"><Calendar className="w-4 h-4 text-indigo-600" />বার্ষিক সারাংশ ({now.getFullYear()})</h3>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between border-b py-1"><span>বিক্রয়</span><span className="font-semibold">৳{year.sale.toFixed(0)}</span></div>
            <div className="flex justify-between border-b py-1"><span>ক্রয়</span><span className="font-semibold">৳{year.purchase.toFixed(0)}</span></div>
            <div className="flex justify-between border-b py-1"><span>খরচ</span><span className="font-semibold">৳{year.expense.toFixed(0)}</span></div>
            <div className="flex justify-between border-b py-1"><span>নিট লাভ</span><span className={`font-semibold ${year.profit >= 0 ? "text-emerald-600" : "text-rose-600"}`}>৳{year.profit.toFixed(0)}</span></div>
            <div className="flex justify-between py-1"><span>নেট ব্যালেন্স</span><span className={`font-semibold ${year.net >= 0 ? "text-emerald-600" : "text-rose-600"}`}>৳{year.net.toFixed(0)}</span></div>
          </div>
        </div>
      </div>

      {/* Per-invoice profit table (ক্রঃ | বিবরন | টাকা | লাভ) */}
      <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
        <h3 className="font-bold mb-3 flex items-center gap-2"><Activity className="w-4 h-4 text-emerald-600" />লাভ হিসাব</h3>
        <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
          <table className="w-full text-sm border-collapse">
            <thead className="bg-slate-200 sticky top-0">
              <tr>
                <th className="border border-slate-400 p-2 w-16 text-center">ক্রঃ</th>
                <th className="border border-slate-400 p-2 text-center">বিবরন</th>
                <th className="border border-slate-400 p-2 w-32 text-center">বিক্রয় মুল্য</th>
                <th className="border border-slate-400 p-2 w-32 text-center">ক্রয়</th>
                <th className="border border-slate-400 p-2 w-32 text-center">লাভ</th>
              </tr>
            </thead>
            <tbody>
              {fSales.length === 0 && (
                <tr><td colSpan={5} className="border border-slate-300 p-6 text-center text-gray-400">এই পরিসরে কোনো বিক্রয় নেই</td></tr>
              )}
              {fSales.map((s, idx) => {
                const calculated = invoiceProfit(s);
                const saleAmt = calculated.sale;
                const itemCogs = calculated.cogs;
                const profit = calculated.profit;
                return (
                  <tr key={s.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => setDetailSale(s)} title="বিস্তারিত দেখতে ক্লিক করুন">
                    <td className="border border-slate-300 p-2 text-center">{idx + 1}</td>
                    <td className="border border-slate-300 p-2 text-center">{s.invoice_no}</td>
                    <td className="border border-slate-300 p-2 text-center">{saleAmt.toFixed(0)}</td>
                    <td className="border border-slate-300 p-2 text-center">{itemCogs.toFixed(0)}</td>
                    <td className={`border border-slate-300 p-2 text-center font-semibold ${profit >= 0 ? "text-emerald-700" : "text-rose-700"}`}>{profit.toFixed(0)}</td>
                  </tr>
                );
              })}
              <tr className="bg-slate-100 font-bold">
                <td className="border border-slate-400 p-2 text-center" colSpan={2}>মোটঃ</td>
                <td className="border border-slate-400 p-2 text-center">{totalSale.toFixed(0)}</td>
                <td className="border border-slate-400 p-2 text-center">{cogs.toFixed(0)}</td>
                <td className="border border-slate-400 p-2 text-center">{grossProfit.toFixed(0)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>



      {/* Monthly trend chart */}
      <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
        <h3 className="font-bold mb-3 flex items-center gap-2"><BarChart3 className="w-4 h-4 text-blue-600" />মাসিক ট্রেন্ড (বিক্রয় vs লাভ)</h3>
        <div className="flex items-end gap-3 h-48">
          {monthlyTrend.map((m) => (
            <div key={m.label} className="flex-1 flex flex-col items-center gap-1">
              <div className="text-[10px] text-gray-600">৳{(m.profit / 1000).toFixed(1)}k</div>
              <div className="w-full flex items-end gap-1 h-full">
                <div className="flex-1 bg-gradient-to-t from-blue-500 to-indigo-400 rounded-t" style={{ height: `${(m.sale / maxMonthSale) * 100}%` }} title={`বিক্রয়: ৳${m.sale.toFixed(0)}`} />
                <div className={`flex-1 bg-gradient-to-t ${m.profit >= 0 ? "from-emerald-500 to-green-400" : "from-rose-500 to-red-400"} rounded-t`} style={{ height: `${(Math.abs(m.profit) / maxMonthSale) * 100}%` }} title={`লাভ: ৳${m.profit.toFixed(0)}`} />
              </div>
              <div className="text-[10px] text-gray-500">{m.label}</div>
            </div>
          ))}
        </div>
        <div className="flex gap-4 text-xs text-gray-600 mt-2">
          <div className="flex items-center gap-1"><div className="w-3 h-3 bg-blue-500 rounded" />বিক্রয়</div>
          <div className="flex items-center gap-1"><div className="w-3 h-3 bg-emerald-500 rounded" />লাভ</div>
        </div>
      </div>

      {/* Daily Account Table */}
      <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
        <h3 className="font-bold mb-3 flex items-center gap-2"><Calendar className="w-4 h-4 text-indigo-600" />দৈনিক হিসাব ({byDate.length} দিন)</h3>
        <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="bg-gradient-to-r from-slate-100 to-slate-50 sticky top-0">
              <tr>
                <th className="p-2 text-left">তারিখ</th>
                <th className="p-2 text-left">ইনভয়েস</th>
                <th className="p-2 text-right">বিক্রয়</th>
                <th className="p-2 text-right">ক্রয়</th>
                <th className="p-2 text-right">খরচ</th>
                <th className="p-2 text-right">লাভ</th>
                <th className="p-2 text-right">বকেয়া</th>
                <th className="p-2 text-center">স্ট্যাটাস</th>
              </tr>
            </thead>
            <tbody>
              {byDate.length === 0 && <tr><td colSpan={8} className="p-6 text-center text-gray-400">এই পরিসরে কোনো তথ্য নেই</td></tr>}
              {byDate.map((r) => (
                <tr key={r.date} className="border-b hover:bg-slate-50">
                  <td className="p-2 font-medium">{r.date}</td>
                  <td className="p-2 text-xs text-gray-600 truncate max-w-[140px]">{r.invoices.slice(0, 3).join(", ") || "—"}</td>
                  <td className="p-2 text-right text-blue-600 font-semibold">৳{r.sale.toFixed(0)}</td>
                  <td className="p-2 text-right text-amber-600">৳{r.purchase.toFixed(0)}</td>
                  <td className="p-2 text-right text-rose-600">৳{r.expense.toFixed(0)}</td>
                  <td className={`p-2 text-right font-bold ${r.profit >= 0 ? "text-emerald-600" : "text-rose-600"}`}>৳{r.profit.toFixed(0)}</td>
                  <td className="p-2 text-right text-purple-600">৳{r.due.toFixed(0)}</td>
                  <td className="p-2 text-center">
                    {r.profit >= 0
                      ? <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-xs inline-flex items-center gap-1"><TrendingUp className="w-3 h-3" />লাভ</span>
                      : <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 text-xs inline-flex items-center gap-1"><TrendingDown className="w-3 h-3" />লস</span>}
                  </td>
                </tr>
              ))}
              {byDate.length > 0 && (
                <tr className="bg-slate-100 font-bold">
                  <td className="p-2" colSpan={2}>মোট</td>
                  <td className="p-2 text-right text-blue-700">৳{totalSale.toFixed(0)}</td>
                  <td className="p-2 text-right text-amber-700">৳{cogs.toFixed(0)}</td>
                  <td className="p-2 text-right text-rose-700">৳{totalExpense.toFixed(0)}</td>
                  <td className={`p-2 text-right ${netProfit >= 0 ? "text-emerald-700" : "text-rose-700"}`}>৳{netProfit.toFixed(0)}</td>
                  <td className="p-2 text-right text-purple-700">৳{totalDue.toFixed(0)}</td>
                  <td />
                </tr>
              )}
              {prevDue > 0 && (
                <tr className="bg-amber-50 font-bold">
                  <td className="p-2" colSpan={6} />
                  <td className="p-2 text-right text-amber-800">পূর্বের বাকিঃ ৳{prevDue.toFixed(0)}</td>
                  <td />
                </tr>
              )}
              {prevDue > 0 && (
                <tr className="bg-amber-100 font-bold">
                  <td className="p-2" colSpan={6} />
                  <td className="p-2 text-right text-amber-900">সর্বমোট বাকিঃ ৳{(totalDue + prevDue).toFixed(0)}</td>
                  <td />
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice details modal */}
      {detailSale && (() => {
        const s = detailSale;
        const calculated = invoiceProfit(s);
        const rows = calculated.rows;
        const totSale = calculated.sale;
        const totCogs = calculated.cogs;
        return (
          <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setDetailSale(null)}>
            <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[85vh] overflow-auto p-5" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-lg">ইনভয়েস {s.invoice_no} — বিস্তারিত ({s.sale_date})</h3>
                <button onClick={() => setDetailSale(null)} className="text-gray-500 hover:text-gray-800 text-xl font-bold px-2">✕</button>
              </div>
              <table className="w-full text-sm border-collapse">
                <thead className="bg-slate-200">
                  <tr>
                    <th className="border border-slate-400 p-2 text-left">পণ্য</th>
                    <th className="border border-slate-400 p-2 text-center">পিস</th>
                    <th className="border border-slate-400 p-2 text-right">একক মূল্য</th>
                    <th className="border border-slate-400 p-2 text-right">বিক্রয়</th>
                    <th className="border border-slate-400 p-2 text-right">ক্রয়</th>
                    <th className="border border-slate-400 p-2 text-right">লাভ</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.length === 0 && <tr><td colSpan={6} className="border border-slate-300 p-4 text-center text-gray-400">কোনো পণ্য নেই</td></tr>}
                  {rows.map((r, i) => (
                    <tr key={i} className={i % 2 ? "bg-slate-50" : ""}>
                      <td className="border border-slate-300 p-2">{r.name}</td>
                      <td className="border border-slate-300 p-2 text-center">{r.pieces}</td>
                      <td className="border border-slate-300 p-2 text-right">{r.unit.toFixed(0)}</td>
                      <td className="border border-slate-300 p-2 text-right">{r.sale.toFixed(0)}</td>
                      <td className="border border-slate-300 p-2 text-right">{r.cogs.toFixed(0)}</td>
                      <td className={`border border-slate-300 p-2 text-right font-semibold ${r.profit >= 0 ? "text-emerald-700" : "text-rose-700"}`}>{r.profit.toFixed(0)}</td>
                    </tr>
                  ))}
                  {Math.abs(calculated.adjustment) > 0.000001 && <tr>
                    <td className="border border-slate-300 p-2" colSpan={3}>ছাড় ও অন্যান্য বিল সমন্বয়</td>
                    <td className="border border-slate-300 p-2 text-right">{calculated.adjustment.toFixed(0)}</td>
                    <td className="border border-slate-300 p-2 text-right">0</td>
                    <td className="border border-slate-300 p-2 text-right">{calculated.adjustment.toFixed(0)}</td>
                  </tr>}
                  <tr className="bg-slate-100 font-bold">
                    <td className="border border-slate-400 p-2" colSpan={3}>মোট</td>
                    <td className="border border-slate-400 p-2 text-right">{totSale.toFixed(0)}</td>
                    <td className="border border-slate-400 p-2 text-right">{totCogs.toFixed(0)}</td>
                    <td className="border border-slate-400 p-2 text-right">{(totSale - totCogs).toFixed(0)}</td>
                  </tr>
                </tbody>
              </table>
              {calculated.returnMemo && <p className="text-xs text-muted-foreground mt-2">ফেরত মেমো: বিক্রয় ও ফেরত পণ্যের ক্রয়মূল্য উল্টো হিসাবে সমন্বিত হয়েছে।</p>}
              {calculated.estimated && <p className="text-xs text-muted-foreground mt-2">এই লাভ আনুমানিক; তৎকালীন ক্রয়মূল্য বা ফেরতের সম্পূর্ণ তথ্য নেই।</p>}
            </div>
          </div>
        );
      })()}

    </div>
  );
}
