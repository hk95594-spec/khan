import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

export default function StockEditableCell({ label, value, numeric = false, integer = false, onSave }: {
  label: string; value: string; numeric?: boolean; integer?: boolean;
  onSave: (value: string) => Promise<void>;
}) {
  const [draft, setDraft] = useState(value);
  const [status, setStatus] = useState<"idle" | "saving" | "error">("idle");
  const focused = useRef(false);
  const cancelled = useRef(false);
  const committed = useRef(value);
  useEffect(() => {
    if (!focused.current) { setDraft(value); committed.current = value; }
  }, [value]);

  const save = async () => {
    focused.current = false;
    if (cancelled.current) { cancelled.current = false; return; }
    if (draft === committed.current || status === "saving") return;
    setStatus("saving");
    try {
      await onSave(draft);
      committed.current = draft;
    } catch (error) {
      setStatus("error");
      toast.error(error instanceof Error ? error.message : "সেভ হয়নি, আবার চেষ্টা করুন");
    }
  };

  return <div className="relative min-w-20">
    <input aria-label={label} aria-invalid={status === "error"} title={label}
      type={numeric ? "number" : "text"} min={numeric ? 0 : undefined} step={integer ? 1 : "any"}
      value={draft} disabled={status === "saving"}
      onFocus={() => { focused.current = true; setStatus("idle"); }}
      onChange={(event) => setDraft(event.target.value)} onBlur={() => { void save(); }}
      onKeyDown={(event) => {
        if (event.key === "Enter") event.currentTarget.blur();
        if (event.key === "Escape") {
          cancelled.current = true; setDraft(committed.current); event.currentTarget.blur();
        }
      }}
      className="no-spin w-full min-w-0 rounded-sm border border-transparent bg-transparent py-1 pr-1 text-sm text-inherit outline-none focus:border-ring focus:bg-background focus:text-foreground aria-invalid:border-destructive disabled:opacity-60 print:border-0"
    />
  </div>;
}