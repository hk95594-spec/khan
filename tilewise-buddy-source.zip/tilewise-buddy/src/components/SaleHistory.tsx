import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Printer, Download, Pencil, Undo2, Trash2, Wallet,
  X, MessageSquare, Plus, Eye,
} from "lucide-react";

import { INVOICE_CSS, INVOICE_LOGO_SVG } from "@/lib/invoice-style";
import { invoicePreviousDue } from "@/lib/invoice-due";
import { openWhatsApp } from "@/lib/whatsapp";




type Product = {
  id: string; name: string; size: string | null; company: string | null;
  sqft_per_piece: number; pcs_per_carton: number; stock_pieces: number;
  purchase_price_per_piece: number; sell_price_per_piece: number;
};
type Customer = { id: string; name: string; mobile: string | null; address: string | null; due_amount: number };
type SaleItem = {
  productId: string; pieces: number; totalPrice: number;
  cartons?: number; feet?: number; rate?: number;
};
type Sale = {
  id: string; invoice_no: string; customer_id: string | null; total_amount: number;
  paid_amount: number; due_amount: number; items: SaleItem[]; is_returned: boolean;
  returned_amount: number; sale_date: string;
  labor?: number; transport?: number; discount?: number;
};

type DateMode = "all" | "today" | "custom" | "range";

function custCode(customers: Customer[], id: string | null): string {
  if (!id) return "WALK-IN";
  const sorted = [...customers].sort((a, b) => a.id.localeCompare(b.id));
  const idx = sorted.findIndex((c) => c.id === id);
  return idx >= 0 ? `CUST${String(idx + 1).padStart(6, "0")}` : "CUST------";
}

const SHOP = { nameEn: "Alam Tiles", nameBn: "আলম টাইলস", address: "বড় কালি বাড়ি রোড, টাংগাইল", phone: "0175-7770796, 0162-1176784" };

function computeProfit(s: Sale, productMap: Map<string, Product>): number {
  return s.items.reduce((sum, it) => {
    const p = productMap.get(it.productId);
    const cost = p ? Number(p.purchase_price_per_piece) * it.pieces : 0;
    return sum + (Number(it.totalPrice) - cost);
  }, 0);
}

function statusOf(s: Sale): { label: string; cls: string } {
  if (Number(s.due_amount) <= 0) return { label: "Paid", cls: "bg-emerald-100 text-emerald-700 border-emerald-300" };
  if (Number(s.paid_amount) > 0) return { label: "Partial", cls: "bg-amber-100 text-amber-700 border-amber-300" };
  return { label: "Due", cls: "bg-rose-100 text-rose-700 border-rose-300" };
}

const toBnDigits = (s: string | number) => String(s).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
function numToBnWords(num: number): string {
  num = Math.round(num);
  if (num === 0) return "শূন্য";
  const ones = ["", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়", "দশ", "এগারো", "বারো", "তেরো", "চৌদ্দ", "পনেরো", "ষোলো", "সতেরো", "আঠারো", "ঊনিশ", "বিশ", "একুশ", "বাইশ", "তেইশ", "চব্বিশ", "পঁচিশ", "ছাব্বিশ", "সাতাশ", "আঠাশ", "ঊনত্রিশ", "ত্রিশ", "একত্রিশ", "বত্রিশ", "তেত্রিশ", "চৌত্রিশ", "পঁইত্রিশ", "ছত্রিশ", "সাঁইত্রিশ", "আটত্রিশ", "ঊনচল্লিশ", "চল্লিশ", "একচল্লিশ", "বিয়াল্লিশ", "তেতাল্লিশ", "চুয়াল্লিশ", "পঁইতাল্লিশ", "ছিচল্লিশ", "সাতচল্লিশ", "আটচল্লিশ", "ঊনপঞ্চাশ", "পঞ্চাশ", "একান্ন", "বায়ান্ন", "তিপ্পান্ন", "চুয়ান্ন", "পঞ্চান্ন", "ছাপ্পান্ন", "সাতান্ন", "আটান্ন", "ঊনষাট", "ষাট", "একষট্টি", "বাষট্টি", "তেষট্টি", "চৌষট্টি", "পঁইষট্টি", "ছিষট্টি", "সাতষট্টি", "আটষট্টি", "ঊনসত্তর", "সত্তর", "একাত্তর", "বাহাত্তর", "তিয়াত্তর", "চুয়াত্তর", "পঁচাত্তর", "ছিয়াত্তর", "সাতাত্তর", "আটাত্তর", "ঊনআশি", "আশি", "একাশি", "বিরাশি", "তিরাশি", "চুরাশি", "পঁচাশি", "ছিয়াশি", "সাতাশি", "আটাশি", "ঊননব্বই", "নব্বই", "একানব্বই", "বিরানব্বই", "তিরানব্বই", "চুরানব্বই", "পঁচানব্বই", "ছিয়ানব্বই", "সাতানব্বই", "আটানব্বই", "নিরানব্বই"];
  const below1000 = (n: number): string => {
    if (n < 100) return ones[n];
    const h = Math.floor(n / 100), r = n % 100;
    return ones[h] + "শ" + (r ? " " + ones[r] : "");
  };
  const parts: string[] = [];
  const crore = Math.floor(num / 10000000); num %= 10000000;
  const lakh = Math.floor(num / 100000); num %= 100000;
  const thousand = Math.floor(num / 1000); num %= 1000;
  if (crore) parts.push(below1000(crore) + " কোটি");
  if (lakh) parts.push(below1000(lakh) + " লক্ষ");
  if (thousand) parts.push(below1000(thousand) + " হাজার");
  if (num) parts.push(below1000(num));
  return parts.join(" ");
}

export function buildInvoiceHtml(s: Sale, c: Customer | undefined, productMap: Map<string, Product>, opts: { preview?: boolean; showPreviousDue?: boolean } = {}): string {
  const dateStr = new Date(s.sale_date).toLocaleDateString("en-GB");
  const itemRows = s.items;
  const laborRate = Number(s.labor ?? 0);
  const transportAmt = Number(s.transport ?? 0);
  const totalCartonsAll = itemRows.reduce((sum, it) => sum + (Number(it.cartons) || 0), 0);
  const laborAmount = laborRate > 0 ? totalCartonsAll * laborRate : 0;
  const hasLabor = laborRate > 0;
  const hasTransport = transportAmt > 0;
  const discountAmt = Number((s as any).discount ?? 0) || 0;
  const invNum = s.invoice_no.replace(/\D/g, "").slice(-4) || s.invoice_no;
  const grandTotal = Number(s.total_amount);
  const paidAmt = Number(s.paid_amount);
  const dueNow = Number(s.due_amount);
  const totalFeetAll = itemRows.reduce((sum, it) => sum + Number(it.feet ?? 0), 0);
  const custTotalDue = c ? Number(c.due_amount) : 0;
  const prevDue = invoicePreviousDue(s, custTotalDue);
  const showPrevDue = opts.showPreviousDue !== false;
  const custName = c?.name ?? "Walk-in";
  const custMobile = c?.mobile ?? "";
  const custAddress = c?.address ?? "";

  // Split items into pages of 11
  const PER_PAGE = 11;
  const chunks: typeof itemRows[] = [];
  for (let i = 0; i < itemRows.length; i += PER_PAGE) chunks.push(itemRows.slice(i, i + PER_PAGE));
  if (chunks.length === 0) chunks.push([]);
  const totalPages = chunks.length;

  const renderRow = (it: typeof itemRows[number], idx: number) => {
    const p = productMap.get(it.productId);
    const name = `${p?.name ?? "—"}${p?.size ? " " + p.size : ""}`;
    const ppc = p?.pcs_per_carton ?? 0;
    const leftoverPcs = ppc > 0 ? Number(it.pieces ?? 0) % ppc : Number(it.pieces ?? 0);
    return `<tr>
      <td class="c">${toBnDigits(idx + 1)}</td>
      <td>${name}</td>
      <td class="c">${toBnDigits(Number(it.feet ?? 0).toFixed(2))}</td>
      <td class="c">${Number(it.cartons) ? toBnDigits(Number(it.cartons)) : ""}</td>
      <td class="c">${leftoverPcs ? toBnDigits(leftoverPcs) : ""}</td>
      <td class="c">${toBnDigits(Number(it.rate ?? 0).toFixed(0))}</td>
      <td class="r">${toBnDigits(Number(it.totalPrice).toFixed(0))}</td>
    </tr>`;
  };

  const buildPage = (chunk: typeof itemRows, chunkIdx: number, startIdx: number) => {
    const isLast = chunkIdx === totalPages - 1;
    const rowsHtml = chunk.map((it, i) => renderRow(it, startIdx + i)).join("");
    // Reserve empty rows so table fills. On last page reserve space for summary rows.
    // Count ALL rows appended on last page: labor/transport/discount + মোট ফিট + কথায়/জমা + optional prevDue + optional dueNow
    const extraSummaryRows = 2 + (showPrevDue && Math.round(prevDue) > 0 ? 2 : 0) + (Math.round(dueNow) > 0 ? 1 : 0);
    const summaryRowsCount = (hasLabor ? 1 : 0) + (hasTransport ? 1 : 0) + (discountAmt > 0 ? 1 : 0) + extraSummaryRows;
    const targetRows = isLast ? Math.max(0, PER_PAGE - summaryRowsCount) : PER_PAGE;
    const emptyCount = Math.max(0, targetRows - chunk.length);
    const emptyHtml = Array.from({ length: emptyCount }).map(() =>
      `<tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>`).join("");

    const laborHtml = isLast && hasLabor ? `<tr>
      <td></td><td class="sumlbl">লেবারঃ</td><td></td>
      <td class="c">${toBnDigits(totalCartonsAll)}</td><td></td>
      <td class="c">${toBnDigits(laborRate)}</td>
      <td class="r">${toBnDigits(Math.round(laborAmount))}</td>
    </tr>` : "";
    const transportHtml = isLast && hasTransport ? `<tr>
      <td></td><td class="sumlbl">ভাড়াঃ</td><td colspan="4"></td>
      <td class="r">${toBnDigits(transportAmt)}</td>
    </tr>` : "";
    const discountHtml = isLast && discountAmt > 0 ? `<tr class="shade-row">
      <td colspan="4"></td>
      <td class="sumlbl" colspan="2">ছাড়ঃ</td>
      <td class="sumval">${toBnDigits(discountAmt)}</td>
    </tr>` : "";
    const summaryHtml = isLast ? `
      <tr class="sum-net">
        <td></td><td class="sumlbl">মোট ফিটঃ</td>
        <td class="c">${toBnDigits(totalFeetAll.toFixed(2))}</td>
        <td></td>
        <td class="sumlbl shade" colspan="2">মোট টাকাঃ</td>
        <td class="sumval shade">${toBnDigits((grandTotal + discountAmt).toFixed(0))}</td>
      </tr>
      ${discountHtml}
      ${showPrevDue && Math.round(prevDue) > 0 ? `<tr class="shade-row">
        <td colspan="4"></td>
        <td class="sumlbl" colspan="2">পূর্বের বাকিঃ</td>
        <td class="sumval">${toBnDigits(prevDue.toFixed(0))}</td>
      </tr>
      <tr class="sum-gross">
        <td colspan="4"></td>
        <td class="sumlbl" colspan="2">সর্বমোটঃ</td>
        <td class="sumval">${toBnDigits((grandTotal + discountAmt + prevDue).toFixed(0))}</td>
      </tr>` : ""}
      <tr class="shade-row">
        <td colspan="4" class="katha">কথায়: ${numToBnWords(grandTotal)} টাকা মাত্র</td>
        <td class="sumlbl" colspan="2">জমাঃ</td>
        <td class="sumval">${toBnDigits(paidAmt.toFixed(0))}</td>
      </tr>
      ${Math.round(dueNow) > 0 ? `<tr class="shade-row sum-due">
        <td colspan="4"></td>
        <td class="sumlbl" colspan="2">বাকিঃ</td>
        <td class="sumval">${toBnDigits(dueNow.toFixed(0))}</td>
      </tr>` : ""}` : "";

    const footerHtml = isLast ? `
      <div class="foot-note">সরবরাহের পর কোন প্রকার অভিযোগ গ্রহণযোগ্য নয়</div>
      <div class="sign">
        <div>গ্রাহকের স্বাক্ষর</div>
        <div style="text-align:right"><span class="hasan">Hasan</span><br>পক্ষেঃ আলম টাইলস</div>
      </div>` : "";

    return `<div class="wrap page-break">
      <div class="top">
        <div class="logo">${INVOICE_LOGO_SVG}</div>
        <div class="center">
          <div class="bil">বিল মেমো</div>
          <div class="name">${SHOP.nameBn}</div>
          <div class="en">ALAM TILES</div>
        </div>
        <div class="right">
          <div>মোবাইলঃ</div>
          <div>হাসানঃ 0175-7770796</div>
          <div>0162-1176784</div>
          <div>বড় কালি বাড়ি রোড,</div>
          <div>টাংগাইল।</div>
        </div>
      </div>
      <div class="tag">সকল প্রকার টাইলস, মার্বেল পাথর, সিনারী, বর্ডার সামগ্রী পাইকারী ও খুচরা বিক্রেতা<br>এবং সরবরাহকারক। ডিলারঃ কুংফু সিরামিক্স, তুষার সিরামিক্স।</div>
      <table class="meta">
        <tr>
          <td class="lbl">নামঃ</td><td>${custName}</td>
          <td class="date-lbl">তারিখঃ</td><td class="date-val">${toBnDigits(dateStr)}</td>
        </tr>
        <tr><td class="lbl">মোবাইলঃ</td><td colspan="3">${toBnDigits(custMobile)}</td></tr>
        <tr><td class="lbl">ঠিকানাঃ</td><td colspan="3">${custAddress}</td></tr>
      </table>
      <div class="billno">বিল নং ${toBnDigits(invNum)}</div>
      <table class="items" style="table-layout:fixed">
        <colgroup>
          <col style="width:8mm" /><col style="width:45mm" /><col style="width:14mm" /><col style="width:14mm" /><col style="width:10mm" /><col style="width:10mm" /><col style="width:22mm" />
        </colgroup>
        <thead><tr>
          <th>নং</th><th>বিবরণ</th><th>ফুট</th>
          <th>কাটুন</th><th>পিছ</th>
          <th>দর</th><th>মোট টাকা</th>
        </tr></thead>
        <tbody>
          ${rowsHtml}
          ${emptyHtml}
          ${laborHtml}
          ${transportHtml}
          ${summaryHtml}
        </tbody>
      </table>
      ${footerHtml}
      <div class="page">পৃষ্ঠা ${toBnDigits(chunkIdx + 1)} / ${toBnDigits(totalPages)}</div>
    </div>`;
  };

  const pagesHtml = chunks.map((chunk, idx) => buildPage(chunk, idx, idx * PER_PAGE)).join("");

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${s.invoice_no}</title>
<style>${INVOICE_CSS}
.toolbar{position:sticky;top:0;background:#f3f4f6;padding:8px;text-align:center;border-bottom:1px solid #ddd;z-index:10}
.toolbar button{background:#2563eb;color:#fff;border:0;padding:8px 22px;border-radius:6px;font-size:14px;cursor:pointer;font-weight:600}
@media print{.toolbar{display:none}}
</style></head><body>
${opts.preview ? '<div class="toolbar no-print"><button onclick="window.print()">Print</button></div>' : ''}
${pagesHtml}
${opts.preview ? '' : '<script>window.onload=function(){setTimeout(function(){window.print();},300);}</script>'}
</body></html>`;
}


function buildGodownSlipHtml(s: Sale, c: Customer | undefined, productMap: Map<string, Product>): string {
  const dateStr = new Date(s.sale_date).toLocaleDateString("en-GB");
  const invNum = s.invoice_no.replace(/\D/g, "").slice(-4) || s.invoice_no;
  const rows = s.items;
  const minRows = 11;
  const emptyCount = Math.max(0, minRows - rows.length);
  const rowsHtml = rows.map((it, i) => {
    const p = productMap.get(it.productId);
    const name = p?.name ?? "—";
    const ppc = p?.pcs_per_carton ?? 0;
    const leftoverPcs = ppc > 0 ? Number(it.pieces ?? 0) % ppc : Number(it.pieces ?? 0);
    const cartons = Number(it.cartons) ? toBnDigits(Number(it.cartons)) : "";
    const pcs = leftoverPcs ? toBnDigits(leftoverPcs) : "";
    return `<tr>
      <td class="c sl">${toBnDigits(String(i + 1).padStart(2, "0"))}</td>
      <td>${name}</td>
      <td class="c">${cartons}</td>
      <td class="c">${pcs}</td>
    </tr>`;
  }).join("");
  const emptyHtml = Array.from({ length: emptyCount }).map((_, i) =>
    `<tr><td class="c sl">${toBnDigits(String(rows.length + i + 1).padStart(2, "0"))}</td><td></td><td></td><td></td></tr>`
  ).join("");

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Godown Slip ${s.invoice_no}</title>
<style>
  @page { size: A5; margin: 8mm; }
  * { box-sizing: border-box; }
  body { font-family: 'SolaimanLipi','Noto Sans Bengali',Arial,sans-serif; color:#0a2a5e; margin:0; padding:8px; }
  .slip { max-width: 380px; margin: 0 auto; border: 1px solid #0a2a5e; padding: 12px 16px; }
  .shop { text-align:center; font-size: 28px; font-weight: 900; letter-spacing: 2px; line-height:1; font-style: italic; }
  .addr { text-align:center; font-size: 12px; margin-top: 4px; }
  .phone { text-align:center; font-size: 12px; margin-top: 2px; }
  .title-wrap { text-align:center; margin: 8px 0 6px; }
  .title { display:inline-block; border:1.5px solid #0a2a5e; border-radius: 999px; padding: 2px 16px; font-size: 14px; font-weight: 700; }
  .meta { display:flex; justify-content:space-between; font-size: 12px; margin: 6px 2px; }
  .meta .l { display:flex; flex-direction:column; gap:3px; }
  .meta .r { text-align:right; }
  table { width:100%; border-collapse: collapse; margin-top: 6px; }
  th, td { border: 1px solid #0a2a5e; padding: 4px 6px; font-size: 12px; height: 22px; }
  th { font-weight: 600; text-align:center; background:#fff; }
  td.c { text-align:center; }
  td.sl { width: 12%; }
  th.descr { width: 52%; }
  .signs { display:flex; justify-content:space-between; align-items:flex-end; margin-top: 12px; font-size: 11px; gap: 10px; }
  .signs .col { text-align:center; flex:1; }
  .signs .line { border-top: 1px dotted #0a2a5e; padding-top: 4px; }
  .dealers { display:flex; flex-direction:column; gap:3px; align-items:center; }
  .dealer { border:1px solid #0a2a5e; padding: 2px 8px; font-size: 11px; border-radius: 2px; }
  .toolbar{position:sticky;top:0;background:#f3f4f6;padding:8px;text-align:center;border-bottom:1px solid #ddd;z-index:10}
  .toolbar button{background:#2563eb;color:#fff;border:0;padding:8px 22px;border-radius:6px;font-size:14px;cursor:pointer;font-weight:600}
  @media print { .toolbar { display:none } body { padding:0 } .slip { border:none } }
</style></head><body>
<div class="toolbar no-print"><button onclick="window.print()">Print</button></div>
<div class="slip">
  <div class="shop">আলম টাইলস্</div>
  <div class="addr">${SHOP.address}</div>
  <div class="phone">মোবাইলঃ ০১৭১৬-২২২৩৪৬, ০১৬২১১-৭৬৭৮৪</div>
  <div class="title-wrap"><span class="title">গোডাউন স্লিপ</span></div>
  <div class="meta">
    <div class="l">
      <div>ক্রমিক নংঃ ${toBnDigits(invNum)}</div>
      <div>চালান/মেমো নংঃ ${toBnDigits(s.invoice_no)}</div>
    </div>
    <div class="r">তারিখঃ ${toBnDigits(dateStr)}</div>
  </div>
  <table>
    <thead>
      <tr>
        <th>সংখ্যা</th>
        <th class="descr">দ্রব্যের বিবরণ</th>
        <th>বক্স/কার্টুন</th>
        <th>পিছ</th>
      </tr>
    </thead>
    <tbody>
      ${rowsHtml}
      ${emptyHtml}
    </tbody>
  </table>
  <div class="signs">
    <div class="col"><div class="line">গ্রহণকারীর স্বাক্ষর</div></div>
    <div class="col dealers">
      <div class="dealer">ডিলারঃ কুংফু সিরামিক্স</div>
      <div class="dealer">ডিলারঃ তুষার সিরামিক্স</div>
    </div>
    <div class="col"><div class="line">কর্তৃপক্ষের স্বাক্ষর</div></div>
  </div>
</div>
</body></html>`;
}

export default function SaleHistory({
  sales, customers, products, userId, refresh, onEditSale,
}: {
  sales: Sale[]; customers: Customer[]; products: Product[];
  userId: string | null; refresh: () => void | Promise<void>;
  onEditSale?: (id: string) => void;
}) {
  const productMap = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);
  const customerMap = useMemo(() => new Map(customers.map((c) => [c.id, c])), [customers]);

  const [origInv, setOrigInv] = useState("");
  const [custName, setCustName] = useState("");
  const [custMobile, setCustMobile] = useState("");
  const [custAddress, setCustAddress] = useState("");
  const [dateMode, setDateMode] = useState<DateMode>("all");
  const [customDate, setCustomDate] = useState("");
  const [rangeFrom, setRangeFrom] = useState("");
  const [rangeTo, setRangeTo] = useState("");
  const [pageSize, setPageSize] = useState(20);
  const [page, setPage] = useState(1);

  const [detailSale, setDetailSale] = useState<Sale | null>(null);
  const [editSale, setEditSale] = useState<Sale | null>(null);
  const [paySale, setPaySale] = useState<Sale | null>(null);

  const filtered = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const oi = origInv.trim().toLowerCase();
    const cn = custName.trim().toLowerCase();
    const cm = custMobile.trim().toLowerCase();
    const ca = custAddress.trim().toLowerCase();

    return sales.filter((s) => {
      if (dateMode === "today" && s.sale_date !== today) return false;
      if (dateMode === "custom" && customDate && s.sale_date !== customDate) return false;
      if (dateMode === "range") {
        if (rangeFrom && s.sale_date < rangeFrom) return false;
        if (rangeTo && s.sale_date > rangeTo) return false;
      }
      const c = s.customer_id ? customerMap.get(s.customer_id) : undefined;
      if (oi && !s.invoice_no.toLowerCase().includes(oi)) return false;
      if (cn && !(c?.name ?? "").toLowerCase().includes(cn)) return false;
      if (cm && !(c?.mobile ?? "").toLowerCase().includes(cm)) return false;
      if (ca && !(c?.address ?? "").toLowerCase().includes(ca)) return false;
      return true;
    });
  }, [sales, origInv, custName, custMobile, custAddress, dateMode, customDate, rangeFrom, rangeTo, customerMap]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const visible = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  function clearFilters() {
    setOrigInv(""); setCustName(""); setCustMobile(""); setCustAddress("");
    setDateMode("all"); setCustomDate(""); setRangeFrom(""); setRangeTo("");
  }

  function openInvoiceWindow(s: Sale, preview = false) {
    const html = buildInvoiceHtml(s, s.customer_id ? customerMap.get(s.customer_id) : undefined, productMap, { preview });
    const w = window.open("", "_blank");
    if (w) { w.document.open(); w.document.write(html); w.document.close(); }
  }
  async function handlePrint(s: Sale) { openInvoiceWindow(s); }
  function handleDownload(s: Sale) { openInvoiceWindow(s); }
  function handleGodownSlip(s: Sale) {
    const html = buildGodownSlipHtml(s, s.customer_id ? customerMap.get(s.customer_id) : undefined, productMap);
    const w = window.open("", "_blank");
    if (w) { w.document.open(); w.document.write(html); w.document.close(); }
  }
  function handlePreview(s: Sale) { openInvoiceWindow(s, true); }

  function handleWhatsApp(s: Sale) {
    const c = s.customer_id ? customerMap.get(s.customer_id) : undefined;
    const phone = (c?.mobile || "").replace(/\D/g, "");
    const intl = phone.startsWith("880") ? phone : phone.startsWith("0") ? "88" + phone.slice(1) : phone.length === 10 ? "880" + phone : phone;
    if (!intl) {
      alert("কাস্টমারের মোবাইল নম্বর নেই / No customer mobile");
      return;
    }
    const items = s.items || [];
    const itemLines = items.map((it, i) => {
      const p = productMap.get(it.productId);
      const rawName = p?.name || "Item";
      const name = rawName.length > 22 ? rawName.slice(0, 22) + "…" : rawName;
      return `${String(i + 1).padStart(2, "0")}. ${name}\n     ${it.pieces} pcs × ৳${Number(it.rate || 0).toFixed(2)} = ৳${Number(it.totalPrice || 0).toFixed(2)}`;
    }).join("\n");
    const totalPieces = items.reduce((sum, it) => sum + Number(it.pieces || 0), 0);
    const customerTotalDue = c ? Number(c.due_amount || 0) : Number(s.due_amount);
    const text =
`🏪 *${SHOP.nameEn}*
_${SHOP.nameBn}_
📍 ${SHOP.address}
📞 ${SHOP.phone}
━━━━━━━━━━━━━━━━━━
🧾 *Invoice:* ${s.invoice_no}
📅 ${new Date(s.sale_date).toLocaleDateString("en-GB")}
👤 ${c?.name || "Customer"}${c?.mobile ? `\n📱 ${c.mobile}` : ""}
━━━━━━━━━━━━━━━━━━
🛒 *Items (${items.length}, ${totalPieces} pcs):*
${itemLines}
━━━━━━━━━━━━━━━━━━
💰 *Total:*  ৳${Number(s.total_amount).toFixed(2)}
✅ *Paid:*   ৳${Number(s.paid_amount).toFixed(2)}
⚠️ *Due:*    ৳${Number(s.due_amount).toFixed(2)}${c && customerTotalDue !== Number(s.due_amount) ? `\n📊 *Total Due:* ৳${customerTotalDue.toFixed(2)}` : ""}
━━━━━━━━━━━━━━━━━━
আপনার কেনাকাটার জন্য ধন্যবাদ! 🙏
Thank you for shopping with us!`;
    openWhatsApp(intl, text);
  }


  async function handleDelete(s: Sale) {
    if (!confirm(`Delete invoice ${s.invoice_no}? This will restore stock and update customer due.`)) return;
    for (const it of s.items) {
      const p = productMap.get(it.productId); if (!p) continue;
      await supabase.from("products").update({ stock_pieces: p.stock_pieces + it.pieces }).eq("id", p.id);
    }
    if (s.customer_id) {
      const c = customerMap.get(s.customer_id);
      if (c) {
        const newDue = Math.max(0, Number(c.due_amount) - Number(s.due_amount));
        await supabase.from("customers").update({ due_amount: newDue }).eq("id", c.id);
      }
    }
    if (Number(s.paid_amount) > 0 && userId) {
      await supabase.from("cash_transactions").insert({
        user_id: userId, type: "out", amount: Number(s.paid_amount),
        reason: `Delete sale ${s.invoice_no}`, trans_date: new Date().toISOString().slice(0, 10),
      });
    }
    const { error } = await supabase.from("sales").delete().eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Invoice deleted");
    refresh();
  }

  async function handleReturn(s: Sale) {
    if (s.is_returned) return toast.info("Already marked as returned");
    if (!confirm(`Return all products from ${s.invoice_no}? Stock will be restored.`)) return;
    for (const it of s.items) {
      const p = productMap.get(it.productId); if (!p) continue;
      await supabase.from("products").update({ stock_pieces: p.stock_pieces + it.pieces }).eq("id", p.id);
    }
    const { error } = await supabase.from("sales").update({
      is_returned: true, returned_amount: Number(s.total_amount),
    }).eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Return recorded");
    refresh();
  }

  const inputCls = "w-full px-4 py-3 rounded-lg border border-gray-200 bg-white text-sm placeholder-gray-400 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-none";

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      <h1 className="text-center text-2xl font-semibold text-gray-700 mt-2">Sales History</h1>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl border border-gray-200 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input value={origInv} onChange={(e) => setOrigInv(e.target.value)} placeholder="Original Invoice" className={inputCls} />
          <input value={custName} onChange={(e) => setCustName(e.target.value)} placeholder="Customer Name" className={inputCls} />
          <input value={custMobile} onChange={(e) => setCustMobile(e.target.value)} placeholder="Mobile Number" className={inputCls} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input value={custAddress} onChange={(e) => setCustAddress(e.target.value)} placeholder="Address" className={inputCls} />
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          {([
            ["all", "All"], ["today", "Today"], ["custom", "Custom Date"], ["range", "Date Range"],
          ] as const).map(([k, label]) => (
            <button key={k} onClick={() => setDateMode(k as DateMode)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                dateMode === k ? "bg-blue-600 text-white shadow" : "bg-gray-50 text-gray-700 hover:bg-gray-100"
              }`}>{label}</button>
          ))}
          {dateMode === "custom" && (
            <input type="date" value={customDate} onChange={(e) => setCustomDate(e.target.value)}
              className="px-3 py-2 rounded-lg border border-gray-200 text-sm" />
          )}
          {dateMode === "range" && (
            <>
              <input type="date" value={rangeFrom} onChange={(e) => setRangeFrom(e.target.value)}
                className="px-3 py-2 rounded-lg border border-gray-200 text-sm" />
              <span className="text-gray-400">—</span>
              <input type="date" value={rangeTo} onChange={(e) => setRangeTo(e.target.value)}
                className="px-3 py-2 rounded-lg border border-gray-200 text-sm" />
            </>
          )}
          <div className="ml-auto">
            <button onClick={clearFilters}
              className="px-4 py-2 rounded-lg bg-red-500 text-white text-sm font-medium hover:bg-red-600">Clear Filters</button>
          </div>
        </div>

        <div className="flex items-center gap-2 text-sm text-gray-600">
          <span>Show:</span>
          <select value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
            className="px-2 py-1 rounded border border-gray-200 bg-white">
            {[10, 20, 50, 100, 200].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
          <span>entries</span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-gray-600 text-left">
              <tr>
                <th className="p-3 font-semibold">Invoice</th>
                <th className="p-3 font-semibold">Date</th>
                <th className="p-3 font-semibold">Customer Id</th>
                <th className="p-3 font-semibold">Customer Info</th>
                <th className="p-3 font-semibold text-right">Total Due</th>
                <th className="p-3 font-semibold text-right">Paid</th>
                <th className="p-3 font-semibold text-right">Due</th>
                <th className="p-3 font-semibold text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {visible.length === 0 && (
                <tr><td colSpan={8} className="p-8 text-center text-gray-400">No invoices found</td></tr>
              )}
              {visible.map((s) => {
                const c = s.customer_id ? customerMap.get(s.customer_id) : undefined;
                return (
                  <tr key={s.id} className="border-t border-gray-100 hover:bg-blue-50/30">
                    <td className="p-3 font-medium">{s.invoice_no}</td>
                    <td className="p-3 text-gray-600">{s.sale_date}</td>
                    <td className="p-3 text-gray-700">{custCode(customers, s.customer_id)}</td>
                    <td className="p-3">
                      <div className="text-blue-600 font-medium">{c?.name ?? "Walk-in"}</div>
                      <div className="text-gray-500 text-xs">{c?.address ?? ""}</div>
                      <div className="text-gray-500 text-xs">{c?.mobile ?? ""}</div>
                    </td>
                    <td className="p-3 text-right">{Number(s.total_amount).toFixed(0)}</td>
                    <td className="p-3 text-right text-emerald-600">৳{Number(s.paid_amount).toFixed(0)}</td>
                    <td className="p-3 text-right">{Number(s.due_amount).toFixed(0)}</td>
                    <td className="p-3">
                      <div className="flex items-center justify-center gap-1.5 flex-wrap">
                        <button onClick={() => handlePreview(s)} title="Preview Invoice"
                          className="p-2 rounded-md bg-emerald-100 text-emerald-700 hover:bg-emerald-200">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button onClick={() => handlePrint(s)} title="Print Invoice"
                          className="p-2 rounded-md bg-slate-700 text-white hover:bg-slate-800">
                          <Printer className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleGodownSlip(s)} title="Godown Slip"
                          className="px-2 py-2 rounded-md bg-amber-500 text-white text-xs font-semibold hover:bg-amber-600">
                          গোডাউন
                        </button>
                        <button onClick={() => onEditSale ? onEditSale(s.id) : setEditSale(s)} title="Edit"
                          className="p-2 rounded-md bg-violet-100 text-violet-700 hover:bg-violet-200">
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button onClick={() => setDetailSale(s)}
                          className="px-3 py-2 rounded-md bg-blue-600 text-white text-sm font-medium hover:bg-blue-700">
                          Details
                        </button>
                        <button onClick={() => handleDelete(s)} title="Delete"
                          className="p-2 rounded-md bg-red-500 text-white hover:bg-red-600">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

            </tbody>
          </table>
        </div>
      </div>

      <Pager page={currentPage} totalPages={totalPages} total={filtered.length} pageSize={pageSize} onPage={setPage} />



      {detailSale && (
        <DetailsModal
          sale={detailSale}
          customers={customers}
          customer={detailSale.customer_id ? customerMap.get(detailSale.customer_id) : undefined}
          productMap={productMap}
          onClose={() => setDetailSale(null)}
          onPrint={() => handlePrint(detailSale)}
          onPdf={() => handleDownload(detailSale)}
          onPreview={() => handlePreview(detailSale)}
          onWhatsApp={() => handleWhatsApp(detailSale)}
          onPay={() => { setPaySale(detailSale); setDetailSale(null); }}
          onEdit={() => { if (onEditSale) { onEditSale(detailSale.id); setDetailSale(null); } else { setEditSale(detailSale); setDetailSale(null); } }}
          onReturn={() => handleReturn(detailSale)}
          onDelete={() => handleDelete(detailSale)}
        />
      )}
      {paySale && (
        <PaymentModal sale={paySale} userId={userId} customerMap={customerMap}
          onDone={() => { setPaySale(null); refresh(); }} onClose={() => setPaySale(null)} />
      )}
      {editSale && (
        <EditModal sale={editSale} customers={customers} productMap={productMap} userId={userId}
          onDone={() => { setEditSale(null); refresh(); }} onClose={() => setEditSale(null)} />
      )}
    </div>
  );
}

function Pager({ page, totalPages, total, pageSize, onPage }: {
  page: number; totalPages: number; total: number; pageSize: number; onPage: (p: number) => void;
}) {
  if (total === 0) return null;
  const from = (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, total);
  const nums: number[] = [];
  const start = Math.max(1, page - 2);
  const end = Math.min(totalPages, start + 4);
  for (let i = start; i <= end; i++) nums.push(i);
  const btn = "px-3 py-1.5 rounded-md border border-gray-200 bg-white text-sm hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed";
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 px-1">
      <div className="text-sm text-gray-600">Showing {from}–{to} of {total}</div>
      <div className="flex items-center gap-1">
        <button className={btn} disabled={page <= 1} onClick={() => onPage(1)}>«</button>
        <button className={btn} disabled={page <= 1} onClick={() => onPage(page - 1)}>Prev</button>
        {nums.map((n) => (
          <button key={n} onClick={() => onPage(n)}
            className={`px-3 py-1.5 rounded-md text-sm border ${n === page ? "bg-blue-600 text-white border-blue-600" : "bg-white border-gray-200 hover:bg-gray-50"}`}>
            {n}
          </button>
        ))}
        <button className={btn} disabled={page >= totalPages} onClick={() => onPage(page + 1)}>Next</button>
        <button className={btn} disabled={page >= totalPages} onClick={() => onPage(totalPages)}>»</button>
      </div>
    </div>
  );
}

function Modal({ children, onClose, wide }: { children: React.ReactNode; onClose: () => void; wide?: boolean }) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className={`bg-white rounded-2xl shadow-2xl w-full ${wide ? "max-w-[1400px]" : "max-w-md"} max-h-[90vh] overflow-y-auto`}>
        <div className="sticky top-0 bg-white border-b px-5 py-3 flex items-center justify-between">
          <div />
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

// ---- Details modal (matches the screenshot) ----
function DetailsModal({
  sale, customers, customer, productMap, onClose,
  onPrint, onPdf, onPreview, onWhatsApp, onPay, onEdit, onReturn, onDelete,
}: {
  sale: Sale; customers: Customer[]; customer: Customer | undefined; productMap: Map<string, Product>;
  onClose: () => void;
  onPrint: () => void; onPdf: () => void; onPreview: () => void; onWhatsApp: () => void;
  onPay: () => void; onEdit: () => void; onReturn: () => void; onDelete: () => void;
}) {
  const items = sale.items;
  const subtotal = items.reduce((s, it) => s + Number(it.totalPrice), 0);
  const grandTotal = Number(sale.total_amount);
  const discount = Math.max(0, subtotal - grandTotal);
  const profit = computeProfit(sale, productMap);
  const previousDue = 0;
  const code = custCode(customers, sale.customer_id);

  const cellCls = "border border-gray-300 p-2 text-sm align-top";
  const headCls = "border border-gray-300 p-2 text-sm font-semibold bg-slate-100 text-gray-700 text-left";

  return (
    <Modal wide onClose={onClose}>
      <h2 className="text-center text-xl font-semibold mb-4">Invoice Number: {sale.invoice_no} Details</h2>
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className={headCls}>Invoice</th>
              <th className={headCls}>Date</th>
              <th className={headCls}>Customer Info</th>
              <th className={headCls}>Product Name</th>
              <th className={headCls}>Quantity</th>
              <th className={headCls}>Price</th>
              <th className={headCls}>Total</th>
              <th className={headCls}>Subtotal</th>
              <th className={headCls}>Discount</th>
              <th className={headCls}>Grand Total</th>
              <th className={headCls}>Profit</th>
              <th className={headCls}>Previous Due</th>
              <th className={headCls}>Total Due</th>
              <th className={headCls}>Paid</th>
              <th className={headCls}>Due</th>
              <th className={headCls}>Print</th>
              <th className={headCls}>Edit</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, i) => {
              const p = productMap.get(it.productId);
              const isFirst = i === 0;
              const rowCount = items.length;
              return (
                <tr key={i}>
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{sale.invoice_no}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{sale.sale_date}</td>}
                  {isFirst && (
                    <td className={cellCls} rowSpan={rowCount}>
                      <div className="text-blue-600 font-medium">{code}</div>
                      <div className="text-blue-600">{customer?.name ?? "Walk-in"}</div>
                      <div className="text-gray-600 text-xs">{customer?.address ?? ""}</div>
                      <div className="text-gray-600 text-xs">{customer?.mobile ?? ""}</div>
                    </td>
                  )}
                  <td className={cellCls}>{p?.name ?? "—"}{p?.size ? ` ${p.size}` : ""}</td>
                  <td className={cellCls}>{it.feet != null ? `${Number(it.feet).toFixed(2)} feet` : `${it.pieces} pcs`}</td>
                  <td className={cellCls}>{it.rate ?? "—"}</td>
                  <td className={cellCls}>{Number(it.totalPrice).toFixed(0)}</td>
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{subtotal.toFixed(0)}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{discount.toFixed(0)}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{grandTotal.toFixed(0)}</td>}
                  {isFirst && <td className={`${cellCls} text-emerald-600 font-medium`} rowSpan={rowCount}>{profit.toFixed(0)}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{previousDue.toFixed(0)}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{grandTotal.toFixed(0)}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{Number(sale.paid_amount).toFixed(0)}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{Number(sale.due_amount).toFixed(0)}</td>}
                  {isFirst && (
                    <td className={cellCls} rowSpan={rowCount}>
                      <button onClick={onPrint}
                        className="px-3 py-1.5 rounded-md bg-slate-700 text-white text-xs font-medium hover:bg-slate-800 flex items-center gap-1">
                        <Printer className="w-3.5 h-3.5" /> Print
                      </button>
                    </td>
                  )}
                  {isFirst && (
                    <td className={cellCls} rowSpan={rowCount}>
                      <button onClick={onEdit}
                        className="p-2 rounded-md bg-violet-100 text-violet-700 hover:bg-violet-200">
                        <Pencil className="w-4 h-4" />
                      </button>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap justify-end gap-2 mt-5">
        <button onClick={onPreview} className="px-3 py-2 rounded-lg bg-emerald-600 text-white text-sm flex items-center gap-1.5"><Eye className="w-4 h-4" /> Preview</button>
        <button onClick={onPdf} className="px-3 py-2 rounded-lg bg-indigo-600 text-white text-sm flex items-center gap-1.5"><Download className="w-4 h-4" /> PDF</button>
        <button onClick={onWhatsApp} className="px-3 py-2 rounded-lg bg-emerald-600 text-white text-sm flex items-center gap-1.5"><MessageSquare className="w-4 h-4" /> WhatsApp</button>
        <button onClick={onPay} className="px-3 py-2 rounded-lg bg-amber-500 text-white text-sm flex items-center gap-1.5"><Wallet className="w-4 h-4" /> Payment</button>
        <button onClick={onReturn} className="px-3 py-2 rounded-lg bg-orange-500 text-white text-sm flex items-center gap-1.5"><Undo2 className="w-4 h-4" /> Return</button>
        <button onClick={onDelete} className="px-3 py-2 rounded-lg bg-red-500 text-white text-sm flex items-center gap-1.5"><Trash2 className="w-4 h-4" /> Delete</button>
      </div>
    </Modal>
  );
}


function Summary({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="p-3 rounded-xl bg-slate-50 border">
      <div className="text-xs text-gray-500">{label}</div>
      <div className={`text-lg font-bold ${color}`}>{value}</div>
    </div>
  );
}

// ---- Payment Receive Modal ----
function PaymentModal({
  sale, userId, customerMap, onDone, onClose,
}: {
  sale: Sale; userId: string | null; customerMap: Map<string, Customer>;
  onDone: () => void; onClose: () => void;
}) {
  const [amount, setAmount] = useState("");
  const due = Number(sale.due_amount);

  async function submit() {
    const amt = Number(amount);
    if (!amt || amt <= 0) return toast.error("Enter a valid amount");
    if (amt > due) return toast.error("Amount exceeds due");
    const newPaid = Number(sale.paid_amount) + amt;
    const newDue = Math.max(0, due - amt);
    const { error } = await supabase.from("sales").update({ paid_amount: newPaid, due_amount: newDue }).eq("id", sale.id);
    if (error) return toast.error(error.message);
    if (sale.customer_id) {
      const c = customerMap.get(sale.customer_id);
      if (c) {
        const cDue = Math.max(0, Number(c.due_amount) - amt);
        await supabase.from("customers").update({ due_amount: cDue }).eq("id", c.id);
      }
    }
    if (userId) {
      await supabase.from("cash_transactions").insert({
        user_id: userId, type: "in", amount: amt,
        reason: `Payment ${sale.invoice_no}`, trans_date: new Date().toISOString().slice(0, 10),
      });
    }
    toast.success("Payment received");
    onDone();
  }

  return (
    <Modal onClose={onClose}>
      <h3 className="text-lg font-bold mb-1">Receive Payment</h3>
      <p className="text-xs text-gray-500 mb-4">Invoice {sale.invoice_no} • Due ৳{due.toFixed(2)}</p>
      <label className="text-xs text-gray-600">Amount</label>
      <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)}
        className="w-full mt-1 px-3 py-2 rounded-xl border" placeholder="0.00" />
      <div className="flex justify-end gap-2 mt-4">
        <button onClick={onClose} className="px-4 py-2 rounded-xl border text-sm">Cancel</button>
        <button onClick={submit} className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm">Receive</button>
      </div>
    </Modal>
  );
}

// ---- Edit Modal ----
function EditModal({
  sale, customers, productMap, userId, onDone, onClose,
}: {
  sale: Sale; customers: Customer[]; productMap: Map<string, Product>;
  userId: string | null; onDone: () => void; onClose: () => void;
}) {
  const [customerId, setCustomerId] = useState<string | null>(sale.customer_id);
  const [items, setItems] = useState<SaleItem[]>(sale.items.map((it) => ({ ...it })));
  const [paid, setPaid] = useState(String(sale.paid_amount));
  const [discount, setDiscount] = useState("0");

  const subtotal = items.reduce((s, it) => s + Number(it.totalPrice), 0);
  const total = Math.max(0, subtotal - Number(discount || 0));
  const due = Math.max(0, total - Number(paid || 0));

  function updateItem(i: number, patch: Partial<SaleItem>) {
    setItems((arr) => arr.map((it, idx) => {
      if (idx !== i) return it;
      const next = { ...it, ...patch };
      const p = productMap.get(next.productId);
      const ppc = p ? (Number(p.pcs_per_carton) || 1) : 1;
      // recompute pieces from cartons if provided
      if (patch.cartons !== undefined && p) {
        next.pieces = Number(patch.cartons) * ppc + (next.pieces % ppc);
      }
      if (p) {
        next.feet = next.pieces * Number(p.sqft_per_piece);
        next.totalPrice = next.feet * Number(next.rate ?? p.sell_price_per_piece);
      }

      return next;
    }));
  }

  function removeItem(i: number) {
    setItems((arr) => arr.filter((_, idx) => idx !== i));
  }

  function addBlankRow() {
    setItems((arr) => [
      ...arr,
      { productId: "", cartons: 0, pieces: 0, feet: 0, rate: 0, totalPrice: 0 },
    ]);
  }

  function changeProduct(i: number, pid: string) {
    if (!pid) return;
    if (items.some((it, idx) => idx !== i && it.productId === pid)) {
      toast.error("এই পণ্য ইতিমধ্যে যোগ করা আছে");
      return;
    }
    const p = productMap.get(pid);
    if (!p) return;
    setItems((arr) => arr.map((it, idx) => idx !== i ? it : {
      ...it,
      productId: pid,
      rate: it.rate || Number(p.sell_price_per_piece),
      feet: it.pieces * Number(p.sqft_per_piece),
      totalPrice: (it.pieces * Number(p.sqft_per_piece)) * Number(it.rate || p.sell_price_per_piece),
    }));

  }

  const customer = customers.find((c) => c.id === customerId);
  const totalFeet = items.reduce((s, it) => s + Number(it.feet ?? 0), 0);
  const previousDue = Math.max(0, Number(customer?.due_amount ?? 0) - Number(sale.due_amount));
  const totalDue = due + previousDue;

  async function save() {
    if (customerId) {
      const c = customers.find((x) => x.id === customerId);
      if (!c?.name?.trim()) return toast.error("কাস্টমারের নাম লিখুন / Customer Name is required");
      if (!c?.mobile?.trim()) return toast.error("কাস্টমারের মোবাইল নম্বর লিখুন / Customer Mobile is required");
    }

    // restore old stock then deduct new
    for (const it of sale.items) {
      const p = productMap.get(it.productId); if (!p) continue;
      await supabase.from("products").update({ stock_pieces: p.stock_pieces + it.pieces }).eq("id", p.id);
    }
    for (const it of items) {
      if (!it.productId) continue;
      const p = productMap.get(it.productId); if (!p) continue;
      const restoredStock = p.stock_pieces + (sale.items.find((x) => x.productId === it.productId)?.pieces ?? 0);
      const newStock = restoredStock - it.pieces;
      if (newStock < 0) {
        toast.error(`Insufficient stock for ${p.name}`);
        await supabase.from("products").update({ stock_pieces: p.stock_pieces }).eq("id", p.id);
        return;
      }
      await supabase.from("products").update({ stock_pieces: newStock }).eq("id", p.id);
    }

    const cleanItems = items.filter((it) => it.productId);
    const { error } = await supabase.from("sales").update({
      customer_id: customerId,
      items: JSON.parse(JSON.stringify(cleanItems)),
      total_amount: total,
      paid_amount: Number(paid || 0),
      due_amount: due,
    }).eq("id", sale.id);
    if (error) return toast.error(error.message);

    if (customerId) {
      const c = customers.find((x) => x.id === customerId);
      if (c) {
        const delta = due - Number(sale.due_amount);
        const newDue = Math.max(0, Number(c.due_amount) + delta);
        await supabase.from("customers").update({ due_amount: newDue }).eq("id", c.id);
      }
    }
    const cashDelta = Number(paid || 0) - Number(sale.paid_amount);
    if (cashDelta !== 0 && userId) {
      await supabase.from("cash_transactions").insert({
        user_id: userId, type: cashDelta > 0 ? "in" : "out", amount: Math.abs(cashDelta),
        reason: `Edit sale ${sale.invoice_no}`, trans_date: new Date().toISOString().slice(0, 10),
      });
    }
    toast.success("Sale updated");
    onDone();
  }

  const allProducts = useMemo(
    () => Array.from(productMap.values()).sort((a, b) => a.name.localeCompare(b.name)),
    [productMap]
  );

  return (
    <Modal wide onClose={onClose}>
      <div className="bg-slate-600 text-white text-center py-2 rounded-t-lg -mt-2 -mx-2 mb-4">
        <h3 className="text-base font-bold tracking-wide">INVOICE FORM UPDATE — {sale.invoice_no}</h3>
      </div>

      {/* Customer Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
        <div>
          <label className="text-xs text-gray-600">Customer *</label>
          <select value={customerId ?? ""} onChange={(e) => setCustomerId(e.target.value || null)}
            className="w-full mt-1 px-3 py-2 rounded-lg border bg-white">
            <option value="">Walk-in</option>
            {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs text-gray-600">Customer Address</label>
          <div className="mt-1 px-3 py-2 rounded-lg border bg-slate-50 text-sm min-h-[40px]">{customer?.address ?? "—"}</div>
        </div>
        <div>
          <label className="text-xs text-gray-600">Customer Mobile</label>
          <div className="mt-1 px-3 py-2 rounded-lg border bg-slate-50 text-sm min-h-[40px]">{customer?.mobile ?? "—"}</div>
        </div>
      </div>

      {/* Items table */}
      <div className="overflow-x-auto border rounded-lg">
        <table className="w-full text-sm">
          <thead className="bg-slate-100">
            <tr className="text-slate-700">
              <th className="p-2 text-center w-12">SI</th>
              <th className="p-2 text-left">Product Name</th>
              <th className="p-2 text-center">Stock</th>
              <th className="p-2 text-center">Purchase Price</th>
              <th className="p-2 text-center">Caton</th>
              <th className="p-2 text-center">Pcs</th>
              <th className="p-2 text-center">Sell Feet</th>
              <th className="p-2 text-center">Sell Price</th>
              <th className="p-2 text-right">Total</th>
              <th className="p-2 text-center">Remove</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, i) => {
              const p = productMap.get(it.productId);
              const ppc = p ? (Number(p.pcs_per_carton) || 1) : 1;
              const cartonsVal = p ? Math.floor(it.pieces / ppc) : (it.cartons ?? 0);
              const leftoverPcs = p ? it.pieces % ppc : 0;
              return (
                <tr key={i} className="border-t">
                  <td className="p-2 text-center">{i + 1}</td>
                  <td className="p-2">
                    <select value={it.productId} onChange={(e) => changeProduct(i, e.target.value)}
                      className="w-full px-2 py-1 rounded border bg-white">
                      <option value="">— পণ্য বাছাই করুন —</option>
                      {allProducts.map((pr) => (
                        <option key={pr.id} value={pr.id}>{pr.name}{pr.size ? ` • ${pr.size}` : ""}</option>
                      ))}
                    </select>
                  </td>
                  <td className="p-2 text-center text-gray-700">{p?.stock_pieces ?? "—"}</td>
                  <td className="p-2 text-center text-gray-700">{p ? Number(p.purchase_price_per_piece).toFixed(0) : "—"}</td>
                  <td className="p-2 text-center">
                    <NumInput value={cartonsVal} onChange={(v) => {
                      updateItem(i, { cartons: v, pieces: v * ppc + leftoverPcs });
                    }} />
                  </td>
                  <td className="p-2 text-center">
                    <NumInput value={leftoverPcs} onChange={(v) => {
                      updateItem(i, { pieces: cartonsVal * ppc + v });
                    }} />
                  </td>
                  <td className="p-2 text-center font-medium">{Number(it.feet ?? 0).toFixed(2)}</td>
                  <td className="p-2 text-center">
                    <NumInput value={it.rate ?? 0} onChange={(v) => updateItem(i, { rate: v })} />
                  </td>
                  <td className="p-2 text-right font-semibold">৳{Number(it.totalPrice).toFixed(0)}</td>
                  <td className="p-2 text-center">
                    <button onClick={() => removeItem(i)}
                      className="px-3 py-1 rounded bg-red-500 text-white text-xs hover:bg-red-600">Remove</button>
                  </td>
                </tr>
              );
            })}
            {items.length === 0 && (
              <tr><td colSpan={10} className="p-4 text-center text-gray-400">কোন পণ্য নেই — Add Product চাপুন</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-3">
        <button onClick={addBlankRow}
          className="px-4 py-2 rounded-lg bg-sky-600 text-white text-sm flex items-center gap-1 hover:bg-sky-700">
          <Plus className="w-4 h-4" /> Add Product
        </button>
      </div>

      {/* Totals */}
      <div className="mt-5 border-t pt-4">
        <div className="flex flex-wrap gap-x-8 gap-y-2 text-sm mb-3 justify-center">
          <div><span className="text-gray-600">Total Feet:</span> <span className="font-semibold">{totalFeet.toFixed(2)}</span></div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Field label="Subtotal"><div className="px-3 py-2 rounded-lg bg-slate-50 border font-semibold">৳{subtotal.toFixed(0)}</div></Field>
          <Field label="Discount">
            <input type="number" value={discount} onChange={(e) => setDiscount(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border" />
          </Field>
          <Field label="Grand Total"><div className="px-3 py-2 rounded-lg bg-slate-50 border font-semibold">৳{total.toFixed(0)}</div></Field>
          <Field label="Previous Due"><div className="px-3 py-2 rounded-lg bg-slate-50 border">৳{previousDue.toFixed(0)}</div></Field>
          <Field label="Total Due"><div className="px-3 py-2 rounded-lg bg-amber-50 border border-amber-200 font-semibold">৳{totalDue.toFixed(0)}</div></Field>
          <Field label="Paid">
            <input type="number" value={paid} onChange={(e) => setPaid(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border" />
          </Field>
          <Field label="Due"><div className="px-3 py-2 rounded-lg bg-rose-50 text-rose-600 border border-rose-200 font-semibold">৳{due.toFixed(0)}</div></Field>
        </div>
      </div>

      <div className="flex justify-end gap-2 mt-5">
        <button onClick={onClose} className="px-4 py-2 rounded-lg border text-sm">Cancel</button>
        <button onClick={save} className="px-6 py-2 rounded-lg bg-violet-600 text-white text-sm font-semibold hover:bg-violet-700">Submit</button>
      </div>
    </Modal>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs text-gray-600">{label}</label>
      <div className="mt-1">{children}</div>
    </div>
  );
}

function NumInput({ value, onChange }: { value: number; onChange: (n: number) => void }) {
  return (
    <input type="number" value={value}
      onChange={(e) => onChange(Number(e.target.value) || 0)}
      className="w-20 px-2 py-1 rounded-lg border text-center" />
  );
}
