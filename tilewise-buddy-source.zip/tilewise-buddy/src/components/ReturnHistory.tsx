import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Printer, Download, MessageSquare, Undo2, X, Eye, Pencil, Trash2 } from "lucide-react";
import { INVOICE_CSS, INVOICE_LOGO_SVG } from "@/lib/invoice-style";
import { openWhatsApp } from "@/lib/whatsapp";

const SHOP_BN = { nameBn: "আলম টাইলস" };
const toBnDigits = (s: string | number) => String(s).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
function numToBnWords(num: number): string {
  num = Math.round(num);
  if (num === 0) return "শূন্য";
  const ones = ["", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়", "দশ", "এগারো", "বারো", "তেরো", "চৌদ্দ", "পনেরো", "ষোলো", "সতেরো", "আঠারো", "ঊনিশ", "বিশ", "একুশ", "বাইশ", "তেইশ", "চব্বিশ", "পঁচিশ", "ছাব্বিশ", "সাতাশ", "আঠাশ", "ঊনত্রিশ", "ত্রিশ", "একত্রিশ", "বত্রিশ", "তেত্রিশ", "চৌত্রিশ", "পঁইত্রিশ", "ছত্রিশ", "সাঁইত্রিশ", "আটত্রিশ", "ঊনচল্লিশ", "চল্লিশ", "একচল্লিশ", "বিয়াল্লিশ", "তেতাল্লিশ", "চুয়াল্লিশ", "পঁইতাল্লিশ", "ছিচল্লিশ", "সাতচল্লিশ", "আটচল্লিশ", "ঊনপঞ্চাশ", "পঞ্চাশ", "একান্ন", "বায়ান্ন", "তিপ্পান্ন", "চুয়ান্ন", "পঞ্চান্ন", "ছাপ্পান্ন", "সাতান্ন", "আটান্ন", "ঊনষাট", "ষাট", "একষট্টি", "বাষট্টি", "তেষট্টি", "চৌষট্টি", "পঁইষট্টি", "ছিষট্টি", "সাতষট্টি", "আটষট্টি", "ঊনসত্তর", "সত্তর", "একাত্তর", "বাহাত্তর", "তিয়াত্তর", "চুয়াত্তর", "পঁচাত্তর", "ছিয়াত্তর", "সাতাত্তর", "আটাত্তর", "ঊনআশি", "আশি", "একাশি", "বিরাশি", "তিরাশি", "চুরাশি", "পঁচাশি", "ছিয়াশি", "সাতাশি", "আটাশি", "ঊননব্বই", "নব্বই", "একানব্বই", "বিরানব্বই", "তিরানব্বই", "চুরানব্বই", "পঁচানব্বই", "ছিয়ানব্বই", "সাতানব্বই", "আটানব্বই", "নিরানব্বই"];
  const below1000 = (n: number): string => {
    if (n < 100) return ones[n];
    const h = Math.floor(n / 100), r = n % 100;
    return ones[h] + "শ" + (r ? " " + ones[r] : "");
  };
  const parts: string[] = [];
  const crore = Math.floor(num / 10000000); num %= 10000000;
  const lakh = Math.floor(num / 100000); num %= 100000;
  const thousand = Math.floor(num / 1000); num %= 1000;
  if (crore) parts.push(below1000(crore) + " কোটি");
  if (lakh) parts.push(below1000(lakh) + " লক্ষ");
  if (thousand) parts.push(below1000(thousand) + " হাজার");
  if (num) parts.push(below1000(num));
  return parts.join(" ");
}

type Product = {
  id: string; name: string; size: string | null; company: string | null;
  sqft_per_piece: number; pcs_per_carton: number; stock_pieces: number;
  purchase_price_per_piece: number; sell_price_per_piece: number;
};
type Customer = { id: string; name: string; mobile: string | null; address: string | null; due_amount: number };
type SaleItem = {
  productId: string; pieces: number; totalPrice: number;
  cartons?: number; feet?: number; rate?: number;
};
type Sale = {
  id: string; invoice_no: string; customer_id: string | null; total_amount: number;
  paid_amount: number; due_amount: number; items: SaleItem[]; is_returned: boolean;
  returned_amount: number; sale_date: string;
};

type DateMode = "all" | "today" | "custom" | "range";

const SHOP = { nameEn: "Tiles Bazar", address: "Dhaka, Bangladesh", phone: "+880" };

function custCode(customers: Customer[], id: string | null): string {
  if (!id) return "WALK-IN";
  const sorted = [...customers].sort((a, b) => a.id.localeCompare(b.id));
  const idx = sorted.findIndex((c) => c.id === id);
  return idx >= 0 ? `CUST${String(idx + 1).padStart(6, "0")}` : "CUST------";
}

function computeProfit(s: Sale, productMap: Map<string, Product>): number {
  return s.items.reduce((sum, it) => {
    const p = productMap.get(it.productId);
    const cost = p ? Number(p.purchase_price_per_piece) * it.pieces : 0;
    return sum + (Number(it.totalPrice) - cost);
  }, 0);
}

export function buildReturnHtml(s: Sale, c: Customer | undefined, productMap: Map<string, Product>, opts: { preview?: boolean } = {}): string {
  const dateStr = new Date(s.sale_date).toLocaleDateString("en-GB");
  const itemRows = s.items;
  const totalFeetAll = itemRows.reduce((sum, it) => sum + Number(it.feet ?? 0), 0);
  const renderRow = (it: SaleItem, idx: number) => {
    const p = productMap.get(it.productId);
    const name = `${p?.name ?? "—"}${p?.size ? " " + p.size : ""}`;
    const ppc = p?.pcs_per_carton ?? 0;
    const leftoverPcs = ppc > 0 ? Number(it.pieces ?? 0) % ppc : Number(it.pieces ?? 0);
    return `<tr>
      <td class="c">${toBnDigits(idx + 1)}</td>
      <td>${name}</td>
      <td class="c">${toBnDigits(Number(it.feet ?? 0).toFixed(2))}</td>
      <td class="c">${Number(it.cartons) ? toBnDigits(Number(it.cartons)) : ""}</td>
      <td class="c">${leftoverPcs ? toBnDigits(leftoverPcs) : ""}</td>
      <td class="c">${toBnDigits(Number(it.rate ?? 0).toFixed(0))}</td>
      <td class="r">${toBnDigits(Number(it.totalPrice).toFixed(0))}</td>
    </tr>`;
  };
  const invNum = s.invoice_no.replace(/\D/g, "").slice(-4) || s.invoice_no;
  const grandTotal = Number(s.total_amount);
  const paidAmt = Number(s.paid_amount);
  const dueNow = Number(s.due_amount);
  const returnAmt = Number(s.returned_amount);
  const custName = c?.name ?? "Walk-in";
  const custMobile = c?.mobile ?? "";
  const custAddress = c?.address ?? "";

  const PER_PAGE = 11;
  const chunks: SaleItem[][] = [];
  for (let i = 0; i < itemRows.length; i += PER_PAGE) chunks.push(itemRows.slice(i, i + PER_PAGE));
  if (chunks.length === 0) chunks.push([]);
  const totalPages = chunks.length;

  const buildPage = (chunk: SaleItem[], chunkIdx: number, startIdx: number) => {
    const isLast = chunkIdx === totalPages - 1;
    const rowsHtml = chunk.map((it, i) => renderRow(it, startIdx + i)).join("");
    const summaryRowsCount = 2 + (paidAmt > 0 ? 1 : 0) + (dueNow > 0 ? 1 : 0);
    const targetRows = isLast ? Math.max(0, PER_PAGE - summaryRowsCount) : PER_PAGE;
    const emptyCount = Math.max(0, targetRows - chunk.length);
    const emptyHtml = Array.from({ length: emptyCount }).map(() =>
      `<tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>`).join("");

    const summaryHtml = isLast ? `
      <tr class="sum-net">
        <td></td><td class="sumlbl">মোট ফিটঃ</td>
        <td class="c">${toBnDigits(totalFeetAll.toFixed(2))}</td>
        <td></td>
        <td class="sumlbl shade" colspan="2">মোট টাকাঃ</td>
        <td class="sumval shade">${toBnDigits(grandTotal.toFixed(0))}</td>
      </tr>
      <tr class="shade-row">
        <td colspan="4" class="katha">কথায়: ${numToBnWords(returnAmt || grandTotal)} টাকা মাত্র</td>
        <td class="sumlbl" colspan="2">ফেরতঃ</td>
        <td class="sumval">${toBnDigits((returnAmt || grandTotal).toFixed(0))}</td>
      </tr>
      ${paidAmt > 0 ? `<tr class="shade-row">
        <td colspan="4"></td>
        <td class="sumlbl" colspan="2">জমাঃ</td>
        <td class="sumval">${toBnDigits(paidAmt.toFixed(0))}</td>
      </tr>` : ""}
      ${dueNow > 0 ? `<tr class="sum-due shade-row">
        <td colspan="4"></td>
        <td class="sumlbl" colspan="2">বাকিঃ</td>
        <td class="sumval">${toBnDigits(dueNow.toFixed(0))}</td>
      </tr>` : ""}` : "";

    const footerHtml = isLast ? `
      <div class="foot-note">এই বিলটি ফেরত হিসেবে গণ্য — অভিযোগের জন্য মূল বিলের সাথে সংরক্ষণ করুন</div>
      <div class="sign">
        <div>গ্রাহকের স্বাক্ষর</div>
        <div style="text-align:right"><span class="hasan">Hasan</span><br>পক্ষেঃ আলম টাইলস</div>
      </div>` : "";

    return `<div class="wrap page-break">
      <div class="top">
        <div class="logo">${INVOICE_LOGO_SVG}</div>
        <div class="center">
          <div class="bil">বিল মেমো (ফেরত)</div>
          <div class="name">${SHOP_BN.nameBn}</div>
          <div class="en">ALAM TILES</div>
        </div>
        <div class="right">
          <div>মোবাইলঃ</div>
          <div>হাসানঃ 0175-7770796</div>
          <div>0162-1176784</div>
          <div>বড় কালি বাড়ি রোড,</div>
          <div>টাংগাইল।</div>
        </div>
      </div>
      <div class="tag">সকল প্রকার টাইলস, মার্বেল পাথর, সিনারী, বর্ডার সামগ্রী পাইকারী ও খুচরা বিক্রেতা<br>এবং সরবরাহকারক। ডিলারঃ কুংফু সিরামিক্স, তুষার সিরামিক্স।</div>
      <table class="meta">
        <tr>
          <td class="lbl">নামঃ</td><td>${custName}</td>
          <td class="date-lbl">তারিখঃ</td><td class="date-val">${toBnDigits(dateStr)}</td>
        </tr>
        <tr><td class="lbl">মোবাইলঃ</td><td colspan="3">${toBnDigits(custMobile)}</td></tr>
        <tr><td class="lbl">ঠিকানাঃ</td><td colspan="3">${custAddress}</td></tr>
      </table>
      <div class="billno">ফেরত বিল নং ${toBnDigits(invNum)}</div>
      <table class="items" style="table-layout:fixed">
        <colgroup>
          <col style="width:8mm" /><col style="width:45mm" /><col style="width:14mm" /><col style="width:14mm" /><col style="width:10mm" /><col style="width:10mm" /><col style="width:22mm" />
        </colgroup>
        <thead><tr>
          <th>নং</th><th>বিবরণ</th><th>ফুট</th>
          <th>কাটুন</th><th>পিছ</th>
          <th>দর</th><th>মোট টাকা</th>
        </tr></thead>
        <tbody>
          ${rowsHtml}
          ${emptyHtml}
          ${summaryHtml}
        </tbody>
      </table>
      ${footerHtml}
      <div class="page">পৃষ্ঠা ${toBnDigits(chunkIdx + 1)} / ${toBnDigits(totalPages)}</div>
    </div>`;
  };

  const pagesHtml = chunks.map((chunk, idx) => buildPage(chunk, idx, idx * PER_PAGE)).join("");

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Return ${s.invoice_no}</title>
<style>${INVOICE_CSS}
.toolbar { position: fixed; top: 0; left: 0; right: 0; display: flex; gap: 8px; padding: 12px 16px; background: rgba(30,41,59,0.92); backdrop-filter: blur(6px); z-index: 10000; }
.toolbar button { background: #3b82f6; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; font-size: 14px; cursor: pointer; }
.toolbar button:hover { background: #2563eb; }
@media print { .toolbar, .no-print { display: none !important; } }
</style></head><body>
${opts.preview ? '<div class="toolbar no-print"><button onclick="window.print()">Print</button></div>' : ''}
${pagesHtml}
${opts.preview ? '' : '<script>window.onload=function(){setTimeout(function(){window.print();},300);}</script>'}
</body></html>`;
}

export default function ReturnHistory({
  sales, customers, products, userId, refresh,
}: {
  sales: Sale[]; customers: Customer[]; products: Product[];
  userId: string | null; refresh: () => void | Promise<void>;
}) {
  const productMap = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);
  const customerMap = useMemo(() => new Map(customers.map((c) => [c.id, c])), [customers]);

  const returns = useMemo(() => sales.filter((s) => s.is_returned), [sales]);

  const [origInv, setOrigInv] = useState("");
  const [custName, setCustName] = useState("");
  const [custMobile, setCustMobile] = useState("");
  const [custAddress, setCustAddress] = useState("");
  const [dateMode, setDateMode] = useState<DateMode>("all");
  const [customDate, setCustomDate] = useState("");
  const [rangeFrom, setRangeFrom] = useState("");
  const [rangeTo, setRangeTo] = useState("");
  const [pageSize, setPageSize] = useState(20);
  const [page, setPage] = useState(1);

  const [detailSale, setDetailSale] = useState<Sale | null>(null);
  const [editingSale, setEditingSale] = useState<Sale | null>(null);

  const filtered = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const oi = origInv.trim().toLowerCase();
    const cn = custName.trim().toLowerCase();
    const cm = custMobile.trim().toLowerCase();
    const ca = custAddress.trim().toLowerCase();

    return returns.filter((s) => {
      if (dateMode === "today" && s.sale_date !== today) return false;
      if (dateMode === "custom" && customDate && s.sale_date !== customDate) return false;
      if (dateMode === "range") {
        if (rangeFrom && s.sale_date < rangeFrom) return false;
        if (rangeTo && s.sale_date > rangeTo) return false;
      }
      const c = s.customer_id ? customerMap.get(s.customer_id) : undefined;
      if (oi && !s.invoice_no.toLowerCase().includes(oi)) return false;
      if (cn && !(c?.name ?? "").toLowerCase().includes(cn)) return false;
      if (cm && !(c?.mobile ?? "").toLowerCase().includes(cm)) return false;
      if (ca && !(c?.address ?? "").toLowerCase().includes(ca)) return false;
      return true;
    });
  }, [returns, origInv, custName, custMobile, custAddress, dateMode, customDate, rangeFrom, rangeTo, customerMap]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const visible = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  function clearFilters() {
    setOrigInv(""); setCustName(""); setCustMobile(""); setCustAddress("");
    setDateMode("all"); setCustomDate(""); setRangeFrom(""); setRangeTo("");
  }

  function openReturnWindow(s: Sale, preview = false) {
    const html = buildReturnHtml(s, s.customer_id ? customerMap.get(s.customer_id) : undefined, productMap, { preview });
    const w = window.open("", "_blank");
    if (w) { w.document.open(); w.document.write(html); w.document.close(); }
  }
  function handlePrint(s: Sale) { openReturnWindow(s); }
  function handlePreview(s: Sale) { openReturnWindow(s, true); }
  function handleDownload(s: Sale) { openReturnWindow(s); }
  function handleWhatsApp(s: Sale) {
    const c = s.customer_id ? customerMap.get(s.customer_id) : undefined;
    const phone = (c?.mobile || "").replace(/\D/g, "");
    const intl = phone.startsWith("880") ? phone : phone.startsWith("0") ? "88" + phone : phone ? "880" + phone : "";
    const msg = `${SHOP.nameEn} — Return Slip\nInvoice: ${s.invoice_no}\nReturn: BDT ${Number(s.returned_amount).toFixed(2)}`;
    openWhatsApp(intl, msg);
  }
  async function undoReturn(s: Sale) {
    if (!confirm(`Undo return for ${s.invoice_no}?`)) return;
    const { error } = await supabase.from("sales").update({ is_returned: false, returned_amount: 0 }).eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Return reversed");
    refresh();
  }
  async function handleDelete(s: Sale) {
    if (!confirm(`Delete return invoice ${s.invoice_no}? This cannot be undone.`)) return;
    const { error } = await supabase.from("sales").delete().eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Return invoice deleted");
    refresh();
  }
  async function handleUpdateReturn(s: Sale, updates: { returned_amount: number; paid_amount: number; due_amount: number; sale_date: string }) {
    const { error } = await supabase.from("sales").update({
      returned_amount: updates.returned_amount,
      paid_amount: updates.paid_amount,
      due_amount: updates.due_amount,
      sale_date: updates.sale_date,
    }).eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Return invoice updated");
    setEditingSale(null);
    refresh();
  }

  const inputCls = "w-full px-4 py-3 rounded-lg border border-gray-200 bg-white text-sm placeholder-gray-400 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-none";

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      <h1 className="text-center text-2xl font-semibold text-gray-700 mt-2">Return History</h1>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl border border-gray-200 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input value={origInv} onChange={(e) => setOrigInv(e.target.value)} placeholder="Original Invoice" className={inputCls} />
          <input value={custName} onChange={(e) => setCustName(e.target.value)} placeholder="Customer Name" className={inputCls} />
          <input value={custMobile} onChange={(e) => setCustMobile(e.target.value)} placeholder="Mobile Number" className={inputCls} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input value={custAddress} onChange={(e) => setCustAddress(e.target.value)} placeholder="Address" className={inputCls} />
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          {([
            ["all", "All"], ["today", "Today"], ["custom", "Custom Date"], ["range", "Date Range"],
          ] as const).map(([k, label]) => (
            <button key={k} onClick={() => setDateMode(k as DateMode)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                dateMode === k ? "bg-blue-600 text-white shadow" : "bg-gray-50 text-gray-700 hover:bg-gray-100"
              }`}>{label}</button>
          ))}
          {dateMode === "custom" && (
            <input type="date" value={customDate} onChange={(e) => setCustomDate(e.target.value)}
              className="px-3 py-2 rounded-lg border border-gray-200 text-sm" />
          )}
          {dateMode === "range" && (
            <>
              <input type="date" value={rangeFrom} onChange={(e) => setRangeFrom(e.target.value)}
                className="px-3 py-2 rounded-lg border border-gray-200 text-sm" />
              <span className="text-gray-400">—</span>
              <input type="date" value={rangeTo} onChange={(e) => setRangeTo(e.target.value)}
                className="px-3 py-2 rounded-lg border border-gray-200 text-sm" />
            </>
          )}
          <div className="ml-auto">
            <button onClick={clearFilters}
              className="px-4 py-2 rounded-lg bg-red-500 text-white text-sm font-medium hover:bg-red-600">Clear Filters</button>
          </div>
        </div>

        <div className="flex items-center gap-2 text-sm text-gray-600">
          <span>Show:</span>
          <select value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
            className="px-2 py-1 rounded border border-gray-200 bg-white">
            {[10, 20, 50, 100, 200].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
          <span>entries</span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-gray-600 text-left">
              <tr>
                <th className="p-3 font-semibold">Invoice</th>
                <th className="p-3 font-semibold">Date</th>
                <th className="p-3 font-semibold">Customer Id</th>
                <th className="p-3 font-semibold">Customer Info</th>
                <th className="p-3 font-semibold text-right">Return</th>
                <th className="p-3 font-semibold text-right">Paid</th>
                <th className="p-3 font-semibold text-right">Due</th>
                <th className="p-3 font-semibold text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {visible.length === 0 && (
                <tr><td colSpan={8} className="p-8 text-center text-gray-400">No returns found</td></tr>
              )}
              {visible.map((s) => {
                const c = s.customer_id ? customerMap.get(s.customer_id) : undefined;
                return (
                  <tr key={s.id} className="border-t border-gray-100 hover:bg-blue-50/30">
                    <td className="p-3 font-medium">{s.invoice_no}</td>
                    <td className="p-3 text-gray-600">{s.sale_date}</td>
                    <td className="p-3 text-gray-700">{custCode(customers, s.customer_id)}</td>
                    <td className="p-3">
                      <div className="text-blue-600 font-medium">{c?.name ?? "Walk-in"}</div>
                      <div className="text-gray-500 text-xs">{c?.address ?? ""}</div>
                      <div className="text-gray-500 text-xs">{c?.mobile ?? ""}</div>
                    </td>
                    <td className="p-3 text-right text-rose-600 font-medium">{Number(s.returned_amount).toFixed(0)}</td>
                    <td className="p-3 text-right text-emerald-600">৳{Number(s.paid_amount).toFixed(0)}</td>
                    <td className="p-3 text-right">{Number(s.due_amount).toFixed(0)}</td>
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button onClick={() => setEditingSale(s)}
                          className="px-3 py-1.5 rounded-md bg-blue-600 text-white text-xs font-medium hover:bg-blue-700 flex items-center gap-1">
                          <Pencil className="w-3.5 h-3.5" /> Edit
                        </button>
                        <button onClick={() => handleDelete(s)}
                          className="px-3 py-1.5 rounded-md bg-red-500 text-white text-xs font-medium hover:bg-red-600 flex items-center gap-1">
                          <Trash2 className="w-3.5 h-3.5" /> Delete
                        </button>
                        <button onClick={() => setDetailSale(s)}
                          className="px-3 py-1.5 rounded-md bg-slate-700 text-white text-xs font-medium hover:bg-slate-800 flex items-center gap-1">
                          <Eye className="w-3.5 h-3.5" /> Details
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <Pager page={currentPage} totalPages={totalPages} total={filtered.length} pageSize={pageSize} onPage={setPage} />



      {detailSale && (
        <DetailsModal
          sale={detailSale}
          customers={customers}
          customer={detailSale.customer_id ? customerMap.get(detailSale.customer_id) : undefined}
          productMap={productMap}
          onClose={() => setDetailSale(null)}
          onPrint={() => handlePrint(detailSale)}
          onPreview={() => handlePreview(detailSale)}
          onPdf={() => handleDownload(detailSale)}
          onWhatsApp={() => handleWhatsApp(detailSale)}
          onUndo={() => { undoReturn(detailSale); setDetailSale(null); }}
          onEdit={() => { setDetailSale(null); setEditingSale(detailSale); }}
          onDelete={() => { handleDelete(detailSale); setDetailSale(null); }}
        />
      )}
      {editingSale && (
        <EditModal
          sale={editingSale}
          onClose={() => setEditingSale(null)}
          onSave={handleUpdateReturn}
        />
      )}
    </div>
  );
}

function Pager({ page, totalPages, total, pageSize, onPage }: {
  page: number; totalPages: number; total: number; pageSize: number; onPage: (p: number) => void;
}) {
  if (total === 0) return null;
  const from = (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, total);
  const nums: number[] = [];
  const start = Math.max(1, page - 2);
  const end = Math.min(totalPages, start + 4);
  for (let i = start; i <= end; i++) nums.push(i);
  const btn = "px-3 py-1.5 rounded-md border border-gray-200 bg-white text-sm hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed";
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 px-1">
      <div className="text-sm text-gray-600">Showing {from}–{to} of {total}</div>
      <div className="flex items-center gap-1">
        <button className={btn} disabled={page <= 1} onClick={() => onPage(1)}>«</button>
        <button className={btn} disabled={page <= 1} onClick={() => onPage(page - 1)}>Prev</button>
        {nums.map((n) => (
          <button key={n} onClick={() => onPage(n)}
            className={`px-3 py-1.5 rounded-md text-sm border ${n === page ? "bg-blue-600 text-white border-blue-600" : "bg-white border-gray-200 hover:bg-gray-50"}`}>
            {n}
          </button>
        ))}
        <button className={btn} disabled={page >= totalPages} onClick={() => onPage(page + 1)}>Next</button>
        <button className={btn} disabled={page >= totalPages} onClick={() => onPage(totalPages)}>»</button>
      </div>
    </div>
  );
}

function Modal({ children, onClose, wide }: { children: React.ReactNode; onClose: () => void; wide?: boolean }) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className={`bg-white rounded-2xl shadow-2xl w-full ${wide ? "max-w-[1400px]" : "max-w-md"} max-h-[90vh] overflow-y-auto`}>
        <div className="sticky top-0 bg-white border-b px-5 py-3 flex items-center justify-between">
          <div />
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function DetailsModal({
  sale, customers, customer, productMap, onClose,
  onPrint, onPreview, onPdf, onWhatsApp, onUndo, onEdit, onDelete,
}: {
  sale: Sale; customers: Customer[]; customer: Customer | undefined; productMap: Map<string, Product>;
  onClose: () => void;
  onPrint: () => void; onPreview: () => void; onPdf: () => void; onWhatsApp: () => void; onUndo: () => void; onEdit: () => void; onDelete: () => void;
}) {
  const items = sale.items;
  const subtotal = items.reduce((s, it) => s + Number(it.totalPrice), 0);
  const grandTotal = Number(sale.total_amount);
  const discount = Math.max(0, subtotal - grandTotal);
  const profit = computeProfit(sale, productMap);
  const code = custCode(customers, sale.customer_id);
  const returnAmt = Number(sale.returned_amount);

  const cellCls = "border border-gray-300 p-2 text-sm align-top";
  const headCls = "border border-gray-300 p-2 text-sm font-semibold bg-slate-100 text-gray-700 text-left";

  return (
    <Modal wide onClose={onClose}>
      <h2 className="text-center text-xl font-semibold mb-4">Return Invoice: {sale.invoice_no} Details</h2>
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className={headCls}>Invoice</th>
              <th className={headCls}>Date</th>
              <th className={headCls}>Customer Info</th>
              <th className={headCls}>Product Name</th>
              <th className={headCls}>Quantity</th>
              <th className={headCls}>Price</th>
              <th className={headCls}>Total</th>
              <th className={headCls}>Subtotal</th>
              <th className={headCls}>Discount Cut</th>
              <th className={headCls}>Grand Total</th>
              <th className={headCls}>Return</th>
              <th className={headCls}>Paid</th>
              <th className={headCls}>Due</th>
              <th className={headCls}>Print</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, i) => {
              const p = productMap.get(it.productId);
              const isFirst = i === 0;
              const rowCount = items.length;
              return (
                <tr key={i}>
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{sale.invoice_no}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{sale.sale_date}</td>}
                  {isFirst && (
                    <td className={cellCls} rowSpan={rowCount}>
                      <div className="text-blue-600 font-medium">{code}</div>
                      <div className="text-blue-600">{customer?.name ?? "Walk-in"}</div>
                      <div className="text-gray-600 text-xs">{customer?.address ?? ""}</div>
                      <div className="text-gray-600 text-xs">{customer?.mobile ?? ""}</div>
                    </td>
                  )}
                  <td className={cellCls}>{p?.name ?? "—"}{p?.size ? ` ${p.size}` : ""}</td>
                  <td className={cellCls}>{it.feet != null ? `${Number(it.feet).toFixed(2)} feet` : `${it.pieces} pcs`}</td>
                  <td className={cellCls}>{it.rate ?? "—"}</td>
                  <td className={cellCls}>{Number(it.totalPrice).toFixed(0)}</td>
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{subtotal.toFixed(0)}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{discount.toFixed(0)}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{grandTotal.toFixed(0)}</td>}
                  {isFirst && <td className={`${cellCls} text-rose-600 font-medium`} rowSpan={rowCount}>{returnAmt.toFixed(0)}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{Number(sale.paid_amount).toFixed(0)}</td>}
                  {isFirst && <td className={cellCls} rowSpan={rowCount}>{Number(sale.due_amount).toFixed(0)}</td>}
                  {isFirst && (
                    <td className={cellCls} rowSpan={rowCount}>
                      <button onClick={onPrint}
                        className="px-3 py-1.5 rounded-md bg-slate-700 text-white text-xs font-medium hover:bg-slate-800 flex items-center gap-1">
                        <Printer className="w-3.5 h-3.5" /> Print
                      </button>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-3 text-xs text-gray-500">Profit (original sale): ৳{profit.toFixed(0)}</div>

      <div className="flex flex-wrap justify-end gap-2 mt-5">
        <button onClick={onPrint} className="px-3 py-2 rounded-lg bg-slate-700 text-white text-sm flex items-center gap-1.5"><Printer className="w-4 h-4" /> Print</button>
        <button onClick={onPreview} className="px-3 py-2 rounded-lg bg-sky-600 text-white text-sm flex items-center gap-1.5"><Eye className="w-4 h-4" /> Preview</button>
        <button onClick={onPdf} className="px-3 py-2 rounded-lg bg-indigo-600 text-white text-sm flex items-center gap-1.5"><Download className="w-4 h-4" /> PDF</button>
        <button onClick={onWhatsApp} className="px-3 py-2 rounded-lg bg-emerald-600 text-white text-sm flex items-center gap-1.5"><MessageSquare className="w-4 h-4" /> WhatsApp</button>
        <button onClick={onEdit} className="px-3 py-2 rounded-lg bg-blue-600 text-white text-sm flex items-center gap-1.5"><Pencil className="w-4 h-4" /> Edit</button>
        <button onClick={onDelete} className="px-3 py-2 rounded-lg bg-red-500 text-white text-sm flex items-center gap-1.5"><Trash2 className="w-4 h-4" /> Delete</button>
        <button onClick={onUndo} className="px-3 py-2 rounded-lg bg-orange-500 text-white text-sm flex items-center gap-1.5"><Undo2 className="w-4 h-4" /> Undo Return</button>
      </div>
    </Modal>
  );
}

function EditModal({
  sale, onClose, onSave,
}: {
  sale: Sale;
  onClose: () => void;
  onSave: (s: Sale, updates: { returned_amount: number; paid_amount: number; due_amount: number; sale_date: string }) => Promise<unknown>;
}) {
  const [returnedAmount, setReturnedAmount] = useState(Number(sale.returned_amount));
  const [paidAmount, setPaidAmount] = useState(Number(sale.paid_amount));
  const [dueAmount, setDueAmount] = useState(Number(sale.due_amount));
  const [saleDate, setSaleDate] = useState(sale.sale_date);
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    setSaving(true);
    await onSave(sale, {
      returned_amount: returnedAmount,
      paid_amount: paidAmount,
      due_amount: dueAmount,
      sale_date: saleDate,
    });
    setSaving(false);
  }

  const inputCls = "w-full px-4 py-3 rounded-lg border border-gray-200 bg-white text-sm placeholder-gray-400 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-none";

  return (
    <Modal onClose={onClose}>
      <h2 className="text-center text-xl font-semibold mb-4">Edit Return Invoice</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Invoice No</label>
          <input value={sale.invoice_no} disabled className={`${inputCls} bg-gray-100`} />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Sale Date</label>
          <input type="date" value={saleDate} onChange={(e) => setSaleDate(e.target.value)} className={inputCls} />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Returned Amount</label>
          <input type="number" value={returnedAmount} onChange={(e) => setReturnedAmount(Number(e.target.value))} className={inputCls} />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Paid Amount</label>
          <input type="number" value={paidAmount} onChange={(e) => setPaidAmount(Number(e.target.value))} className={inputCls} />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Due Amount</label>
          <input type="number" value={dueAmount} onChange={(e) => setDueAmount(Number(e.target.value))} className={inputCls} />
        </div>
        <div className="flex gap-3 pt-2">
          <button onClick={handleSave} disabled={saving}
            className="flex-1 px-4 py-3 rounded-lg bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 disabled:opacity-50">
            {saving ? "Saving..." : "Save Changes"}
          </button>
          <button onClick={onClose}
            className="flex-1 px-4 py-3 rounded-lg bg-gray-100 text-gray-700 text-sm font-medium hover:bg-gray-200">
            Cancel
          </button>
        </div>
      </div>
    </Modal>
  );
}
