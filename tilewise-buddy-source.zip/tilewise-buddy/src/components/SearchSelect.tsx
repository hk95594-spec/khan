import { useEffect, useMemo, useRef, useState } from "react";
import { Search, X } from "lucide-react";

export type SearchSelectOption = { value: string; label: string; hint?: string };

type Props = {
  options: SearchSelectOption[];
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
  inputClassName?: string;
  emptyText?: string;
  clearable?: boolean;
  autoFocus?: boolean;
};

export default function SearchSelect({
  options, value, onChange, placeholder = "Search...",
  className = "", inputClassName = "", emptyText = "No results", clearable = true, autoFocus,
}: Props) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [hi, setHi] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  const selected = options.find((o) => o.value === value) || null;

  // Sync input text with externally selected value when closed
  useEffect(() => {
    if (!open) setQuery(selected ? selected.label : "");
  }, [selected, open]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options.slice(0, 50);
    return options
      .filter((o) => (o.label + " " + (o.hint || "")).toLowerCase().includes(q))
      .slice(0, 50);
  }, [query, options]);

  useEffect(() => { setHi(0); }, [query, open]);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const pick = (o: SearchSelectOption) => {
    onChange(o.value);
    setQuery(o.label);
    setOpen(false);
  };

  return (
    <div ref={ref} className={`relative ${className}`}>
      <Search className="w-4 h-4 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
      <input
        autoFocus={autoFocus}
        value={query}
        onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        onKeyDown={(e) => {
          if (e.key === "ArrowDown") { e.preventDefault(); setOpen(true); setHi((h) => Math.min(h + 1, filtered.length - 1)); }
          else if (e.key === "ArrowUp") { e.preventDefault(); setHi((h) => Math.max(h - 1, 0)); }
          else if (e.key === "Enter") { if (filtered[hi]) { e.preventDefault(); pick(filtered[hi]); } }
          else if (e.key === "Escape") { setOpen(false); }
        }}
        placeholder={placeholder}
        className={`w-full pl-8 pr-7 py-2 rounded-lg border border-gray-200 bg-white focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500 outline-none text-sm ${inputClassName}`}
      />
      {clearable && (value || query) && (
        <button type="button" onClick={() => { onChange(""); setQuery(""); setOpen(false); }}
          className="absolute right-1.5 top-1/2 -translate-y-1/2 p-0.5 text-gray-400 hover:text-gray-700">
          <X className="w-3.5 h-3.5" />
        </button>
      )}
      {open && (
        <div className="absolute z-50 mt-1 left-0 right-0 max-h-64 overflow-auto rounded-lg border border-gray-200 bg-white shadow-lg">
          {filtered.length === 0 ? (
            <div className="px-3 py-2 text-xs text-gray-500">{emptyText}</div>
          ) : (
            filtered.map((o, idx) => (
              <button
                type="button"
                key={o.value}
                onMouseEnter={() => setHi(idx)}
                onClick={() => pick(o)}
                className={`w-full text-left px-3 py-1.5 text-sm flex justify-between gap-2 ${idx === hi ? "bg-emerald-50" : "hover:bg-gray-50"} ${o.value === value ? "font-semibold text-emerald-700" : "text-gray-800"}`}
              >
                <span className="truncate">{o.label}</span>
                {o.hint && <span className="text-xs text-gray-500 whitespace-nowrap">{o.hint}</span>}
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}
