import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type Product = {
  id: string; name: string; category: string | null; company: string | null; size: string | null;
  sqft_per_piece: number; pcs_per_carton: number; stock_pieces: number;
  purchase_price_per_piece: number; sell_price_per_piece: number;
};
type Supplier = { id: string; name: string; mobile: string | null; address: string | null; advance: number; total_due: number };
type Category = { id: string; name: string };
type Company = { id: string; name: string };

export type PurchaseMeta = {
  invoice_no?: string;
  brand?: string;
  type?: string;
  status?: "Paid" | "Partial Paid" | "Due";
  transport?: number;
  loading?: number;
  other?: number;
  paid?: number;
  payment_method?: "Cash" | "Bank" | "Mobile Banking";
  product_code?: string;
};

const META_KEY = "tiles_purchase_meta_v1";
export const loadMeta = (): Record<string, PurchaseMeta> => {
  try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch { return {}; }
};
const saveMeta = (m: Record<string, PurchaseMeta>) => localStorage.setItem(META_KEY, JSON.stringify(m));

type Row = {
  key: string;
  productQuery: string;
  productId: string;
  productOpen: boolean;
  productName: string;
  size: string;
  category: string;
  companyName: string;
  cartons: number;
  perUnit: number | "";
  sqftPerPiece: number;
  purchasePrice: number;
};

const newRow = (): Row => ({
  key: Math.random().toString(36).slice(2),
  productQuery: "", productId: "", productOpen: false, productName: "",
  size: "", category: "", companyName: "",
  cartons: 0, perUnit: "", sqftPerPiece: 1, purchasePrice: 0,
});

export default function PurchaseProduct({
  userId, products, suppliers, categories, companies, refresh,
}: {
  userId: string;
  products: Product[];
  suppliers: Supplier[];
  categories: Category[];
  companies: Company[];
  refresh: () => void;
}) {
  const [supplierQuery, setSupplierQuery] = useState("");
  const [supplierId, setSupplierId] = useState("");
  const [supplierOpen, setSupplierOpen] = useState(false);
  const supplier = suppliers.find((s) => s.id === supplierId);

  const [purchaseStatus, setPurchaseStatus] = useState<"True" | "False">("True");
  const [rows, setRows] = useState<Row[]>([newRow()]);

  const filteredSuppliers = useMemo(() => {
    const q = supplierQuery.trim().toLowerCase();
    if (!q) return suppliers.slice(0, 8);
    return suppliers.filter((s) => s.name.toLowerCase().includes(q)).slice(0, 8);
  }, [suppliers, supplierQuery]);

  const updateRow = (key: string, patch: Partial<Row>) => {
    setRows((rs) => rs.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  };

  // Auto-fill on product select or exact name match while typing
  useEffect(() => {
    setRows((rs) =>
      rs.map((r) => {
        if (!r.productId) return r;
        const p = products.find((x) => x.id === r.productId);
        if (!p) return r;
        if (r.productName === p.name) return r;
        return {
          ...r,
          productName: p.name,
          category: p.category ?? r.category,
          companyName: p.company ?? r.companyName,
          size: p.size ?? r.size,
          perUnit: r.perUnit || (p.pcs_per_carton || 0),
          sqftPerPiece: Number(p.sqft_per_piece) || 1,
          purchasePrice: r.purchasePrice || Number(p.purchase_price_per_piece) || 0,
        };
      })
    );
  }, [rows.map((r) => r.productId).join("|"), products]);

  const tryAutoFill = (key: string, name: string) => {
    const match = products.find((p) => p.name.toLowerCase() === name.trim().toLowerCase());
    if (!match) return;
    updateRow(key, {
      productId: match.id,
      productName: match.name,
      category: match.category || "",
      companyName: match.company || "",
      size: match.size || "",
      perUnit: match.pcs_per_carton || 0,
      sqftPerPiece: Number(match.sqft_per_piece) || 1,
      purchasePrice: Number(match.purchase_price_per_piece) || 0,
      productOpen: false,
    });
  };

  const rowPcs = (r: Row) => r.perUnit === "" ? 0 : Math.round(r.cartons * r.perUnit);
  const rowFeet = (r: Row) => rowPcs(r) * (r.sqftPerPiece || 1);
  const rowTotal = (r: Row) => rowFeet(r) * r.purchasePrice;
  const grandTotal = useMemo(() => rows.reduce((s, r) => s + rowTotal(r), 0), [rows]);
  const totalPcsAll = useMemo(() => rows.reduce((s, r) => s + rowPcs(r), 0), [rows]);
  const totalCartonsAll = useMemo(() => rows.reduce((s, r) => s + (r.cartons || 0), 0), [rows]);

  const addRow = () => setRows((rs) => [...rs, newRow()]);
  const removeRow = (key: string) =>
    setRows((rs) => (rs.length === 1 ? rs : rs.filter((r) => r.key !== key)));

  const resetForm = () => {
    setSupplierId(""); setSupplierQuery("");
    setPurchaseStatus("True");
    setRows([newRow()]);
  };

  const submit = async () => {
    if (!supplierId) return toast.error("Supplier সিলেক্ট করুন");
    const valid = rows.filter((r) => r.productName.trim() && r.cartons > 0 && typeof r.perUnit === 'number' && r.perUnit > 0 && r.purchasePrice > 0);
    if (valid.length === 0) return toast.error("কমপক্ষে একটি পণ্য ঠিকমতো পূরণ করুন");

    const purchaseDate = new Date().toISOString().slice(0, 10);
    const invoiceNo = `PUR-${Date.now().toString().slice(-6)}`;
    const status: PurchaseMeta["status"] = purchaseStatus === "True" ? "Paid" : "Due";
    const meta = loadMeta();
    let supplierDueDelta = 0;
    let successCount = 0;

    for (const r of valid) {
      let pid = r.productId;
      if (!pid) {
        const existing = products.find((p) => p.name.toLowerCase() === r.productName.trim().toLowerCase());
        if (existing) {
          pid = existing.id;
        } else {
          const { data: np, error: pe } = await supabase
            .from("products")
            .insert({
              user_id: userId,
              name: r.productName.trim(),
              category: r.category || null,
              company: r.companyName || null,
              size: r.size || null,
              pcs_per_carton: Math.max(1, Math.round(Number(r.perUnit))),
              sqft_per_piece: 1,
              stock_pieces: 0,
              purchase_price_per_piece: r.purchasePrice,
              sell_price_per_piece: r.purchasePrice * 1.15,
            })
            .select()
            .single();
          if (pe || !np) { toast.error(pe?.message || "Product তৈরি ব্যর্থ"); continue; }
          pid = np.id;
        }
      }

      const tPcs = rowPcs(r);
      const tAmt = rowTotal(r);
      const paid = purchaseStatus === "True" ? tAmt : 0;

      const { data: ins, error } = await supabase
        .from("purchases")
        .insert({
          user_id: userId,
          product_id: pid,
          supplier_id: supplierId,
          pieces: tPcs,
          cost_per_piece: r.purchasePrice,
          total_cost: tAmt,
          purchase_date: purchaseDate,
        })
        .select()
        .single();
      if (error || !ins) { toast.error(error?.message || "Save ব্যর্থ"); continue; }

      meta[ins.id] = { invoice_no: invoiceNo, status, paid, payment_method: "Cash" };

      const p = products.find((x) => x.id === pid);
      if (p) {
        await supabase.from("products").update({
          stock_pieces: Number(p.stock_pieces) + tPcs,
          purchase_price_per_piece: r.purchasePrice || p.purchase_price_per_piece,
          category: r.category || p.category,
          company: r.companyName || p.company,
          size: r.size || p.size,
        }).eq("id", pid);
      } else {
        await supabase.from("products").update({
          stock_pieces: tPcs,
          purchase_price_per_piece: r.purchasePrice,
        }).eq("id", pid);
      }

      supplierDueDelta += Math.max(0, tAmt - paid);
      successCount++;
    }

    saveMeta(meta);

    if (supplier && supplierDueDelta > 0) {
      await supabase.from("suppliers").update({
        total_due: Number(supplier.total_due) + supplierDueDelta,
      }).eq("id", supplierId);
    }

    if (successCount > 0) {
      toast.success(`✅ ${successCount}টি পণ্য সফলভাবে সংরক্ষণ হয়েছে (${invoiceNo})`);
      refresh();
      resetForm();
    }
  };

  const label = "block text-xs font-medium text-gray-700 mb-1";
  const req = <span className="text-red-500">*</span>;
  const input = "w-full border border-gray-300 rounded-md px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500";

  return (
    <div className="max-w-6xl mx-auto bg-white rounded-2xl shadow-sm border border-gray-200 p-5 md:p-8">
      <h2 className="text-center text-2xl md:text-3xl font-serif italic text-gray-800 mb-6">Purchase Product</h2>

      {/* Top: Supplier + Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-5 mb-6">
        <div className="relative">
          <label className={label}>Supplier Name {req}</label>
          <div className="relative">
            <input
              value={supplierQuery || supplier?.name || ""}
              onChange={(e) => { setSupplierQuery(e.target.value); setSupplierId(""); setSupplierOpen(true); }}
              onFocus={() => setSupplierOpen(true)}
              onBlur={() => setTimeout(() => setSupplierOpen(false), 150)}
              placeholder="Search or select a name"
              className={`${input} pr-8`}
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">▾</span>
          </div>
          {supplierOpen && filteredSuppliers.length > 0 && (
            <ul className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-md shadow-lg max-h-56 overflow-y-auto">
              {filteredSuppliers.map((s) => (
                <li key={s.id}
                  onMouseDown={() => { setSupplierId(s.id); setSupplierQuery(""); setSupplierOpen(false); }}
                  className="px-3 py-2 text-sm hover:bg-emerald-50 cursor-pointer">
                  {s.name}{s.mobile ? <span className="text-xs text-gray-500 ml-2">{s.mobile}</span> : null}
                </li>
              ))}
            </ul>
          )}
          {supplier && Number(supplier.total_due) > 0 && (
            <div className="mt-1 text-xs text-amber-700">Current Due: ৳{Number(supplier.total_due).toFixed(0)}</div>
          )}
        </div>

        <div>
          <label className={label}>Purchase Status {req}</label>
          <select
            value={purchaseStatus}
            onChange={(e) => setPurchaseStatus(e.target.value as "True" | "False")}
            className={input}
          >
            <option value="True">True (Paid)</option>
            <option value="False">False (Due)</option>
          </select>
        </div>
      </div>

      {/* Product rows */}
      <div className="space-y-4">
        {rows.map((r, idx) => {
          const filteredProducts = (() => {
            const q = r.productQuery.trim().toLowerCase();
            if (!q) return products.slice(0, 8);
            return products.filter((p) => p.name.toLowerCase().includes(q)).slice(0, 8);
          })();
          return (
            <div key={r.key} className="border border-gray-200 rounded-xl p-4 bg-gray-50/50">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-semibold text-gray-700">পণ্য #{idx + 1}</span>
                {rows.length > 1 && (
                  <button
                    onClick={() => removeRow(r.key)}
                    className="text-xs text-red-600 hover:text-red-700 font-medium"
                  >
                    ✕ মুছুন
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                {/* Product Name */}
                <div className="relative">
                  <label className={label}>Product Name {req}</label>
                  <div className="relative">
                    <input
                      value={r.productQuery || r.productName}
                      onChange={(e) => {
                        const val = e.target.value;
                        updateRow(r.key, { productQuery: val, productName: val, productId: "", productOpen: true });
                        tryAutoFill(r.key, val);
                      }}
                      onFocus={() => updateRow(r.key, { productOpen: true })}
                      onBlur={() => setTimeout(() => updateRow(r.key, { productOpen: false }), 150)}
                      placeholder="Search or select a Product"
                      className={`${input} pr-8`}
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">▾</span>
                  </div>
                  {r.productOpen && filteredProducts.length > 0 && (
                    <ul className="absolute z-20 mt-1 w-full bg-white border border-gray-200 rounded-md shadow-lg max-h-56 overflow-y-auto">
                      {filteredProducts.map((p) => (
                        <li key={p.id}
                          onMouseDown={() => updateRow(r.key, { productId: p.id, productQuery: "", productOpen: false })}
                          className="px-3 py-2 text-sm hover:bg-emerald-50 cursor-pointer">
                          {p.name} {p.size ? <span className="text-xs text-gray-500">({p.size})</span> : null}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                {/* Company */}
                <div>
                  <label className={label}>Company Name</label>
                  <input
                    list="company-list"
                    value={r.companyName}
                    onChange={(e) => updateRow(r.key, { companyName: e.target.value })}
                    placeholder="Company Name"
                    className={input}
                  />
                </div>

                {/* Size */}
                <div>
                  <label className={label}>Size</label>
                  <input
                    value={r.size}
                    onChange={(e) => updateRow(r.key, { size: e.target.value })}
                    placeholder="Size"
                    className={input}
                  />
                </div>

                {/* Category */}
                <div>
                  <label className={label}>Catagory</label>
                  <input
                    list="cat-list"
                    value={r.category}
                    onChange={(e) => updateRow(r.key, { category: e.target.value })}
                    placeholder="catagory"
                    className={input}
                  />
                </div>

                {/* Quantity */}
                <div>
                  <label className={label}>Quantity/Caton {req}</label>
                  <input
                    type="number"
                    value={r.cartons || ""}
                    onChange={(e) => updateRow(r.key, { cartons: parseFloat(e.target.value) || 0 })}
                    placeholder="Quantity"
                    className={input}
                  />
                </div>

                {/* Per */}
                <div>
                  <label className={label}>Per Feet || Per Pcs {req}</label>
                  <input
                    type="number"
                    step="0.01"
                    value={r.perUnit === "" ? "" : r.perUnit}
                    onChange={(e) => {
                      const val = e.target.value;
                      updateRow(r.key, { perUnit: val === "" ? "" : parseFloat(val) || 0 });
                    }}
                    placeholder="Per feet || Per pcs"
                    className={input}
                  />
                </div>

                {/* Purchase Price */}
                <div>
                  <label className={label}>Purchase Price {req}</label>
                  <input
                    type="number"
                    step="0.01"
                    value={r.purchasePrice || ""}
                    onChange={(e) => updateRow(r.key, { purchasePrice: parseFloat(e.target.value) || 0 })}
                    placeholder="Purchase Price"
                    className={input}
                  />
                </div>

                {/* Subtotal */}
                <div>
                  <label className={label}>Subtotal</label>
                  <div className="w-full border border-emerald-200 bg-emerald-50 rounded-md px-3 py-2 text-sm font-semibold text-emerald-800">
                    {r.perUnit === "" ? (
                      <span className="text-gray-400 font-normal">—</span>
                    ) : (
                      <>৳ {rowTotal(r).toFixed(2)} <span className="text-xs font-normal text-emerald-700">({rowFeet(r).toFixed(2)} ft / {rowPcs(r)} pcs)</span></>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <datalist id="company-list">
        {companies.map((c) => <option key={c.id} value={c.name} />)}
      </datalist>
      <datalist id="cat-list">
        {categories.map((c) => <option key={c.id} value={c.name} />)}
      </datalist>

      {/* Add row + Grand total */}
      <div className="mt-4 flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
        <button
          onClick={addRow}
          className="w-full md:w-auto px-4 py-2.5 border-2 border-dashed border-emerald-400 text-emerald-700 hover:bg-emerald-50 rounded-md font-medium text-sm"
        >
          + আরও পণ্য যোগ করুন
        </button>
        <div className="text-right">
          <div className="text-xs text-gray-500">Grand Total ({totalCartonsAll} কার্টুন)</div>
          <div className="text-2xl font-bold text-emerald-700">৳ {grandTotal.toFixed(2)}</div>
        </div>
      </div>

      <button
        onClick={submit}
        className="mt-6 w-full bg-emerald-500 hover:bg-emerald-600 text-white font-semibold py-3.5 rounded-md shadow-sm transition-colors"
      >
        Purchase Product ({rows.length}টি)
      </button>
    </div>
  );
}
