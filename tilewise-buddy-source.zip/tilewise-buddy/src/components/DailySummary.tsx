import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

type Sale = {
  id: string; invoice_no: string; customer_id: string | null;
  total_amount: number; paid_amount: number; due_amount: number;
  is_returned: boolean; returned_amount: number; sale_date: string;
  items: { productId: string; pieces: number; totalPrice: number }[];
};
type Purchase = { id: string; supplier_id: string | null; product_id: string | null; pieces: number; total_cost: number; purchase_date: string };
type Cost = { id: string; description: string; amount: number; cost_date: string };
type CashTx = { id: string; type: "in" | "out"; amount: number; reason: string | null; trans_date: string };
type Customer = { id: string; name: string };
type Supplier = { id: string; name: string };

const today = () => new Date().toISOString().slice(0, 10);

type Row = { sl: number; desc: string; amount: number; id?: string };

type Theme = { header: string; headerText: string; row: string; border: string };

function Box({ title, headers, rows, totalLabel = "মোট", footerSpan, theme, deleteIds, onDelete }: {
  title: string; headers: string[]; rows: (string | number)[][]; totalLabel?: string; footerSpan?: number; theme: Theme;
  deleteIds?: string[]; onDelete?: (id: string) => void;
}) {
  const total = rows.reduce((s, r) => s + (Number(r[r.length - 1]) || 0), 0);
  const canDelete = !!(deleteIds && onDelete);
  return (
    <div className={`border ${theme.border} rounded overflow-hidden`}>
      <div className={`text-center font-semibold py-2 text-sm ${theme.header} ${theme.headerText}`}>{title}</div>
      <table className="w-full text-xs border-collapse">
        <thead className={theme.row}>
          <tr>
            {headers.map((h, i) => <th key={i} className={`border ${theme.border} px-2 py-1 font-medium`}>{h}</th>)}
            {canDelete && <th className={`border ${theme.border} px-1 py-1 font-medium print:hidden w-8`}></th>}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr><td className={`border ${theme.border} px-2 py-2 text-center text-gray-400`} colSpan={headers.length + (canDelete ? 1 : 0)}>—</td></tr>
          ) : rows.map((r, i) => (
            <tr key={i} className={i % 2 ? theme.row : ""}>
              {r.map((c, j) => <td key={j} className={`border ${theme.border} px-2 py-1 text-center`}>{c}</td>)}
              {canDelete && (
                <td className={`border ${theme.border} px-1 py-1 text-center print:hidden`}>
                  <button
                    onClick={() => { if (confirm("এই এন্ট্রিটি ডিলিট করবেন?")) onDelete!(deleteIds![i]); }}
                    className="text-rose-600 hover:text-rose-800 text-[11px] font-bold"
                    title="ডিলিট"
                  >✕</button>
                </td>
              )}
            </tr>
          ))}
          <tr className={`font-semibold ${theme.header} ${theme.headerText}`}>
            <td className={`border ${theme.border} px-2 py-1 text-center`} colSpan={footerSpan ?? headers.length - 1}>{totalLabel}</td>
            <td className={`border ${theme.border} px-2 py-1 text-center`}>{Math.round(total)}</td>
            {canDelete && <td className={`border ${theme.border} print:hidden`}></td>}
          </tr>
        </tbody>
      </table>
    </div>
  );
}


export default function DailySummary({
  sales, purchases, costs, cashTx, customers, suppliers, refresh,
}: {
  sales: Sale[]; purchases: Purchase[]; costs: Cost[]; cashTx: CashTx[];
  customers: Customer[]; suppliers: Supplier[]; refresh?: () => void;
}) {
  const deleteCashTx = async (id: string) => {
    const { error } = await supabase.from("cash_transactions").delete().eq("id", id);
    if (error) { alert("ডিলিট করা যায়নি: " + error.message); return; }
    refresh?.();
  };
  const [date, setDate] = useState<string>(today());
  const [mode, setMode] = useState<"day" | "month">("day");
  const inRange = (d: string) => mode === "day" ? d === date : d.slice(0, 7) === date.slice(0, 7);
  const rangeLabel = mode === "day" ? date : date.slice(0, 7);

  const cMap = useMemo(() => new Map(customers.map(c => [c.id, c.name])), [customers]);
  const sMap = useMemo(() => new Map(suppliers.map(s => [s.id, s.name])), [suppliers]);

  const DENOM_KEY = "tiles_daily_denom_v1";
  const DENOMS: { label: string; value: number; isDirect?: boolean }[] = [
    { label: "১০০০ X", value: 1000 },
    { label: "৫০০ X", value: 500 },
    { label: "২০০ X", value: 200 },
    { label: "১০০ X", value: 100 },
    { label: "৫০ X", value: 50 },
    { label: "২০ X", value: 20 },
    { label: "১০ X", value: 10 },
    { label: "৫ X", value: 5 },
    { label: "২ X", value: 2 },
    { label: "চেক/বিকাশ", value: 1, isDirect: true },
  ];
  const [denomCounts, setDenomCounts] = useState<number[]>(() => {
    try { const s = JSON.parse(localStorage.getItem(DENOM_KEY) || "[]"); return DENOMS.map((_, i) => Number(s[i]) || 0); } catch { return DENOMS.map(() => 0); }
  });
  const updateDenom = (i: number, v: number) => {
    const next = denomCounts.slice(); next[i] = v || 0; setDenomCounts(next);
    localStorage.setItem(DENOM_KEY, JSON.stringify(next));
  };
  const denomTotal = DENOMS.reduce((a, d, i) => a + (d.isDirect ? denomCounts[i] : denomCounts[i] * d.value), 0);

  const data = useMemo(() => {
    const daySales = sales.filter(s => inRange(s.sale_date));
    const dayCosts = costs.filter(c => inRange(c.cost_date));
    const dayCash = cashTx.filter(c => inRange(c.trans_date));
    const dayPurch = purchases.filter(p => inRange(p.purchase_date));

    const cashSale: Row[] = daySales
      .filter(s => Number(s.paid_amount) > 0)
      .map((s, i) => ({ sl: i + 1, desc: `${s.invoice_no} - ${s.customer_id ? (cMap.get(s.customer_id) || "") : "Anonymous"}`, amount: Number(s.paid_amount) }));

    const dueColl: Row[] = dayCash
      .filter(t => t.type === "in" && /due|collection|বাকি|কালেকশন/i.test(t.reason || ""))
      .map((t, i) => ({ sl: i + 1, desc: t.reason || "Due Collection", amount: Number(t.amount), id: t.id }));

    const dayExp: Row[] = dayCosts.map((c, i) => ({ sl: i + 1, desc: c.description, amount: Number(c.amount) }));

    const returns: Row[] = daySales.filter(s => s.is_returned && Number(s.returned_amount) > 0)
      .map((s, i) => ({ sl: i + 1, desc: `${s.invoice_no} - ${s.customer_id ? (cMap.get(s.customer_id) || "") : "Anonymous"}`, amount: Number(s.returned_amount) }));

    const bank: { sl: number; bank: string; type: string; amount: number }[] = dayCash
      .filter(t => /bank|ব্যাংক/i.test(t.reason || ""))
      .map((t, i) => ({ sl: i + 1, bank: (t.reason || "").replace(/.*bank[: ]*/i, "") || "Bank", type: t.type === "in" ? "জমা" : "উত্তোলন", amount: Number(t.amount) }));

    const purch: { sl: number; supplier: string; amount: number }[] = dayPurch
      .map((p, i) => ({ sl: i + 1, supplier: p.supplier_id ? (sMap.get(p.supplier_id) || "") : "—", amount: Number(p.total_cost) }));

    const sum = (rows: Row[]) => rows.reduce((s, r) => s + r.amount, 0);
    const sumA = <T extends { amount: number }>(rows: T[]) => rows.reduce((s, r) => s + r.amount, 0);

    const cashSaleTotal = sum(cashSale);
    const dueCollTotal = sum(dueColl);
    const expTotal = sum(dayExp);
    const returnTotal = sum(returns);
    const purchTotal = sumA(purch);
    const bankIn = bank.filter(b => b.type === "জমা").reduce((s, b) => s + b.amount, 0);
    const bankOut = bank.filter(b => b.type === "উত্তোলন").reduce((s, b) => s + b.amount, 0);

    const totalCash = cashSaleTotal + dueCollTotal + bankOut;
    const totalExpense = expTotal + returnTotal + purchTotal + bankIn;
    const remaining = totalCash - totalExpense;

    return {
      cashSale, dueColl, dayExp, returns, bank, purch,
      cashSaleTotal, dueCollTotal, expTotal, returnTotal, purchTotal,
      bankIn, bankOut, totalCash, totalExpense, remaining,
    };
  }, [sales, costs, cashTx, purchases, date, mode, cMap, sMap]);

  const printIt = () => window.print();

  const themes: Record<string, Theme> = {
    green:  { header: "bg-emerald-600", headerText: "text-white", row: "bg-emerald-50", border: "border-emerald-400" },
    blue:   { header: "bg-sky-600",     headerText: "text-white", row: "bg-sky-50",     border: "border-sky-400" },
    amber:  { header: "bg-amber-500",   headerText: "text-white", row: "bg-amber-50",   border: "border-amber-400" },
    rose:   { header: "bg-rose-500",    headerText: "text-white", row: "bg-rose-50",    border: "border-rose-400" },
    violet: { header: "bg-violet-600",  headerText: "text-white", row: "bg-violet-50",  border: "border-violet-400" },
    teal:   { header: "bg-teal-600",    headerText: "text-white", row: "bg-teal-50",    border: "border-teal-400" },
    indigo: { header: "bg-indigo-600",  headerText: "text-white", row: "bg-indigo-50",  border: "border-indigo-400" },
    slate:  { header: "bg-slate-700",   headerText: "text-white", row: "bg-slate-50",   border: "border-slate-400" },
  };

  return (
    <div className="max-w-[1400px] print:max-w-full mx-auto p-6 print:p-0 space-y-4 bg-white daily-summary">
      <style>{`
        @media print {
          @page { size: A4 portrait; margin: 6mm; }
          .daily-summary { font-size: 10px; }
          .daily-summary table { font-size: 9.5px !important; }
          .daily-summary input { border: 0 !important; padding: 0 !important; }
          .daily-summary * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; color-adjust: exact !important; }
          .daily-summary { page-break-inside: avoid; }
          .daily-summary .avoid-break { page-break-inside: avoid; break-inside: avoid; }
        }
      `}</style>
      <div className="flex items-center gap-3 print:hidden flex-wrap">
        <div className="flex rounded overflow-hidden border border-indigo-500">
          <button onClick={() => setMode("day")} className={`px-3 py-1.5 text-sm ${mode === "day" ? "bg-indigo-600 text-white" : "bg-white text-indigo-700"}`}>দৈনিক</button>
          <button onClick={() => setMode("month")} className={`px-3 py-1.5 text-sm ${mode === "month" ? "bg-indigo-600 text-white" : "bg-white text-indigo-700"}`}>মাসিক</button>
        </div>
        <label className="font-semibold">{mode === "day" ? "Select Date:" : "Select Month:"}</label>
        {mode === "day" ? (
          <input type="date" value={date} onChange={e => setDate(e.target.value)}
            className="border border-gray-300 rounded px-3 py-1.5 text-sm" />
        ) : (
          <input type="month" value={date.slice(0, 7)} onChange={e => setDate(e.target.value + "-01")}
            className="border border-gray-300 rounded px-3 py-1.5 text-sm" />
        )}
        <button onClick={printIt} className="bg-sky-600 hover:bg-sky-700 text-white px-4 py-1.5 rounded text-sm">Print</button>
      </div>

      <div className="border-2 border-indigo-500 rounded-lg p-5 avoid-break">
        <h2 className="text-center text-xl font-bold mb-3 bg-gradient-to-r from-indigo-600 to-violet-600 text-white py-2.5 rounded">{mode === "day" ? "দৈনিক" : "মাসিক"} সামারি ({rangeLabel})</h2>
        <div className="grid grid-cols-3 gap-4">
          <Box theme={themes.green} title="নগদ বিক্রয় (Cash Sale)" headers={["ক্রম", "বিবরণ", "টাকা"]}
            rows={data.cashSale.map(r => [r.sl, r.desc, Math.round(r.amount)])} />
          <Box theme={themes.blue} title="বাকি উত্তোলন / কালেকশন" headers={["ক্রম", "বিবরণ", "টাকা"]}
            rows={data.dueColl.map(r => [r.sl, r.desc, Math.round(r.amount)])}
            deleteIds={data.dueColl.map(r => r.id || "")}
            onDelete={deleteCashTx} />
          <Box theme={themes.amber} title="দৈনিক খরচ" headers={["ক্রম", "খরচের ধরন", "পরিমাণ"]}
            rows={data.dayExp.map(r => [r.sl, r.desc, Math.round(r.amount)])} />

          <Box theme={themes.teal} title="পণ্য ফেরত থেকে বাকি উত্তোলন" headers={["ক্রম", "বিবরণ", "টাকা"]} rows={[]} />
          <Box theme={themes.indigo} title="দৈনিক জমা / উত্তোলন" headers={["ক্রম", "টাইপ", "পরিমাণ"]}
            rows={data.bank.map(b => [b.sl, b.type, Math.round(b.amount)])} />
          <Box theme={themes.rose} title="পণ্য ফেরতের টাকা ক্রেতাকে প্রদান" headers={["ক্রম", "বিবরণ", "টাকা"]}
            rows={data.returns.map(r => [r.sl, r.desc, Math.round(r.amount)])} />

          <div className="border border-slate-500 rounded overflow-hidden avoid-break">
            <div className="relative text-center font-semibold py-2 text-sm bg-slate-800 text-white">
              নগদ টাকার বিবরণ
              <button
                onClick={() => {
                  const zeros = DENOMS.map(() => 0);
                  setDenomCounts(zeros);
                  localStorage.setItem(DENOM_KEY, JSON.stringify(zeros));
                }}
                className="print:hidden absolute right-2 top-1/2 -translate-y-1/2 bg-blue-500 hover:bg-blue-600 text-white text-[10px] px-2 py-0.5 rounded"
              >
                রিফ্রেশ
              </button>
            </div>
            <table className="w-full text-xs border-collapse">
              <tbody>
                {DENOMS.map((d, i) => (
                  <tr key={d.label} className={i % 2 ? "bg-slate-50" : ""}>
                    <td className="border border-slate-400 px-2 py-1 text-center w-24">{d.label}</td>
                    <td className="border border-slate-400 px-1 py-1 w-20">
                      <input
                        type="number"
                        min={0}
                        value={denomCounts[i] || ""}
                        onChange={e => updateDenom(i, parseInt(e.target.value) || 0)}
                        className="w-full text-right px-2 py-0.5 text-xs border rounded"
                      />
                    </td>
                    <td className="border border-slate-400 px-2 py-1 text-center w-8">=</td>
                    <td className="border border-slate-400 px-2 py-1 text-right w-24">{Math.round(d.isDirect ? denomCounts[i] : denomCounts[i] * d.value)}</td>
                  </tr>
                ))}
                <tr className="bg-slate-800 text-white font-semibold">
                  <td className="border border-slate-400 px-2 py-1 text-center" colSpan={2}>টাকা</td>
                  <td className="border border-slate-400 px-2 py-1 text-center">=</td>
                  <td className="border border-slate-400 px-2 py-1 text-right">{Math.round(denomTotal)}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <Box theme={themes.violet} title="দৈনিক ক্রয়" headers={["ক্রম", "সরবরাহকারী", "ক্রয় মূল্য"]}
            rows={data.purch.map(p => [p.sl, p.supplier, Math.round(p.amount)])} />

          <div className="col-span-1 avoid-break">
            <div className="border border-emerald-500 rounded overflow-hidden">
              <div className="text-center font-semibold py-2 text-sm bg-emerald-700 text-white">সারাংশ (Summary)</div>
              <table className="w-full text-xs border-collapse">
                <thead className="bg-emerald-100"><tr><th className="border border-emerald-400 px-2 py-1">বিবরণ</th><th className="border border-emerald-400 px-2 py-1">পরিমাণ</th></tr></thead>
                <tbody>
                  <tr><td className="border border-emerald-400 px-2 py-1">দিনের শুরুতে নগদ টাকা</td><td className="border border-emerald-400 px-2 py-1 text-right">0</td></tr>
                  <tr className="bg-emerald-50"><td className="border border-emerald-400 px-2 py-1">নগদ বিক্রয়</td><td className="border border-emerald-400 px-2 py-1 text-right">{Math.round(data.cashSaleTotal)}</td></tr>
                  <tr><td className="border border-emerald-400 px-2 py-1">পণ্য ফেরত থেকে বাকি উত্তোলন</td><td className="border border-emerald-400 px-2 py-1 text-right">0</td></tr>
                  <tr className="bg-emerald-50"><td className="border border-emerald-400 px-2 py-1">বাকি উত্তোলন / কালেকশন</td><td className="border border-emerald-400 px-2 py-1 text-right">{Math.round(data.dueCollTotal)}</td></tr>
                  <tr><td className="border border-emerald-400 px-2 py-1">ব্যাংক থেকে উত্তোলন</td><td className="border border-emerald-400 px-2 py-1 text-right">{Math.round(data.bankOut)}</td></tr>
                  <tr className="bg-emerald-600 text-white font-semibold"><td className="border border-emerald-400 px-2 py-1">নগদ</td><td className="border border-emerald-400 px-2 py-1 text-right">{Math.round(data.totalCash)}</td></tr>
                  <tr><td className="border border-emerald-400 px-2 py-1">দৈনিক খরচ</td><td className="border border-emerald-400 px-2 py-1 text-right">{Math.round(data.expTotal)}</td></tr>
                  <tr className="bg-rose-50"><td className="border border-emerald-400 px-2 py-1">রিটার্ন পণ্যের টাকা ফেরত</td><td className="border border-emerald-400 px-2 py-1 text-right">{Math.round(data.returnTotal)}</td></tr>
                  <tr><td className="border border-emerald-400 px-2 py-1">দৈনিক ক্রয়</td><td className="border border-emerald-400 px-2 py-1 text-right">{Math.round(data.purchTotal)}</td></tr>
                  <tr className="bg-rose-50"><td className="border border-emerald-400 px-2 py-1">ব্যাংকে জমা</td><td className="border border-emerald-400 px-2 py-1 text-right">{Math.round(data.bankIn)}</td></tr>
                  <tr><td className="border border-emerald-400 px-2 py-1">আজকের উত্তোলন</td><td className="border border-emerald-400 px-2 py-1 text-right">0</td></tr>
                  <tr className="bg-rose-600 text-white font-semibold"><td className="border border-emerald-400 px-2 py-1">মোট খরচ</td><td className="border border-emerald-400 px-2 py-1 text-right">{Math.round(data.totalExpense)}</td></tr>
                  <tr className="bg-indigo-700 text-white font-bold text-sm"><td className="border border-emerald-400 px-2 py-1.5">অবশিষ্ট</td><td className="border border-emerald-400 px-2 py-1.5 text-right">{Math.round(data.remaining)}</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
