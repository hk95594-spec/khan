import { useMemo, useState } from "react";
import {
  Building2, TrendingUp, ShoppingCart, Undo2, Package, AlertTriangle,
  Download, Printer, Search, Wallet, Coins, Trophy, Share2, BarChart3,
  ArrowUpRight, ArrowDownRight, Boxes,
} from "lucide-react";
import { toast } from "sonner";
import jsPDF from "jspdf";

type Product = {
  id: string; name: string; category: string | null; company: string | null; size: string | null;
  sqft_per_piece: number; pcs_per_carton: number; stock_pieces: number;
  purchase_price_per_piece: number; sell_price_per_piece: number;
  min_label_feet?: number;
};
type SaleItem = { productId: string; pieces: number; totalPrice: number };
type Sale = {
  id: string; invoice_no: string; customer_id: string | null; total_amount: number;
  paid_amount: number; due_amount: number; items: SaleItem[]; is_returned: boolean;
  returned_amount: number; sale_date: string;
};
type Purchase = {
  id: string; product_id: string | null; supplier_id: string | null;
  pieces: number; cost_per_piece: number; total_cost: number; purchase_date: string;
};
type Company = { id: string; name: string };
type Supplier = { id: string; name: string; mobile: string | null; address: string | null; advance: number; total_due: number };

type Period = "today" | "week" | "month" | "all" | "custom";

const fmt = (n: number) => `৳${Number(n || 0).toLocaleString("en-BD", { maximumFractionDigits: 2 })}`;
const today = () => new Date().toISOString().slice(0, 10);
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const iso = (d: Date) => d.toISOString().slice(0, 10);

export default function CompanyReport({
  companies, products, sales, purchases, suppliers,
}: {
  companies: Company[]; products: Product[]; sales: Sale[]; purchases: Purchase[]; suppliers: Supplier[];
}) {
  const [period, setPeriod] = useState<Period>("month");
  const [fromDate, setFromDate] = useState<string>(iso(addDays(new Date(), -30)));
  const [toDate, setToDate] = useState<string>(today());
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string | null>(null);

  const range = useMemo(() => {
    const now = new Date();
    if (period === "today") return { from: today(), to: today() };
    if (period === "week") return { from: iso(addDays(now, -7)), to: today() };
    if (period === "month") return { from: iso(addDays(now, -30)), to: today() };
    if (period === "all") return { from: "0000-01-01", to: "9999-12-31" };
    return { from: fromDate, to: toDate };
  }, [period, fromDate, toDate]);

  const inRange = (d: string) => d >= range.from && d <= range.to;
  const productMap = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);

  // ---------- per company aggregates ----------
  const rows = useMemo(() => {
    return companies.map((co) => {
      const coProducts = products.filter((p) => p.company === co.name);
      const productIds = new Set(coProducts.map((p) => p.id));

      // Stock
      const stockPieces = coProducts.reduce((s, p) => s + Number(p.stock_pieces), 0);
      const stockValue = coProducts.reduce((s, p) => s + Number(p.stock_pieces) * Number(p.purchase_price_per_piece), 0);
      const lowStock = coProducts.filter((p) => {
        const feet = p.stock_pieces * Number(p.sqft_per_piece || 0);
        const min = Number(p.min_label_feet || 0);
        return min > 0 ? feet <= min : p.stock_pieces <= 10;
      }).length;

      // Purchases in range
      let purchaseAmount = 0, purchasePieces = 0;
      purchases.forEach((pu) => {
        if (!pu.product_id || !productIds.has(pu.product_id)) return;
        if (!inRange(pu.purchase_date)) return;
        purchaseAmount += Number(pu.total_cost);
        purchasePieces += Number(pu.pieces);
      });

      // Sales / Profit / Returns / Due / Paid in range
      let saleAmount = 0, salePieces = 0, profit = 0, returnAmount = 0, due = 0, paid = 0;
      const productSold = new Map<string, { pieces: number; amount: number; name: string }>();

      sales.forEach((s) => {
        if (!inRange(s.sale_date)) return;
        const itemsForCo = (s.items || []).filter((it) => productIds.has(it.productId));
        if (!itemsForCo.length) return;
        const coTotal = itemsForCo.reduce((a, it) => a + Number(it.totalPrice), 0);
        const saleTotal = Number(s.total_amount) || 1;
        const ratio = coTotal / saleTotal;

        saleAmount += coTotal;
        due += Number(s.due_amount) * ratio;
        paid += Number(s.paid_amount) * ratio;
        if (s.is_returned) returnAmount += Number(s.returned_amount) * ratio;

        itemsForCo.forEach((it) => {
          const p = productMap.get(it.productId);
          if (!p) return;
          salePieces += it.pieces;
          const cost = Number(p.purchase_price_per_piece) * it.pieces;
          profit += Number(it.totalPrice) - cost;
          const cur = productSold.get(it.productId) || { pieces: 0, amount: 0, name: p.name };
          cur.pieces += it.pieces; cur.amount += Number(it.totalPrice);
          productSold.set(it.productId, cur);
        });
      });

      // adjust profit for returns proportionally
      if (saleAmount > 0) profit -= profit * (returnAmount / saleAmount);

      const topProducts = Array.from(productSold.values()).sort((a, b) => b.amount - a.amount).slice(0, 5);
      const fastMoving = Array.from(productSold.values()).sort((a, b) => b.pieces - a.pieces).slice(0, 3);
      const slowMoving = coProducts
        .filter((p) => !productSold.has(p.id) && p.stock_pieces > 0)
        .slice(0, 3)
        .map((p) => ({ name: p.name, pieces: p.stock_pieces, amount: 0 }));

      return {
        id: co.id, name: co.name,
        productCount: coProducts.length,
        stockPieces, stockValue, lowStock,
        purchaseAmount, purchasePieces,
        saleAmount, salePieces,
        returnAmount, profit, due, paid,
        topProducts, fastMoving, slowMoving,
      };
    });
  }, [companies, products, sales, purchases, productMap, range]);

  const filteredRows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? rows.filter((r) => r.name.toLowerCase().includes(q)) : rows;
  }, [rows, search]);

  // ---------- totals ----------
  const totals = useMemo(() => rows.reduce((acc, r) => ({
    purchase: acc.purchase + r.purchaseAmount,
    sale: acc.sale + r.saleAmount,
    profit: acc.profit + r.profit,
    due: acc.due + r.due,
    paid: acc.paid + r.paid,
    ret: acc.ret + r.returnAmount,
    stock: acc.stock + r.stockValue,
  }), { purchase: 0, sale: 0, profit: 0, due: 0, paid: 0, ret: 0, stock: 0 }), [rows]);

  // ---------- export ----------
  const exportPDF = () => {
    try {
      const doc = new jsPDF();
      doc.setFontSize(16); doc.text("Company Report", 14, 16);
      doc.setFontSize(10); doc.text(`Period: ${range.from} to ${range.to}`, 14, 24);
      let y = 34;
      doc.text("Company", 14, y); doc.text("Purchase", 70, y); doc.text("Sale", 105, y);
      doc.text("Profit", 135, y); doc.text("Due", 165, y); y += 4;
      doc.line(14, y, 196, y); y += 5;
      filteredRows.forEach((r) => {
        if (y > 280) { doc.addPage(); y = 20; }
        doc.text(r.name.slice(0, 26), 14, y);
        doc.text(r.purchaseAmount.toFixed(0), 70, y);
        doc.text(r.saleAmount.toFixed(0), 105, y);
        doc.text(r.profit.toFixed(0), 135, y);
        doc.text(r.due.toFixed(0), 165, y);
        y += 6;
      });
      doc.save(`company-report-${range.from}-${range.to}.pdf`);
      toast.success("PDF downloaded");
    } catch { toast.error("Failed to export"); }
  };

  const exportCSV = () => {
    const header = "Company,Purchase,Sale,Return,Profit,Paid,Due,StockValue,LowStock\n";
    const body = filteredRows.map((r) =>
      [r.name, r.purchaseAmount, r.saleAmount, r.returnAmount, r.profit, r.paid, r.due, r.stockValue, r.lowStock].join(",")
    ).join("\n");
    const blob = new Blob([header + body], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `company-report-${range.from}-${range.to}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV downloaded");
  };

  const shareWhatsApp = () => {
    const lines = [
      `📊 Company Report (${range.from} → ${range.to})`,
      `Total Purchase: ${fmt(totals.purchase)}`,
      `Total Sale: ${fmt(totals.sale)}`,
      `Profit: ${fmt(totals.profit)}`,
      `Due: ${fmt(totals.due)}`,
      ``,
      ...filteredRows.slice(0, 10).map((r) => `• ${r.name}: Sale ${fmt(r.saleAmount)} | Profit ${fmt(r.profit)}`),
    ].join("\n");
    window.open(`https://wa.me/?text=${encodeURIComponent(lines)}`, "_blank");
  };

  const ranking = [...rows].sort((a, b) => b.saleAmount - a.saleAmount);
  const selectedRow = selected ? rows.find((r) => r.id === selected) : null;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 text-white p-5 shadow-lg">
        <div className="absolute inset-0 bg-white/5 backdrop-blur-sm" />
        <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
              <Building2 className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">Company Report</h2>
              <p className="text-sm text-white/80">Smart automation • Purchase / Sale / Profit / Due</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={exportPDF} className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur px-3 py-2 rounded-lg text-sm">
              <Download className="w-4 h-4" /> PDF
            </button>
            <button onClick={exportCSV} className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur px-3 py-2 rounded-lg text-sm">
              <Download className="w-4 h-4" /> Excel
            </button>
            <button onClick={shareWhatsApp} className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur px-3 py-2 rounded-lg text-sm">
              <Share2 className="w-4 h-4" /> WhatsApp
            </button>
            <button onClick={() => window.print()} className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur px-3 py-2 rounded-lg text-sm">
              <Printer className="w-4 h-4" /> Print
            </button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white/80 backdrop-blur rounded-2xl shadow-sm p-4 border border-white/60">
        <div className="flex flex-wrap gap-2 mb-3">
          {(["today", "week", "month", "all", "custom"] as Period[]).map((p) => (
            <button key={p} onClick={() => setPeriod(p)} className={`px-3 py-1.5 text-sm rounded-lg capitalize transition ${period === p ? "bg-indigo-600 text-white shadow" : "bg-gray-100 hover:bg-gray-200"}`}>{p}</button>
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <label className="text-xs font-medium text-gray-600">From</label>
            <input type="date" value={range.from === "0000-01-01" ? "" : range.from} onChange={(e) => { setPeriod("custom"); setFromDate(e.target.value); }} className="border rounded-lg p-2 w-full text-sm" />
          </div>
          <div>
            <label className="text-xs font-medium text-gray-600">To</label>
            <input type="date" value={range.to === "9999-12-31" ? "" : range.to} onChange={(e) => { setPeriod("custom"); setToDate(e.target.value); }} className="border rounded-lg p-2 w-full text-sm" />
          </div>
          <div>
            <label className="text-xs font-medium text-gray-600">Search Company</label>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-2 top-2.5 text-gray-400" />
              <input placeholder="Company name…" value={search} onChange={(e) => setSearch(e.target.value)} className="border rounded-lg p-2 pl-8 w-full text-sm" />
            </div>
          </div>
        </div>
      </div>

      {/* Top KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Kpi icon={ShoppingCart} label="Total Purchase" value={fmt(totals.purchase)} gradient="from-emerald-500 to-teal-600" />
        <Kpi icon={TrendingUp} label="Total Sale" value={fmt(totals.sale)} gradient="from-blue-500 to-indigo-600" />
        <Kpi icon={BarChart3} label="Total Profit" value={fmt(totals.profit)} gradient="from-amber-500 to-orange-600" />
        <Kpi icon={Undo2} label="Total Return" value={fmt(totals.ret)} gradient="from-rose-500 to-pink-600" />
        <Kpi icon={Wallet} label="Total Paid" value={fmt(totals.paid)} gradient="from-cyan-500 to-sky-600" />
        <Kpi icon={Coins} label="Total Due" value={fmt(totals.due)} gradient="from-red-500 to-rose-600" />
        <Kpi icon={Package} label="Stock Value" value={fmt(totals.stock)} gradient="from-violet-500 to-purple-600" />
        <Kpi icon={Building2} label="Companies" value={String(companies.length)} gradient="from-slate-600 to-gray-700" />
      </div>

      {/* Smart Alerts */}
      <SmartAlerts rows={rows} />

      {/* Ranking & Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Ranking */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="px-4 py-3 bg-gradient-to-r from-amber-50 to-yellow-50 border-b flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold">Top Companies (Ranking)</h3>
          </div>
          <div className="divide-y">
            {ranking.slice(0, 8).map((r, i) => (
              <button key={r.id} onClick={() => setSelected(r.id)} className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 text-left">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${i === 0 ? "bg-amber-500" : i === 1 ? "bg-gray-400" : i === 2 ? "bg-orange-500" : "bg-indigo-400"}`}>{i + 1}</div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{r.name}</div>
                  <div className="text-xs text-gray-500">{r.productCount} products</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-sm">{fmt(r.saleAmount)}</div>
                  <div className={`text-xs flex items-center gap-1 justify-end ${r.profit >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {r.profit >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    {fmt(r.profit)}
                  </div>
                </div>
              </button>
            ))}
            {ranking.length === 0 && <p className="p-6 text-sm text-center text-gray-400">No companies yet</p>}
          </div>
        </div>

        {/* Company cards */}
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredRows.map((r) => (
            <button key={r.id} onClick={() => setSelected(r.id)} className="text-left bg-white p-4 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md hover:-translate-y-0.5 transition">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 text-white flex items-center justify-center">
                  <Building2 className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold truncate">{r.name}</h3>
                  <p className="text-xs text-gray-500">{r.productCount} SKU • {r.salePieces} sold</p>
                </div>
                {r.lowStock > 0 && (
                  <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> {r.lowStock}
                  </span>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <Stat label="Purchase" value={fmt(r.purchaseAmount)} color="text-emerald-700" />
                <Stat label="Sale" value={fmt(r.saleAmount)} color="text-blue-700" />
                <Stat label="Profit" value={fmt(r.profit)} color={r.profit >= 0 ? "text-amber-700" : "text-red-700"} />
                <Stat label="Due" value={fmt(r.due)} color="text-rose-700" />
                <Stat label="Return" value={fmt(r.returnAmount)} color="text-pink-700" />
                <Stat label="Stock" value={fmt(r.stockValue)} color="text-violet-700" />
              </div>
            </button>
          ))}
          {filteredRows.length === 0 && (
            <div className="md:col-span-2 bg-white p-10 rounded-2xl text-center text-gray-400 border border-dashed">
              No companies match the search.
            </div>
          )}
        </div>
      </div>

      {/* Detail modal */}
      {selectedRow && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelected(null)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="p-5 bg-gradient-to-r from-indigo-600 to-violet-600 text-white rounded-t-2xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Building2 className="w-7 h-7" />
                <div>
                  <h3 className="text-xl font-bold">{selectedRow.name}</h3>
                  <p className="text-xs text-white/80">{range.from} → {range.to}</p>
                </div>
              </div>
              <button onClick={() => setSelected(null)} className="text-white/80 hover:text-white text-xl">✕</button>
            </div>
            <div className="p-5 space-y-5">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <MiniBox label="Purchase" value={fmt(selectedRow.purchaseAmount)} color="bg-emerald-500" />
                <MiniBox label="Sale" value={fmt(selectedRow.saleAmount)} color="bg-blue-500" />
                <MiniBox label="Profit" value={fmt(selectedRow.profit)} color="bg-amber-500" />
                <MiniBox label="Return" value={fmt(selectedRow.returnAmount)} color="bg-rose-500" />
                <MiniBox label="Paid" value={fmt(selectedRow.paid)} color="bg-cyan-500" />
                <MiniBox label="Due" value={fmt(selectedRow.due)} color="bg-red-500" />
                <MiniBox label="Stock Value" value={fmt(selectedRow.stockValue)} color="bg-violet-500" />
                <MiniBox label="Low Stock" value={String(selectedRow.lowStock)} color="bg-orange-500" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <ListCard title="🔥 Fast Moving" items={selectedRow.fastMoving.map((p) => ({ name: p.name, sub: `${p.pieces} pcs`, val: fmt(p.amount) }))} empty="No sales yet" />
                <ListCard title="🐢 Slow / Dead Stock" items={selectedRow.slowMoving.map((p) => ({ name: p.name, sub: `${p.pieces} pcs in stock`, val: "—" }))} empty="All products moving" />
              </div>

              <div className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-4 border">
                <h4 className="font-bold mb-3 flex items-center gap-2"><Boxes className="w-4 h-4" /> Top Selling Products</h4>
                {selectedRow.topProducts.length === 0 ? (
                  <p className="text-sm text-gray-400">No products sold in this period.</p>
                ) : (
                  <table className="w-full text-sm">
                    <thead className="text-gray-500">
                      <tr><th className="text-left p-1">Product</th><th className="text-right p-1">Pieces</th><th className="text-right p-1">Amount</th></tr>
                    </thead>
                    <tbody>
                      {selectedRow.topProducts.map((p, i) => (
                        <tr key={i} className="border-t">
                          <td className="p-1">{p.name}</td>
                          <td className="p-1 text-right">{p.pieces}</td>
                          <td className="p-1 text-right font-semibold">{fmt(p.amount)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Kpi({ icon: Icon, label, value, gradient }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; gradient: string }) {
  return (
    <div className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${gradient} text-white p-4 shadow-md`}>
      <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/10 rounded-full blur-2xl" />
      <div className="relative flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-white/20 backdrop-blur flex items-center justify-center">
          <Icon className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <div className="text-xs opacity-80 truncate">{label}</div>
          <div className="font-extrabold text-lg truncate">{value}</div>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="bg-gray-50 rounded-lg p-2">
      <div className="text-[10px] text-gray-500 uppercase tracking-wide">{label}</div>
      <div className={`font-bold ${color} truncate`}>{value}</div>
    </div>
  );
}

function MiniBox({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="rounded-xl p-3 text-white shadow-sm" style={{}}>
      <div className={`rounded-xl p-3 ${color}`}>
        <div className="text-[10px] opacity-90 uppercase">{label}</div>
        <div className="font-extrabold truncate">{value}</div>
      </div>
    </div>
  );
}

function ListCard({ title, items, empty }: { title: string; items: { name: string; sub: string; val: string }[]; empty: string }) {
  return (
    <div className="bg-white rounded-xl border p-4">
      <h4 className="font-bold mb-2">{title}</h4>
      {items.length === 0 ? <p className="text-sm text-gray-400">{empty}</p> : (
        <ul className="space-y-2">
          {items.map((it, i) => (
            <li key={i} className="flex items-center justify-between text-sm border-b last:border-0 pb-2">
              <div className="min-w-0">
                <div className="font-medium truncate">{it.name}</div>
                <div className="text-xs text-gray-500">{it.sub}</div>
              </div>
              <div className="font-semibold ml-2">{it.val}</div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function SmartAlerts({ rows }: { rows: { name: string; due: number; lowStock: number; profit: number; saleAmount: number; purchaseAmount: number }[] }) {
  const alerts: { type: "warn" | "info" | "danger"; msg: string }[] = [];
  rows.forEach((r) => {
    if (r.due > 50000) alerts.push({ type: "danger", msg: `${r.name}: High due ${fmt(r.due)}` });
    if (r.lowStock > 0) alerts.push({ type: "warn", msg: `${r.name}: ${r.lowStock} product(s) low stock` });
    if (r.purchaseAmount > 0 && r.saleAmount === 0) alerts.push({ type: "info", msg: `${r.name}: Purchased but no sale yet` });
    if (r.profit < 0) alerts.push({ type: "danger", msg: `${r.name}: Loss ${fmt(Math.abs(r.profit))}` });
  });
  if (!alerts.length) return null;
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
      <h3 className="font-bold flex items-center gap-2 mb-3"><AlertTriangle className="w-5 h-5 text-amber-500" /> Smart Alerts</h3>
      <div className="flex flex-wrap gap-2">
        {alerts.slice(0, 10).map((a, i) => (
          <span key={i} className={`text-xs px-3 py-1.5 rounded-full border ${
            a.type === "danger" ? "bg-red-50 text-red-700 border-red-200" :
            a.type === "warn" ? "bg-amber-50 text-amber-700 border-amber-200" :
            "bg-blue-50 text-blue-700 border-blue-200"
          }`}>{a.msg}</span>
        ))}
      </div>
    </div>
  );
}
