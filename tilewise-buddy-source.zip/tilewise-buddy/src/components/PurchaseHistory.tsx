import { useMemo, useState } from "react";
import { loadMeta } from "./PurchaseProduct";
import { Pencil, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type Product = {
  id: string; name: string; category: string | null; company: string | null; size: string | null;
  pcs_per_carton?: number; sqft_per_piece?: number; stock_pieces?: number;
};
type Supplier = { id: string; name: string; total_due?: number };
type Purchase = { id: string; product_id: string | null; supplier_id: string | null; pieces: number; cost_per_piece: number; total_cost: number; purchase_date: string };

type DateMode = "all" | "today" | "custom" | "range";

export default function PurchaseHistory({
  purchases, products, suppliers, refresh,
}: {
  purchases: Purchase[]; products: Product[]; suppliers: Supplier[]; refresh: () => void;
}) {
  const meta = useMemo(() => loadMeta(), [purchases]);
  const today = new Date().toISOString().slice(0, 10);

  const [dateMode, setDateMode] = useState<DateMode>("all");
  const [customDate, setCustomDate] = useState(today);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [perPage, setPerPage] = useState(20);
  const [page, setPage] = useState(1);
  const [gotoPage, setGotoPage] = useState("");

  const [qSL, setQSL] = useState("");
  const [qProduct, setQProduct] = useState("");
  const [qSupplier, setQSupplier] = useState("");
  const [qCompany, setQCompany] = useState("");

  const [editRow, setEditRow] = useState<Purchase | null>(null);

  const numbered = useMemo(() => {
    const asc = [...purchases].sort((a, b) =>
      a.purchase_date === b.purchase_date
        ? a.id.localeCompare(b.id)
        : a.purchase_date.localeCompare(b.purchase_date),
    );
    const slMap = new Map<string, number>();
    asc.forEach((p, i) => slMap.set(p.id, i + 1));
    return [...purchases]
      .sort((a, b) =>
        a.purchase_date === b.purchase_date
          ? b.id.localeCompare(a.id)
          : b.purchase_date.localeCompare(a.purchase_date),
      )
      .map((p) => {
        const prod = products.find((x) => x.id === p.product_id);
        const sup = suppliers.find((x) => x.id === p.supplier_id);
        const m = meta[p.id] || {};
        const pcs = Number(p.pieces) || 0;
        const carton = prod?.pcs_per_carton ? pcs / Number(prod.pcs_per_carton) : 0;
        const qtyFeet = prod?.sqft_per_piece ? pcs * Number(prod.sqft_per_piece) : pcs;
        return { p, prod, sup, m, sl: slMap.get(p.id) || 0, carton, qtyFeet };
      });
  }, [purchases, products, suppliers, meta]);

  const filtered = useMemo(() => {
    return numbered.filter((r) => {
      if (dateMode === "today" && r.p.purchase_date !== today) return false;
      if (dateMode === "custom" && r.p.purchase_date !== customDate) return false;
      if (dateMode === "range") {
        if (from && r.p.purchase_date < from) return false;
        if (to && r.p.purchase_date > to) return false;
      }
      if (qSL && !String(r.sl).includes(qSL.trim())) return false;
      if (qProduct && !(r.prod?.name || "").toLowerCase().includes(qProduct.toLowerCase())) return false;
      if (qSupplier && !(r.sup?.name || "").toLowerCase().includes(qSupplier.toLowerCase())) return false;
      if (qCompany && !(r.prod?.company || "").toLowerCase().includes(qCompany.toLowerCase())) return false;
      return true;
    });
  }, [numbered, dateMode, customDate, from, to, today, qSL, qProduct, qSupplier, qCompany]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const currentPage = Math.min(page, totalPages);
  const rows = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);

  const fmtDate = (d: string) => {
    try {
      const dt = new Date(d);
      return dt.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
    } catch { return d; }
  };

  const handleDelete = async (r: Purchase) => {
    if (!confirm("আপনি কি এই purchase টি ডিলিট করতে চান? Stock এবং Supplier due ঠিক হয়ে যাবে।")) return;
    try {
      // restore stock
      if (r.product_id) {
        const prod = products.find((x) => x.id === r.product_id);
        if (prod) {
          await supabase.from("products").update({
            stock_pieces: Math.max(0, Number(prod.stock_pieces || 0) - Number(r.pieces || 0)),
          }).eq("id", r.product_id);
        }
      }
      // adjust supplier due (reverse the unpaid portion)
      if (r.supplier_id) {
        const sup = suppliers.find((x) => x.id === r.supplier_id);
        const m = meta[r.id] || {};
        const paid = Number(m.paid || 0);
        const unpaid = Math.max(0, Number(r.total_cost || 0) - paid);
        if (sup && unpaid > 0) {
          await supabase.from("suppliers").update({
            total_due: Math.max(0, Number(sup.total_due || 0) - unpaid),
          }).eq("id", r.supplier_id);
        }
      }
      const { error } = await supabase.from("purchases").delete().eq("id", r.id);
      if (error) throw error;
      // clear meta
      try {
        const raw = localStorage.getItem("tiles_purchase_meta_v1");
        if (raw) {
          const m = JSON.parse(raw);
          delete m[r.id];
          localStorage.setItem("tiles_purchase_meta_v1", JSON.stringify(m));
        }
      } catch { /* ignore */ }
      toast.success("Purchase ডিলিট হয়েছে");
      refresh();
    } catch (e: any) {
      toast.error(e?.message || "Delete ব্যর্থ");
    }
  };

  const tabBtn = (active: boolean) =>
    `px-4 py-1.5 rounded-md text-sm font-medium ${active ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <button onClick={() => { setDateMode("all"); setPage(1); }} className={tabBtn(dateMode === "all")}>All</button>
        <button onClick={() => { setDateMode("today"); setPage(1); }} className={tabBtn(dateMode === "today")}>Today</button>
        <button onClick={() => { setDateMode("custom"); setPage(1); }} className={tabBtn(dateMode === "custom")}>Custom Date</button>
        <button onClick={() => { setDateMode("range"); setPage(1); }} className={tabBtn(dateMode === "range")}>Custom Range</button>
        {dateMode === "custom" && (
          <input type="date" value={customDate} onChange={(e) => { setCustomDate(e.target.value); setPage(1); }} className="border border-gray-300 rounded px-2 py-1 text-sm" />
        )}
        {dateMode === "range" && (
          <>
            <input type="date" value={from} onChange={(e) => { setFrom(e.target.value); setPage(1); }} className="border border-gray-300 rounded px-2 py-1 text-sm" />
            <span className="text-sm text-gray-500">to</span>
            <input type="date" value={to} onChange={(e) => { setTo(e.target.value); setPage(1); }} className="border border-gray-300 rounded px-2 py-1 text-sm" />
          </>
        )}
      </div>

      <div className="flex items-center gap-2 text-sm">
        <span className="text-gray-700">Items per page:</span>
        <select value={perPage} onChange={(e) => { setPerPage(Number(e.target.value)); setPage(1); }} className="border border-gray-300 rounded px-2 py-1">
          {[10, 20, 50, 100, 200].map((n) => <option key={n} value={n}>{n}</option>)}
        </select>
        <span className="text-gray-500 ml-2">{rows.length} / {filtered.length}</span>
      </div>

      <div className="overflow-x-auto border border-gray-300 bg-white">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-white">
              <th className="border border-gray-300 p-2 text-left">SL</th>
              <th className="border border-gray-300 p-2 text-left">Product</th>
              <th className="border border-gray-300 p-2 text-left">Supplier</th>
              <th className="border border-gray-300 p-2 text-left">Company</th>
              <th className="border border-gray-300 p-2 text-right">Price</th>
              <th className="border border-gray-300 p-2 text-right">Qty / Feet</th>
              <th className="border border-gray-300 p-2 text-right">Caton</th>
              <th className="border border-gray-300 p-2 text-right">Total</th>
              <th className="border border-gray-300 p-2 text-left">Date</th>
              <th className="border border-gray-300 p-2 text-center">Action</th>
            </tr>
            <tr className="bg-gray-50">
              <th className="border border-gray-300 p-1"><input value={qSL} onChange={(e) => { setQSL(e.target.value); setPage(1); }} placeholder="Search SL" className="w-full border border-gray-200 rounded px-1.5 py-1 text-xs" /></th>
              <th className="border border-gray-300 p-1"><input value={qProduct} onChange={(e) => { setQProduct(e.target.value); setPage(1); }} placeholder="Search Product" className="w-full border border-gray-200 rounded px-1.5 py-1 text-xs" /></th>
              <th className="border border-gray-300 p-1"><input value={qSupplier} onChange={(e) => { setQSupplier(e.target.value); setPage(1); }} placeholder="Search Supplier" className="w-full border border-gray-200 rounded px-1.5 py-1 text-xs" /></th>
              <th className="border border-gray-300 p-1"><input value={qCompany} onChange={(e) => { setQCompany(e.target.value); setPage(1); }} placeholder="Search Company" className="w-full border border-gray-200 rounded px-1.5 py-1 text-xs" /></th>
              <th className="border border-gray-300 p-1"></th>
              <th className="border border-gray-300 p-1"></th>
              <th className="border border-gray-300 p-1"></th>
              <th className="border border-gray-300 p-1"></th>
              <th className="border border-gray-300 p-1"></th>
              <th className="border border-gray-300 p-1"></th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr><td colSpan={10} className="p-6 text-center text-gray-400 border border-gray-300">No purchases found</td></tr>
            ) : rows.map((r) => (
              <tr key={r.p.id} className="hover:bg-gray-50">
                <td className="border border-gray-300 p-2">{r.sl}</td>
                <td className="border border-gray-300 p-2 font-medium">{r.prod?.name || "—"}</td>
                <td className="border border-gray-300 p-2">{r.sup?.name || "—"}</td>
                <td className="border border-gray-300 p-2">{r.prod?.company || "—"}</td>
                <td className="border border-gray-300 p-2 text-right">{Number(r.p.total_cost).toFixed(0)}</td>
                <td className="border border-gray-300 p-2 text-right">{r.qtyFeet.toFixed(2)}</td>
                <td className="border border-gray-300 p-2 text-right">{Math.round(r.carton)}</td>
                <td className="border border-gray-300 p-2 text-right font-semibold">{Number(r.p.total_cost).toFixed(0)}</td>
                <td className="border border-gray-300 p-2 whitespace-nowrap">{fmtDate(r.p.purchase_date)}</td>
                <td className="border border-gray-300 p-2 text-center">
                  <div className="flex items-center justify-center gap-2">
                    <button onClick={() => setEditRow(r.p)} className="text-blue-600 hover:text-blue-800" title="Edit"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => handleDelete(r.p)} className="text-red-600 hover:text-red-800" title="Delete"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex flex-wrap items-center justify-center gap-3 text-sm py-2">
        <button
          disabled={currentPage <= 1}
          onClick={() => setPage(currentPage - 1)}
          className="px-3 py-1 text-gray-600 hover:text-gray-900 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Previous
        </button>
        <span className="text-gray-700">Page {currentPage} of {totalPages}</span>
        <button
          disabled={currentPage >= totalPages}
          onClick={() => setPage(currentPage + 1)}
          className="px-3 py-1 text-gray-600 hover:text-gray-900 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Next
        </button>
        <input
          value={gotoPage}
          onChange={(e) => setGotoPage(e.target.value)}
          placeholder="Go to page"
          className="border border-gray-300 rounded px-2 py-1 w-24 text-sm"
        />
        <button
          onClick={() => {
            const n = parseInt(gotoPage, 10);
            if (!isNaN(n) && n >= 1 && n <= totalPages) { setPage(n); setGotoPage(""); }
          }}
          className="px-3 py-1 text-blue-600 hover:text-blue-800 font-medium"
        >
          Go
        </button>
      </div>

      {editRow && (
        <EditPurchaseModal
          purchase={editRow}
          products={products}
          suppliers={suppliers}
          onClose={() => setEditRow(null)}
          onSaved={() => { setEditRow(null); refresh(); }}
        />
      )}
    </div>
  );
}

function EditPurchaseModal({
  purchase, products, suppliers, onClose, onSaved,
}: {
  purchase: Purchase; products: Product[]; suppliers: Supplier[];
  onClose: () => void; onSaved: () => void;
}) {
  const [productId, setProductId] = useState<string>(purchase.product_id || "");
  const [supplierId, setSupplierId] = useState<string>(purchase.supplier_id || "");
  const selectedProduct = products.find((p) => p.id === productId);
  const pcsPerCarton = Number(selectedProduct?.pcs_per_carton || 0) || 1;
  const initialCarton = (Number(purchase.pieces) || 0) / (Number(products.find((p) => p.id === purchase.product_id)?.pcs_per_carton || 0) || 1);
  const [caton, setCaton] = useState<number>(initialCarton);
  const [costPerPiece, setCostPerPiece] = useState<number>(Number(purchase.cost_per_piece) || 0);
  const [purchaseDate, setPurchaseDate] = useState<string>(purchase.purchase_date);
  const [saving, setSaving] = useState(false);

  const pieces = Math.round(caton * pcsPerCarton);
  const newTotal = pieces * costPerPiece;

  const save = async () => {
    setSaving(true);
    try {
      const oldPieces = Number(purchase.pieces) || 0;
      const oldTotal = Number(purchase.total_cost) || 0;
      const diffPieces = pieces - oldPieces;
      const diffTotal = newTotal - oldTotal;

      // Adjust stock on product (handle product change)
      if (purchase.product_id && productId && purchase.product_id !== productId) {
        const oldProd = products.find((p) => p.id === purchase.product_id);
        if (oldProd) {
          await supabase.from("products").update({
            stock_pieces: Math.max(0, Number(oldProd.stock_pieces || 0) - oldPieces),
          }).eq("id", purchase.product_id);
        }
        const newProd = products.find((p) => p.id === productId);
        if (newProd) {
          await supabase.from("products").update({
            stock_pieces: Number(newProd.stock_pieces || 0) + pieces,
          }).eq("id", productId);
        }
      } else if (productId && diffPieces !== 0) {
        const prod = products.find((p) => p.id === productId);
        if (prod) {
          await supabase.from("products").update({
            stock_pieces: Math.max(0, Number(prod.stock_pieces || 0) + diffPieces),
          }).eq("id", productId);
        }
      }

      // Adjust supplier due by diff (assume unpaid portion changes proportionally)
      const m = (() => {
        try { return JSON.parse(localStorage.getItem("tiles_purchase_meta_v1") || "{}"); } catch { return {}; }
      })();
      const paid = Number(m[purchase.id]?.paid || 0);
      const oldUnpaid = Math.max(0, oldTotal - paid);
      const newUnpaid = Math.max(0, newTotal - paid);
      const supDiff = newUnpaid - oldUnpaid;
      if (supplierId === purchase.supplier_id && supDiff !== 0) {
        const sup = suppliers.find((s) => s.id === supplierId);
        if (sup) {
          await supabase.from("suppliers").update({
            total_due: Math.max(0, Number(sup.total_due || 0) + supDiff),
          }).eq("id", supplierId);
        }
      }

      const { error } = await supabase.from("purchases").update({
        product_id: productId || null,
        supplier_id: supplierId || null,
        pieces,
        cost_per_piece: costPerPiece,
        total_cost: newTotal,
        purchase_date: purchaseDate,
      }).eq("id", purchase.id);
      if (error) throw error;

      toast.success("Purchase আপডেট হয়েছে");
      onSaved();
    } catch (e: any) {
      toast.error(e?.message || "Update ব্যর্থ");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg p-6" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-lg font-semibold mb-4">Edit Purchase</h3>
        <div className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Product</label>
            <select value={productId} onChange={(e) => setProductId(e.target.value)} className="w-full border border-gray-300 rounded px-3 py-2 text-sm">
              <option value="">— select —</option>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Supplier</label>
            <select value={supplierId} onChange={(e) => setSupplierId(e.target.value)} className="w-full border border-gray-300 rounded px-3 py-2 text-sm">
              <option value="">— select —</option>
              {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Caton</label>
              <input type="number" step="0.01" value={caton || ""} onChange={(e) => setCaton(parseFloat(e.target.value) || 0)} className="w-full border border-gray-300 rounded px-3 py-2 text-sm" />
              <div className="text-[11px] text-gray-500 mt-1">= {pieces} pcs (×{pcsPerCarton}/caton)</div>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Cost / Piece</label>
              <input type="number" step="0.01" value={costPerPiece || ""} onChange={(e) => setCostPerPiece(parseFloat(e.target.value) || 0)} className="w-full border border-gray-300 rounded px-3 py-2 text-sm" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Date</label>
            <input type="date" value={purchaseDate} onChange={(e) => setPurchaseDate(e.target.value)} className="w-full border border-gray-300 rounded px-3 py-2 text-sm" />
          </div>
          <div className="bg-emerald-50 border border-emerald-200 rounded px-3 py-2 text-sm">
            <span className="text-gray-600">Total: </span>
            <span className="font-semibold text-emerald-700">৳ {newTotal.toFixed(2)}</span>
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <button onClick={onClose} className="px-4 py-2 text-sm border border-gray-300 rounded hover:bg-gray-50">Cancel</button>
          <button onClick={save} disabled={saving} className="px-4 py-2 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50">
            {saving ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
}
