import { useEffect, useRef, useState } from "react";
import { ImagePlus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

const bucket = "stock-images";

export default function StockImageCell({ name, productIds, imagePath, userId, onSaved }: {
  name: string;
  productIds: string[];
  imagePath: string | null;
  userId: string;
  onSaved: () => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [url, setUrl] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setFailed(false);
    if (!imagePath) { setUrl(null); return; }
    const load = async () => {
      const { data, error } = await supabase.storage.from(bucket).createSignedUrl(imagePath, 86400);
      if (cancelled) return;
      if (error) { setFailed(true); return; }
      setUrl(data.signedUrl);
    };
    void load();
    return () => { cancelled = true; };
  }, [imagePath]);

  const upload = async (file: File) => {
    if (!file.type.startsWith("image/") || file.type === "image/svg+xml") {
      toast.error("JPG, PNG বা WebP ছবি বেছে নিন");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error("ছবিটি ১০ MB-এর ছোট হতে হবে");
      return;
    }
    const firstId = productIds[0];
    if (!firstId || !userId) return;
    const extension = file.type === "image/jpeg" ? "jpg" : file.type.split("/")[1].replace(/[^a-z0-9]/gi, "");
    const path = `${userId}/${firstId}/${crypto.randomUUID()}.${extension}`;
    setSaving(true);
    let uploaded = false;
    let attached = false;
    try {
      const result = await supabase.storage.from(bucket).upload(path, file, { contentType: file.type });
      if (result.error) throw result.error;
      uploaded = true;
      const { data, error } = await supabase.from("products").update({ image_path: path }).in("id", productIds).select("id");
      if (error) throw error;
      if (data?.length !== productIds.length) throw new Error("ছবি সেভ হয়নি; আবার চেষ্টা করুন");
      attached = true;
      const signed = await supabase.storage.from(bucket).createSignedUrl(path, 86400);
      if (signed.data) { setUrl(signed.data.signedUrl); setFailed(false); }
      onSaved();
    } catch (error) {
      if (uploaded && !attached) await supabase.storage.from(bucket).remove([path]);
      toast.error(error instanceof Error ? error.message : "ছবি সেভ হয়নি; আবার চেষ্টা করুন");
    } finally {
      setSaving(false);
    }
  };

  return <>
    <input ref={input} type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/avif" className="hidden"
      aria-label={`Choose photo: ${name}`} onChange={(event) => {
        const file = event.target.files?.[0];
        event.target.value = "";
        if (file) void upload(file);
      }} />
    <Button type="button" variant="ghost" disabled={saving} aria-busy={saving}
      aria-label={`${imagePath || url ? "Replace" : "Add"} photo: ${name}`}
      title={imagePath || url ? "ছবি বদলান" : "ছবি যোগ করুন"}
      onClick={() => input.current?.click()}
      className="absolute inset-0 h-full w-full overflow-hidden rounded-none p-0 focus-visible:ring-inset">
      {url && !failed ? <img src={url} alt={name} onError={() => setFailed(true)} className="h-full w-full object-cover" />
        : <ImagePlus className="text-muted-foreground" style={{ width: 20, height: 20 }} />}
    </Button>
  </>;
}
