import { useMemo, useState } from "react";
import jsPDF from "jspdf";
import {
  Calendar, TrendingUp, TrendingDown, AlertTriangle, Download, FileText,
  MessageSquare, BarChart3, Wallet, Tags, Activity, Flame,
} from "lucide-react";

type Cost = { id: string; description: string; amount: number; cost_date: string };
type Meta = { category: string; name?: string; method?: string; note?: string };
const META_KEY = "tiles_expense_meta_v1";

const loadMeta = (): Record<string, Meta> => {
  try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch { return {}; }
};

const today = () => new Date().toISOString().slice(0, 10);
const ymd = (d: Date) => d.toISOString().slice(0, 10);

export default function CostReport({ costs, sales = [] }: { costs: Cost[]; sales?: { total_amount: number; sale_date: string; is_returned: boolean; returned_amount: number }[] }) {
  const meta = useMemo(() => loadMeta(), [costs]);
  const [period, setPeriod] = useState<"today" | "yesterday" | "week" | "month" | "custom">("month");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [budget, setBudget] = useState<number>(() => Number(localStorage.getItem("tiles_expense_budget") || 0));

  const enriched = useMemo(() => costs.map((c) => ({ ...c, meta: meta[c.id] || { category: "অশ্রেণীবদ্ধ" } })), [costs, meta]);

  const inRange = (d: string) => {
    const dt = new Date(d);
    const now = new Date();
    if (period === "today") return d === today();
    if (period === "yesterday") { const y = new Date(); y.setDate(now.getDate() - 1); return d === ymd(y); }
    if (period === "week") { const w = new Date(); w.setDate(now.getDate() - 7); return dt >= w; }
    if (period === "month") return dt.getMonth() === now.getMonth() && dt.getFullYear() === now.getFullYear();
    if (period === "custom") {
      if (fromDate && dt < new Date(fromDate)) return false;
      if (toDate && dt > new Date(toDate)) return false;
      return true;
    }
    return true;
  };

  const filtered = enriched.filter((c) => inRange(c.cost_date));
  const total = filtered.reduce((s, c) => s + Number(c.amount), 0);

  const byDate = useMemo(() => {
    const m: Record<string, typeof filtered> = {};
    filtered.forEach((c) => { (m[c.cost_date] ||= []).push(c); });
    return Object.entries(m).sort((a, b) => b[0].localeCompare(a[0]));
  }, [filtered]);

  const dailyTotals = byDate.map(([d, items]) => ({ date: d, total: items.reduce((s, c) => s + Number(c.amount), 0), count: items.length }));
  const avgDaily = dailyTotals.length ? total / dailyTotals.length : 0;
  const highestDay = dailyTotals.reduce((a, b) => (a && a.total > b.total ? a : b), dailyTotals[0]);
  const lowestDay = dailyTotals.reduce((a, b) => (a && a.total < b.total ? a : b), dailyTotals[0]);
  const maxDay = Math.max(1, ...dailyTotals.map((d) => d.total));

  const byCategory = useMemo(() => {
    const m: Record<string, number> = {};
    filtered.forEach((c) => { m[c.meta.category] = (m[c.meta.category] || 0) + Number(c.amount); });
    return Object.entries(m).sort((a, b) => b[1] - a[1]);
  }, [filtered]);

  const byMethod = useMemo(() => {
    const m: Record<string, number> = { "নগদ": 0, "ব্যাংক": 0, "বিকাশ": 0, "নগদ অ্যাপ": 0, "রকেট": 0, "অন্যান্য": 0 };
    filtered.forEach((c) => { const k = c.meta.method && m[c.meta.method] !== undefined ? c.meta.method : "অন্যান্য"; m[k] += Number(c.amount); });
    return Object.entries(m).filter(([, v]) => v > 0);
  }, [filtered]);

  const monthTotal = costs.filter((c) => { const d = new Date(c.cost_date); const n = new Date(); return d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear(); }).reduce((s, c) => s + Number(c.amount), 0);
  const lastMonthTotal = costs.filter((c) => { const d = new Date(c.cost_date); const n = new Date(); const lm = new Date(n.getFullYear(), n.getMonth() - 1, 1); return d.getMonth() === lm.getMonth() && d.getFullYear() === lm.getFullYear(); }).reduce((s, c) => s + Number(c.amount), 0);
  const weekTotal = costs.filter((c) => { const w = new Date(); w.setDate(w.getDate() - 7); return new Date(c.cost_date) >= w; }).reduce((s, c) => s + Number(c.amount), 0);
  const prevWeekTotal = costs.filter((c) => { const w1 = new Date(); w1.setDate(w1.getDate() - 14); const w2 = new Date(); w2.setDate(w2.getDate() - 7); const dt = new Date(c.cost_date); return dt >= w1 && dt < w2; }).reduce((s, c) => s + Number(c.amount), 0);
  const trend = prevWeekTotal === 0 ? 0 : ((weekTotal - prevWeekTotal) / prevWeekTotal) * 100;
  const monthTrend = lastMonthTotal === 0 ? 0 : ((monthTotal - lastMonthTotal) / lastMonthTotal) * 100;

  const salesInPeriod = sales.filter((s) => inRange(s.sale_date)).reduce((a, s) => a + Number(s.total_amount) - (s.is_returned ? Number(s.returned_amount) : 0), 0);

  const alerts: { type: "danger" | "warn"; msg: string }[] = [];
  if (budget > 0 && monthTotal > budget) alerts.push({ type: "danger", msg: `মাসিক বাজেট অতিক্রম: ৳${monthTotal.toFixed(0)} / ৳${budget.toFixed(0)}` });
  if (highestDay && highestDay.total > avgDaily * 2 && avgDaily > 0) alerts.push({ type: "warn", msg: `অস্বাভাবিক বেশি খরচ ${highestDay.date} তারিখে: ৳${highestDay.total.toFixed(0)} (গড় ৳${avgDaily.toFixed(0)})` });
  if (trend > 25) alerts.push({ type: "warn", msg: `সাপ্তাহিক খরচ গত সপ্তাহের চেয়ে ${trend.toFixed(0)}% বেড়েছে` });
  const topCat = byCategory[0];
  if (topCat && topCat[1] > total * 0.5 && total > 0) alerts.push({ type: "warn", msg: `${topCat[0]} মোট খরচের ${((topCat[1] / total) * 100).toFixed(0)}% দখল করেছে` });

  const setBudgetVal = (v: number) => { setBudget(v); localStorage.setItem("tiles_expense_budget", String(v)); };

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(16); doc.text("Cost Report (Date-wise)", 14, 18);
    doc.setFontSize(10); doc.text(`Period: ${period}  |  Total: BDT ${total.toFixed(2)}  |  Days: ${dailyTotals.length}`, 14, 26);
    let y = 36;
    byDate.forEach(([d, items]) => {
      if (y > 270) { doc.addPage(); y = 20; }
      const dayTotal = items.reduce((s, c) => s + Number(c.amount), 0);
      doc.setFont("helvetica", "bold"); doc.text(`${d}  —  BDT ${dayTotal.toFixed(0)} (${items.length} items)`, 14, y); y += 6;
      doc.setFont("helvetica", "normal");
      items.forEach((it) => {
        if (y > 280) { doc.addPage(); y = 20; }
        doc.text(`  - [${it.meta.category}] ${it.meta.name || ""} - ${it.meta.method || "-"} - BDT ${Number(it.amount).toFixed(0)}`, 14, y); y += 5;
      });
      y += 2;
    });
    doc.save(`cost-report-${Date.now()}.pdf`);
  };

  const exportCSV = () => {
    const rows = [["তারিখ", "ক্যাটাগরি", "নাম", "পেমেন্ট", "পরিমাণ", "বিবরণ"]];
    filtered.forEach((c) => rows.push([c.cost_date, c.meta.category, c.meta.name || "", c.meta.method || "", String(c.amount), c.description]));
    const csv = rows.map((r) => r.map((v) => `"${(v || "").replace(/"/g, '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = `cost-report-${Date.now()}.csv`; a.click();
  };

  const whatsappShare = () => {
    const text = `*খরচ রিপোর্ট (${period})*\nমোট: ৳${total.toFixed(0)}\nদিন: ${dailyTotals.length}\nগড়/দিন: ৳${avgDaily.toFixed(0)}\nসর্বোচ্চ: ${highestDay ? `${highestDay.date} ৳${highestDay.total.toFixed(0)}` : "—"}\nশীর্ষ ক্যাটাগরি: ${topCat ? `${topCat[0]} ৳${topCat[1].toFixed(0)}` : "—"}\nসাপ্তাহিক ট্রেন্ড: ${trend >= 0 ? "+" : ""}${trend.toFixed(0)}%`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <div className="space-y-5">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "মোট খরচ", value: total, icon: Wallet, grad: "from-rose-500 to-orange-500" },
          { label: "গড় / দিন", value: avgDaily, icon: Activity, grad: "from-indigo-500 to-purple-500" },
          { label: "সর্বোচ্চ দিন", value: highestDay?.total || 0, icon: Flame, grad: "from-red-500 to-rose-600", sub: highestDay?.date },
          { label: "সর্বনিম্ন দিন", value: lowestDay?.total || 0, icon: TrendingDown, grad: "from-emerald-500 to-teal-500", sub: lowestDay?.date },
        ].map((k) => (
          <div key={k.label} className={`bg-gradient-to-br ${k.grad} text-white p-4 rounded-2xl shadow-lg`}>
            <div className="flex items-center justify-between mb-2"><k.icon className="w-5 h-5 opacity-80" /><span className="text-xs opacity-80">{k.label}</span></div>
            <div className="text-2xl font-bold">৳{k.value.toFixed(0)}</div>
            {k.sub && <div className="text-xs opacity-80 mt-1">{k.sub}</div>}
          </div>
        ))}
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-2">
          {alerts.map((a, i) => (
            <div key={i} className={`flex items-center gap-2 p-3 rounded-xl text-sm ${a.type === "danger" ? "bg-red-50 text-red-700 border border-red-200" : "bg-amber-50 text-amber-700 border border-amber-200"}`}>
              <AlertTriangle className="w-4 h-4" />{a.msg}
            </div>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40 flex flex-wrap gap-3 items-end">
        <div>
          <label className="text-xs text-gray-600 block">তারিখ পরিসর</label>
          <select value={period} onChange={(e) => setPeriod(e.target.value as typeof period)} className="border p-2 rounded-lg">
            <option value="today">আজ</option><option value="yesterday">গতকাল</option><option value="week">এই সপ্তাহ</option><option value="month">এই মাস</option><option value="custom">কাস্টম</option>
          </select>
        </div>
        {period === "custom" && (
          <>
            <div><label className="text-xs text-gray-600 block">শুরু</label><input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="border p-2 rounded-lg" /></div>
            <div><label className="text-xs text-gray-600 block">শেষ</label><input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="border p-2 rounded-lg" /></div>
          </>
        )}
        <div>
          <label className="text-xs text-gray-600 block">মাসিক বাজেট (৳)</label>
          <input type="number" value={budget || ""} onChange={(e) => setBudgetVal(parseFloat(e.target.value) || 0)} className="border p-2 rounded-lg w-32" />
        </div>
        <div className="flex gap-2 ml-auto no-print">
          <button onClick={exportPDF} className="bg-red-600 text-white px-3 py-2 rounded-lg flex items-center gap-1 text-sm"><FileText className="w-4 h-4" />PDF</button>
          <button onClick={exportCSV} className="bg-emerald-600 text-white px-3 py-2 rounded-lg flex items-center gap-1 text-sm"><Download className="w-4 h-4" />Excel</button>
          <button onClick={whatsappShare} className="bg-green-500 text-white px-3 py-2 rounded-lg flex items-center gap-1 text-sm"><MessageSquare className="w-4 h-4" />শেয়ার</button>
          <button onClick={() => window.print()} className="bg-slate-700 text-white px-3 py-2 rounded-lg text-sm">প্রিন্ট</button>
        </div>
      </div>

      {/* Trend + Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 text-white p-4 rounded-2xl shadow-lg">
          <h3 className="font-bold mb-3 flex items-center gap-2"><TrendingUp className="w-4 h-4" />ট্রেন্ড বিশ্লেষণ</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="opacity-80">এই সপ্তাহ</span><span>৳{weekTotal.toFixed(0)}</span></div>
            <div className="flex justify-between"><span className="opacity-80">গত সপ্তাহ</span><span>৳{prevWeekTotal.toFixed(0)}</span></div>
            <div className="flex justify-between border-t border-white/20 pt-2"><span>সাপ্তাহিক Δ</span><span className={trend >= 0 ? "text-rose-300" : "text-emerald-300"}>{trend >= 0 ? "▲" : "▼"} {Math.abs(trend).toFixed(1)}%</span></div>
            <div className="flex justify-between pt-1"><span className="opacity-80">এই মাস</span><span>৳{monthTotal.toFixed(0)}</span></div>
            <div className="flex justify-between"><span className="opacity-80">গত মাস</span><span>৳{lastMonthTotal.toFixed(0)}</span></div>
            <div className="flex justify-between"><span>মাসিক Δ</span><span className={monthTrend >= 0 ? "text-rose-300" : "text-emerald-300"}>{monthTrend >= 0 ? "▲" : "▼"} {Math.abs(monthTrend).toFixed(1)}%</span></div>
          </div>
        </div>

        <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
          <h3 className="font-bold mb-3 flex items-center gap-2"><Tags className="w-4 h-4 text-purple-600" />ক্যাটাগরি প্রাধান্য</h3>
          <div className="space-y-2 text-sm">
            {byCategory.length === 0 && <p className="text-gray-400">কোনো তথ্য নেই</p>}
            {byCategory.map(([c, v]) => (
              <div key={c}>
                <div className="flex justify-between"><span>{c}</span><span className="font-semibold">৳{v.toFixed(0)}</span></div>
                <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden"><div className="h-full bg-gradient-to-r from-purple-500 to-pink-500" style={{ width: `${total ? (v / total) * 100 : 0}%` }} /></div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
          <h3 className="font-bold mb-3 flex items-center gap-2"><BarChart3 className="w-4 h-4 text-indigo-600" />পেমেন্ট পদ্ধতি বিভাজন</h3>
          <div className="space-y-2 text-sm">
            {byMethod.length === 0 && <p className="text-gray-400">কোনো তথ্য নেই</p>}
            {byMethod.map(([m, v]) => (
              <div key={m} className="flex justify-between border-b py-1"><span>{m}</span><span className="font-semibold">৳{v.toFixed(0)} <span className="text-xs text-gray-500">({total ? ((v / total) * 100).toFixed(0) : 0}%)</span></span></div>
            ))}
            {sales.length > 0 && (
              <div className="mt-3 pt-3 border-t flex justify-between text-xs"><span className="text-gray-500">বিক্রয় vs খরচ</span><span className={salesInPeriod - total >= 0 ? "text-emerald-600 font-semibold" : "text-rose-600 font-semibold"}>৳{(salesInPeriod - total).toFixed(0)}</span></div>
            )}
          </div>
        </div>
      </div>

      {/* Daily Cost Graph */}
      <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
        <h3 className="font-bold mb-3 flex items-center gap-2"><BarChart3 className="w-4 h-4 text-rose-600" />দৈনিক খরচ চার্ট</h3>
        <div className="flex items-end gap-1 h-40 overflow-x-auto">
          {dailyTotals.length === 0 && <p className="text-gray-400 text-sm">এই পরিসরে কোনো তথ্য নেই</p>}
          {dailyTotals.slice().reverse().map((d) => (
            <div key={d.date} className="flex flex-col items-center min-w-[36px]">
              <div className="text-[10px] text-gray-600 mb-1">৳{d.total > 999 ? `${(d.total / 1000).toFixed(1)}k` : d.total.toFixed(0)}</div>
              <div className="w-7 bg-gradient-to-t from-rose-500 to-orange-400 rounded-t" style={{ height: `${(d.total / maxDay) * 100}%` }} title={`${d.date}: ৳${d.total.toFixed(0)}`} />
              <div className="text-[9px] text-gray-500 mt-1 rotate-45 origin-left">{d.date.slice(5)}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Daily Ledger */}
      <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
        <h3 className="font-bold mb-3 flex items-center gap-2"><Calendar className="w-4 h-4 text-indigo-600" />দৈনিক খাতা ({dailyTotals.length} দিন)</h3>
        <div className="space-y-3 max-h-[500px] overflow-y-auto">
          {byDate.length === 0 && <p className="text-gray-400 text-sm text-center py-8">এই পরিসরে কোনো খরচ নেই</p>}
          {byDate.map(([d, items]) => {
            const dayTotal = items.reduce((s, c) => s + Number(c.amount), 0);
            const dayCats: Record<string, number> = {};
            items.forEach((it) => { dayCats[it.meta.category] = (dayCats[it.meta.category] || 0) + Number(it.amount); });
            const topDayCat = Object.entries(dayCats).sort((a, b) => b[1] - a[1])[0];
            return (
              <div key={d} className="border rounded-xl overflow-hidden bg-white">
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-orange-50 to-rose-50 border-b">
                  <div>
                    <div className="font-semibold">{d}</div>
                    <div className="text-xs text-gray-500">{items.length} টি এন্ট্রি • শীর্ষ: {topDayCat ? `${topDayCat[0]} (৳${topDayCat[1].toFixed(0)})` : "—"}</div>
                  </div>
                  <div className="text-rose-600 font-bold text-lg">৳{dayTotal.toFixed(0)}</div>
                </div>
                <table className="w-full text-sm">
                  <tbody>
                    {items.map((it) => (
                      <tr key={it.id} className="border-b last:border-0">
                        <td className="p-2"><span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 text-xs">{it.meta.category}</span></td>
                        <td className="p-2 text-xs">{it.meta.name || "—"}</td>
                        <td className="p-2 text-xs text-gray-500">{it.meta.method || "—"}</td>
                        <td className="p-2 text-xs text-gray-600 truncate max-w-[200px]">{it.meta.note || it.description}</td>
                        <td className="p-2 text-right font-semibold text-rose-600">৳{Number(it.amount).toFixed(0)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
