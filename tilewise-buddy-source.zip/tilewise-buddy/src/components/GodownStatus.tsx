import { useMemo, useState } from "react";

type Product = {
  id: string; name: string; category: string | null; company: string | null; size: string | null;
  sqft_per_piece: number; pcs_per_carton: number; stock_pieces: number;
  purchase_price_per_piece: number; sell_price_per_piece: number;
  min_label_feet?: number;
};
type SaleItem = {
  productId: string; pieces: number; totalPrice: number;
  cartons?: number; feet?: number; rate?: number;
};
type Sale = {
  id: string; invoice_no: string; customer_id: string | null; total_amount: number;
  paid_amount: number; due_amount: number; items: SaleItem[]; is_returned: boolean;
  returned_amount: number; sale_date: string;
};
type Purchase = {
  id: string; product_id: string | null; supplier_id: string | null;
  pieces: number; cost_per_piece: number; total_cost: number; purchase_date: string;
};

const today = () => new Date().toISOString().slice(0, 10);

export default function GodownStatus({
  products, purchases, sales,
}: { products: Product[]; purchases: Purchase[]; sales: Sale[] }) {
  const [date, setDate] = useState<string>(today());

  const productMap = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);

  // Group purchases by product name -> cartons
  const purchaseRows = useMemo(() => {
    const map = new Map<string, number>();
    purchases.forEach((pu) => {
      if (pu.purchase_date !== date) return;
      const p = pu.product_id ? productMap.get(pu.product_id) : null;
      if (!p) return;
      const ctn = (pu.pieces || 0) / (p.pcs_per_carton || 1);
      map.set(p.name, (map.get(p.name) || 0) + ctn);
    });
    return Array.from(map.entries()).map(([name, ctn]) => ({
      name, cartons: Math.round(ctn),
    })).sort((a, b) => b.cartons - a.cartons);
  }, [purchases, productMap, date]);

  // Group sales by product name -> pieces
  const saleRows = useMemo(() => {
    const map = new Map<string, { pieces: number; perCarton: number }>();
    sales.forEach((s) => {
      if (s.is_returned || s.sale_date !== date) return;
      (s.items || []).forEach((it) => {
        const p = productMap.get(it.productId);
        if (!p) return;
        const cur = map.get(p.name) || { pieces: 0, perCarton: p.pcs_per_carton || 1 };
        cur.pieces += Number(it.pieces) || 0;
        map.set(p.name, cur);
      });
    });
    return Array.from(map.entries()).map(([name, v]) => {
      const cartons = Math.floor(v.pieces / v.perCarton);
      const pieces = v.pieces - cartons * v.perCarton;
      return { name, cartons, pieces };
    }).sort((a, b) => (b.cartons * 1000 + b.pieces) - (a.cartons * 1000 + a.pieces));
  }, [sales, productMap, date]);

  // Group returns by product name
  const returnRows = useMemo(() => {
    const map = new Map<string, { pieces: number; perCarton: number }>();
    sales.forEach((s) => {
      if (!s.is_returned || s.sale_date !== date) return;
      const ratio = s.total_amount ? Number(s.returned_amount) / Number(s.total_amount) : 1;
      (s.items || []).forEach((it) => {
        const p = productMap.get(it.productId);
        if (!p) return;
        const rPieces = Math.round((Number(it.pieces) || 0) * ratio);
        const cur = map.get(p.name) || { pieces: 0, perCarton: p.pcs_per_carton || 1 };
        cur.pieces += rPieces;
        map.set(p.name, cur);
      });
    });
    return Array.from(map.entries()).map(([name, v]) => {
      const cartons = Math.floor(v.pieces / v.perCarton);
      const pieces = v.pieces - cartons * v.perCarton;
      return { name, cartons, pieces };
    }).sort((a, b) => (b.cartons * 1000 + b.pieces) - (a.cartons * 1000 + a.pieces));
  }, [sales, productMap, date]);

  const printReport = () => {
    const w = window.open("", "_blank", "width=900,height=700");
    if (!w) return;
    const purchaseTotal = purchaseRows.reduce((s, r) => s + r.cartons, 0);
    const saleTotalCartons = saleRows.reduce((s, r) => s + r.cartons, 0);
    const saleTotalPieces = saleRows.reduce((s, r) => s + r.pieces, 0);
    const returnTotalCartons = returnRows.reduce((s, r) => s + r.cartons, 0);
    const returnTotalPieces = returnRows.reduce((s, r) => s + r.pieces, 0);
    const purchaseTbl = `
      <table><thead><tr><th>Product Name</th><th>Cartons</th></tr></thead>
      <tbody>${purchaseRows.map(r => `<tr><td>${r.name}</td><td style="text-align:center">${r.cartons}</td></tr>`).join("") || `<tr><td colspan="2" style="text-align:center;color:#888">No data</td></tr>`}</tbody>
      ${purchaseRows.length ? `<tfoot><tr style="font-weight:700;background:#dcfce7"><td>মোট</td><td style="text-align:center">${purchaseTotal}</td></tr></tfoot>` : ""}</table>`;
    const saleTbl = `
      <table><thead><tr><th>Product Name</th><th>Cartons</th><th>Pieces</th></tr></thead>
      <tbody>${saleRows.map(r => `<tr><td>${r.name}</td><td style="text-align:center">${r.cartons}</td><td style="text-align:center">${r.pieces}</td></tr>`).join("") || `<tr><td colspan="3" style="text-align:center;color:#888">No data</td></tr>`}</tbody>
      ${saleRows.length ? `<tfoot><tr style="font-weight:700;background:#dbeafe"><td>মোট</td><td style="text-align:center">${saleTotalCartons}</td><td style="text-align:center">${saleTotalPieces}</td></tr></tfoot>` : ""}</table>`;
    const returnTbl = returnRows.length
      ? `<table><thead><tr><th>Product Name</th><th>Cartons</th><th>Pieces</th></tr></thead>
         <tbody>${returnRows.map(r => `<tr><td>${r.name}</td><td style="text-align:center">${r.cartons}</td><td style="text-align:center">${r.pieces}</td></tr>`).join("")}</tbody>
         <tfoot><tr style="font-weight:700;background:#fef3c7"><td>মোট</td><td style="text-align:center">${returnTotalCartons}</td><td style="text-align:center">${returnTotalPieces}</td></tr></tfoot></table>`
      : `<p style="color:#888">No return data.</p>`;

    w.document.write(`<!doctype html><html><head><title>Godown Status ${date}</title>
      <style>
        body{font-family:Arial,sans-serif;padding:20px;color:#222}
        h2{margin:0 0 16px 0}
        .grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px}
        .card{border:1px solid #d1d5db;border-radius:8px;padding:12px}
        .card h3{margin:0 0 8px 0;text-align:center;font-size:14px}
        table{width:100%;border-collapse:collapse;font-size:12px}
        th,td{border:1px solid #d1d5db;padding:6px}
        thead.p th{background:#16a34a;color:#fff}
        thead.s th{background:#3b82f6;color:#fff}
        thead.r th{background:#f59e0b;color:#fff}
      </style></head><body>
      <h2>Godown Status for ${date}</h2>
      <div class="grid">
        <div class="card"><h3>Purchases</h3>${purchaseTbl.replace("<thead>", '<thead class="p">')}</div>
        <div class="card"><h3>Product Sales</h3>${saleTbl.replace("<thead>", '<thead class="s">')}</div>
        <div class="card"><h3>Product Returns</h3>${returnTbl.replace("<thead>", '<thead class="r">')}</div>
      </div>
      <script>window.onload=()=>{window.print();setTimeout(()=>window.close(),300)}</script>
      </body></html>`);
    w.document.close();
  };

  return (
    <div className="max-w-[1400px] mx-auto space-y-4">
      {/* Top bar */}
      <div className="flex flex-wrap items-center gap-4">
        <label className="font-semibold text-gray-800">Select Date:</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="border border-gray-300 rounded px-3 py-1.5 text-sm"
        />
        <span className="text-gray-600 italic">
          Currently showing data for: <span className="text-blue-600 font-medium">{date}</span>
        </span>
        <button
          onClick={printReport}
          className="ml-auto bg-green-600 hover:bg-green-700 text-white px-4 py-1.5 rounded text-sm font-medium shadow"
        >
          Print
        </button>
      </div>

      <h3 className="text-gray-700">Godown Status for {date} (yyyy-mm-dd)</h3>

      {/* Three column cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Purchases */}
        <div className="border border-gray-200 rounded-xl p-3 bg-white">
          <h4 className="text-center font-medium text-gray-700 mb-2">Purchases</h4>
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="bg-green-600 text-white">
                <th className="border border-gray-300 px-3 py-2 text-left">Product Name</th>
                <th className="border border-gray-300 px-3 py-2 text-left">Cartons</th>
              </tr>
            </thead>
            <tbody>
              {purchaseRows.length === 0 && (
                <tr><td colSpan={2} className="border border-gray-300 p-4 text-center text-gray-400">No purchase data.</td></tr>
              )}
              {purchaseRows.map((r) => (
                <tr key={r.name}>
                  <td className="border border-gray-300 px-3 py-2">{r.name}</td>
                  <td className="border border-gray-300 px-3 py-2">{r.cartons}</td>
                </tr>
              ))}
            </tbody>
            {purchaseRows.length > 0 && (
              <tfoot>
                <tr className="bg-green-50 font-semibold">
                  <td className="border border-gray-300 px-3 py-2">মোট</td>
                  <td className="border border-gray-300 px-3 py-2">{purchaseRows.reduce((s, r) => s + r.cartons, 0)}</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Product Sales */}
        <div className="border border-gray-200 rounded-xl p-3 bg-white">
          <h4 className="text-center font-medium text-gray-700 mb-2">Product Sales</h4>
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="bg-blue-500 text-white">
                <th className="border border-gray-300 px-3 py-2 text-left">Product Name</th>
                <th className="border border-gray-300 px-3 py-2 text-left">Cartons</th>
                <th className="border border-gray-300 px-3 py-2 text-left">Pieces</th>
              </tr>
            </thead>
            <tbody>
              {saleRows.length === 0 && (
                <tr><td colSpan={3} className="border border-gray-300 p-4 text-center text-gray-400">No sale data.</td></tr>
              )}
              {saleRows.map((r) => (
                <tr key={r.name}>
                  <td className="border border-gray-300 px-3 py-2">{r.name}</td>
                  <td className="border border-gray-300 px-3 py-2">{r.cartons}</td>
                  <td className="border border-gray-300 px-3 py-2">{r.pieces}</td>
                </tr>
              ))}
            </tbody>
            {saleRows.length > 0 && (
              <tfoot>
                <tr className="bg-blue-50 font-semibold">
                  <td className="border border-gray-300 px-3 py-2">মোট</td>
                  <td className="border border-gray-300 px-3 py-2">{saleRows.reduce((s, r) => s + r.cartons, 0)}</td>
                  <td className="border border-gray-300 px-3 py-2">{saleRows.reduce((s, r) => s + r.pieces, 0)}</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Product Returns */}
        <div className="border border-gray-200 rounded-xl p-3 bg-white">
          <h4 className="text-center font-medium text-gray-700 mb-2">Product Returns</h4>
          {returnRows.length === 0 ? (
            <p className="text-gray-500 px-2 py-3">No return data .</p>
          ) : (
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-amber-500 text-white">
                  <th className="border border-gray-300 px-3 py-2 text-left">Product Name</th>
                  <th className="border border-gray-300 px-3 py-2 text-left">Cartons</th>
                  <th className="border border-gray-300 px-3 py-2 text-left">Pieces</th>
                </tr>
              </thead>
              <tbody>
                {returnRows.map((r) => (
                  <tr key={r.name}>
                    <td className="border border-gray-300 px-3 py-2">{r.name}</td>
                    <td className="border border-gray-300 px-3 py-2">{r.cartons}</td>
                    <td className="border border-gray-300 px-3 py-2">{r.pieces}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-amber-50 font-semibold">
                  <td className="border border-gray-300 px-3 py-2">মোট</td>
                  <td className="border border-gray-300 px-3 py-2">{returnRows.reduce((s, r) => s + r.cartons, 0)}</td>
                  <td className="border border-gray-300 px-3 py-2">{returnRows.reduce((s, r) => s + r.pieces, 0)}</td>
                </tr>
              </tfoot>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
