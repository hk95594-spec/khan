import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import jsPDF from "jspdf";
import {
  Wallet, TrendingDown, Calendar, AlertTriangle, Download, FileText,
  MessageSquare, Search, Plus, Tags, BarChart3, Trash2,
} from "lucide-react";

type Cost = { id: string; description: string; amount: number; cost_date: string };
type Sale = { id: string; total_amount: number; sale_date: string; is_returned: boolean; returned_amount: number };

type Meta = { category: string; name?: string; method?: string; note?: string };
const META_KEY = "tiles_expense_meta_v1";

const PREDEFINED = [
  "দোকান ভাড়া", "লেবার বিল", "আপ্যায়ন", "পরিবহন", "বিদ্যুৎ বিল",
  "মোবাইল / ইন্টারনেট", "মেরামত", "বেতন", "ট্যাক্স / ভ্যাট", "অন্যান্য",
];
const METHODS = ["নগদ", "ব্যাংক", "বিকাশ", "নগদ অ্যাপ", "রকেট"];

const loadMeta = (): Record<string, Meta> => {
  try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch { return {}; }
};
const saveMeta = (m: Record<string, Meta>) => localStorage.setItem(META_KEY, JSON.stringify(m));

export default function ExpenseManager({
  userId, costs, sales, refresh,
}: { userId: string; costs: Cost[]; sales: Sale[]; refresh: () => void }) {
  const [meta, setMeta] = useState<Record<string, Meta>>(loadMeta());
  const [category, setCategory] = useState(PREDEFINED[0]);
  const [customCat, setCustomCat] = useState("");
  const [name, setName] = useState("");
  const [amount, setAmount] = useState<number>(0);
  const [method, setMethod] = useState(METHODS[0]);
  const [note, setNote] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [search, setSearch] = useState("");
  const [period, setPeriod] = useState<"today" | "week" | "month" | "all" | "custom">("month");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [filterCat, setFilterCat] = useState("all");
  const [budget, setBudget] = useState<number>(() => Number(localStorage.getItem("tiles_expense_budget") || 0));

  useEffect(() => { localStorage.setItem("tiles_expense_budget", String(budget)); }, [budget]);

  const customCats = useMemo(() => {
    const s = new Set<string>();
    Object.values(meta).forEach((m) => { if (m.category && !PREDEFINED.includes(m.category)) s.add(m.category); });
    return Array.from(s);
  }, [meta]);
  const allCats = [...PREDEFINED, ...customCats];

  const inRange = (d: string) => {
    const dt = new Date(d);
    const now = new Date();
    if (period === "today") return d === now.toISOString().slice(0, 10);
    if (period === "week") { const w = new Date(); w.setDate(now.getDate() - 7); return dt >= w; }
    if (period === "month") return dt.getMonth() === now.getMonth() && dt.getFullYear() === now.getFullYear();
    if (period === "custom") {
      if (fromDate && dt < new Date(fromDate)) return false;
      if (toDate && dt > new Date(toDate)) return false;
      return true;
    }
    return true;
  };

  const enriched = useMemo(() => costs.map((c) => ({ ...c, meta: meta[c.id] || { category: "অন্যান্য" } })), [costs, meta]);
  const filtered = enriched.filter((c) => inRange(c.cost_date)
    && (filterCat === "all" || c.meta.category === filterCat)
    && (search === "" || c.description.toLowerCase().includes(search.toLowerCase()) || (c.meta.name || "").toLowerCase().includes(search.toLowerCase())));

  const total = filtered.reduce((s, c) => s + Number(c.amount), 0);
  const todayTotal = costs.filter((c) => c.cost_date === new Date().toISOString().slice(0, 10)).reduce((s, c) => s + Number(c.amount), 0);
  const monthTotal = costs.filter((c) => { const d = new Date(c.cost_date); const n = new Date(); return d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear(); }).reduce((s, c) => s + Number(c.amount), 0);
  const weekTotal = costs.filter((c) => { const w = new Date(); w.setDate(w.getDate() - 7); return new Date(c.cost_date) >= w; }).reduce((s, c) => s + Number(c.amount), 0);

  const byCategory = useMemo(() => {
    const map: Record<string, number> = {};
    filtered.forEach((c) => { map[c.meta.category] = (map[c.meta.category] || 0) + Number(c.amount); });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [filtered]);
  const byName = useMemo(() => {
    const map: Record<string, number> = {};
    filtered.forEach((c) => { const n = c.meta.name?.trim(); if (n) map[n] = (map[n] || 0) + Number(c.amount); });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [filtered]);

  const highestCat = byCategory[0];
  const daysInPeriod = period === "today" ? 1 : period === "week" ? 7 : period === "month" ? 30 : Math.max(1, filtered.length ? Math.ceil((Date.now() - new Date(filtered[filtered.length - 1].cost_date).getTime()) / 86400000) : 1);
  const burnRate = total / daysInPeriod;

  const salesInPeriod = sales.filter((s) => inRange(s.sale_date)).reduce((sum, s) => sum + Number(s.total_amount) - (s.is_returned ? Number(s.returned_amount) : 0), 0);
  const netProfit = salesInPeriod - total;

  const alerts: { type: "danger" | "warn"; msg: string }[] = [];
  if (budget > 0 && monthTotal > budget) alerts.push({ type: "danger", msg: `মাসিক বাজেট অতিক্রম: ৳${monthTotal.toFixed(0)} / ৳${budget.toFixed(0)}` });
  if (highestCat && highestCat[1] > total * 0.5 && total > 0) alerts.push({ type: "warn", msg: `${highestCat[0]} মোট খরচের ${((highestCat[1] / total) * 100).toFixed(0)}% — অতিরিক্ত খরচ সতর্কতা` });
  if (todayTotal > 10000) alerts.push({ type: "warn", msg: `আজকের খরচ বেশি: ৳${todayTotal.toFixed(0)}` });
  const rentExists = costs.some((c) => { const m = meta[c.id]; const d = new Date(c.cost_date); const n = new Date(); return m?.category === "দোকান ভাড়া" && d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear(); });
  if (!rentExists && new Date().getDate() > 5) alerts.push({ type: "warn", msg: "এই মাসে দোকান ভাড়া এন্ট্রি হয়নি" });

  const addExpense = async () => {
    const cat = (category === "__custom" ? customCat : category).trim();
    if (!cat) return toast.error("ক্যাটাগরি দিন");
    if (amount <= 0) return toast.error("পরিমাণ দিন");
    const desc = `[${cat}]${name ? ` ${name}` : ""}${note ? ` — ${note}` : ""}`;
    const { data, error } = await supabase.from("costs").insert({
      user_id: userId, description: desc, amount, cost_date: date,
    }).select().single();
    if (error) return toast.error(error.message);
    if (data) {
      const m = loadMeta(); m[data.id] = { category: cat, name, method, note }; saveMeta(m); setMeta(m);
    }
    await supabase.from("cash_transactions").insert({ user_id: userId, type: "out", amount, reason: `খরচ: ${cat}${name ? ` (${name})` : ""}`, trans_date: date });
    toast.success("খরচ সংরক্ষণ হয়েছে");
    setAmount(0); setName(""); setNote(""); setCustomCat("");
    refresh();
  };

  const removeExpense = async (id: string) => {
    if (!confirm("এই খরচটি মুছে ফেলবেন?")) return;
    const { error } = await supabase.from("costs").delete().eq("id", id);
    if (error) return toast.error(error.message);
    const m = loadMeta(); delete m[id]; saveMeta(m); setMeta(m);
    toast.success("মুছে ফেলা হয়েছে"); refresh();
  };

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(16); doc.text("Expense Report", 14, 18);
    doc.setFontSize(10); doc.text(`Period: ${period}  |  Total: BDT ${total.toFixed(2)}`, 14, 26);
    let y = 36;
    doc.text("Date", 14, y); doc.text("Category", 44, y); doc.text("Name", 90, y); doc.text("Method", 130, y); doc.text("Amount", 170, y); y += 6;
    filtered.forEach((c) => {
      if (y > 280) { doc.addPage(); y = 20; }
      doc.text(c.cost_date, 14, y);
      doc.text((c.meta.category || "").slice(0, 20), 44, y);
      doc.text((c.meta.name || "-").slice(0, 18), 90, y);
      doc.text(c.meta.method || "-", 130, y);
      doc.text(Number(c.amount).toFixed(0), 170, y);
      y += 6;
    });
    doc.save(`expenses-${Date.now()}.pdf`);
  };

  const exportCSV = () => {
    const rows = [["তারিখ", "ক্যাটাগরি", "নাম", "পেমেন্ট", "পরিমাণ", "নোট"]];
    filtered.forEach((c) => rows.push([c.cost_date, c.meta.category, c.meta.name || "", c.meta.method || "", String(c.amount), c.meta.note || ""]));
    const csv = rows.map((r) => r.map((v) => `"${(v || "").replace(/"/g, '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = `expenses-${Date.now()}.csv`; a.click();
  };

  const whatsappShare = () => {
    const text = `*খরচ রিপোর্ট*\nসময়কাল: ${period}\nমোট: ৳${total.toFixed(0)}\nআজ: ৳${todayTotal.toFixed(0)}\nএই মাস: ৳${monthTotal.toFixed(0)}\nনিট লাভ: ৳${netProfit.toFixed(0)}\nসর্বোচ্চ: ${highestCat ? `${highestCat[0]} (৳${highestCat[1].toFixed(0)})` : "—"}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <div className="space-y-5">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "আজকের খরচ", value: todayTotal, icon: Calendar, grad: "from-orange-500 to-red-500" },
          { label: "সাপ্তাহিক খরচ", value: weekTotal, icon: TrendingDown, grad: "from-pink-500 to-rose-500" },
          { label: "মাসিক খরচ", value: monthTotal, icon: Wallet, grad: "from-purple-500 to-indigo-500" },
          { label: "নিট লাভ (সময়কাল)", value: netProfit, icon: BarChart3, grad: netProfit >= 0 ? "from-emerald-500 to-teal-500" : "from-red-500 to-rose-600" },
        ].map((k) => (
          <div key={k.label} className={`bg-gradient-to-br ${k.grad} text-white p-4 rounded-2xl shadow-lg backdrop-blur`}>
            <div className="flex items-center justify-between mb-2"><k.icon className="w-5 h-5 opacity-80" /><span className="text-xs opacity-80">{k.label}</span></div>
            <div className="text-2xl font-bold">৳{k.value.toFixed(0)}</div>
          </div>
        ))}
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-2">
          {alerts.map((a, i) => (
            <div key={i} className={`flex items-center gap-2 p-3 rounded-xl text-sm ${a.type === "danger" ? "bg-red-50 text-red-700 border border-red-200" : "bg-amber-50 text-amber-700 border border-amber-200"}`}>
              <AlertTriangle className="w-4 h-4" />{a.msg}
            </div>
          ))}
        </div>
      )}

      {/* Add Form */}
      <div className="bg-white/70 backdrop-blur p-5 rounded-2xl shadow-sm border border-white/40">
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2"><Plus className="w-5 h-5 text-orange-600" />নতুন খরচ যোগ করুন</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <label className="text-xs text-gray-600">ক্যাটাগরি</label>
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="border p-2 w-full rounded-lg">
              {PREDEFINED.map((c) => <option key={c} value={c}>{c}</option>)}
              {customCats.map((c) => <option key={c} value={c}>{c}</option>)}
              <option value="__custom">➕ কাস্টম...</option>
            </select>
            {category === "__custom" && (
              <input placeholder="নতুন ক্যাটাগরির নাম" value={customCat} onChange={(e) => setCustomCat(e.target.value)} className="border p-2 w-full rounded-lg mt-2" />
            )}
          </div>
          <div>
            <label className="text-xs text-gray-600">নাম (লেবার/সাপ্লায়ার/কর্মচারী)</label>
            <input value={name} onChange={(e) => setName(e.target.value)} className="border p-2 w-full rounded-lg" placeholder="ঐচ্ছিক" />
          </div>
          <div>
            <label className="text-xs text-gray-600">পরিমাণ (৳)</label>
            <input type="number" value={amount || ""} onChange={(e) => setAmount(parseFloat(e.target.value) || 0)} className="border p-2 w-full rounded-lg" />
          </div>
          <div>
            <label className="text-xs text-gray-600">পেমেন্ট পদ্ধতি</label>
            <select value={method} onChange={(e) => setMethod(e.target.value)} className="border p-2 w-full rounded-lg">
              {METHODS.map((m) => <option key={m}>{m}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-gray-600">তারিখ</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="border p-2 w-full rounded-lg" />
          </div>
          <div>
            <label className="text-xs text-gray-600">নোট</label>
            <input value={note} onChange={(e) => setNote(e.target.value)} className="border p-2 w-full rounded-lg" placeholder="ঐচ্ছিক বিবরণ" />
          </div>
        </div>
        <button onClick={addExpense} className="mt-4 bg-gradient-to-r from-orange-600 to-rose-600 text-white px-5 py-2 rounded-lg font-medium shadow hover:opacity-90">খরচ সংরক্ষণ করুন</button>
      </div>

      {/* Filters */}
      <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40 flex flex-wrap gap-3 items-end">
        <div>
          <label className="text-xs text-gray-600 block">সময়কাল</label>
          <select value={period} onChange={(e) => setPeriod(e.target.value as typeof period)} className="border p-2 rounded-lg">
            <option value="today">আজ</option><option value="week">সপ্তাহ</option><option value="month">মাস</option><option value="all">সব</option><option value="custom">কাস্টম</option>
          </select>
        </div>
        {period === "custom" && (
          <>
            <div><label className="text-xs text-gray-600 block">শুরু</label><input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="border p-2 rounded-lg" /></div>
            <div><label className="text-xs text-gray-600 block">শেষ</label><input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="border p-2 rounded-lg" /></div>
          </>
        )}
        <div>
          <label className="text-xs text-gray-600 block">ক্যাটাগরি</label>
          <select value={filterCat} onChange={(e) => setFilterCat(e.target.value)} className="border p-2 rounded-lg">
            <option value="all">সব</option>
            {allCats.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="flex-1 min-w-[180px]">
          <label className="text-xs text-gray-600 block">খুঁজুন</label>
          <div className="relative"><Search className="w-4 h-4 absolute left-2 top-3 text-gray-400" /><input value={search} onChange={(e) => setSearch(e.target.value)} className="border p-2 pl-8 w-full rounded-lg" placeholder="বিবরণ/নাম খুঁজুন..." /></div>
        </div>
        <div>
          <label className="text-xs text-gray-600 block">মাসিক বাজেট (৳)</label>
          <input type="number" value={budget || ""} onChange={(e) => setBudget(parseFloat(e.target.value) || 0)} className="border p-2 rounded-lg w-32" />
        </div>
        <div className="flex gap-2">
          <button onClick={exportPDF} className="bg-red-600 text-white px-3 py-2 rounded-lg flex items-center gap-1 text-sm"><FileText className="w-4 h-4" />PDF</button>
          <button onClick={exportCSV} className="bg-emerald-600 text-white px-3 py-2 rounded-lg flex items-center gap-1 text-sm"><Download className="w-4 h-4" />Excel</button>
          <button onClick={whatsappShare} className="bg-green-500 text-white px-3 py-2 rounded-lg flex items-center gap-1 text-sm"><MessageSquare className="w-4 h-4" />শেয়ার</button>
        </div>
      </div>

      {/* Analytics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
          <h3 className="font-bold mb-3 flex items-center gap-2"><Tags className="w-4 h-4 text-purple-600" />ক্যাটাগরি বিভাজন</h3>
          <div className="space-y-2 text-sm">
            {byCategory.length === 0 && <p className="text-gray-400">কোনো তথ্য নেই</p>}
            {byCategory.map(([c, v]) => (
              <div key={c}>
                <div className="flex justify-between"><span>{c}</span><span className="font-semibold">৳{v.toFixed(0)}</span></div>
                <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden"><div className="h-full bg-gradient-to-r from-purple-500 to-pink-500" style={{ width: `${total ? (v / total) * 100 : 0}%` }} /></div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
          <h3 className="font-bold mb-3 flex items-center gap-2"><BarChart3 className="w-4 h-4 text-indigo-600" />নাম অনুযায়ী খরচ</h3>
          <div className="space-y-1 text-sm max-h-56 overflow-y-auto">
            {byName.length === 0 && <p className="text-gray-400">নামভিত্তিক এন্ট্রি নেই</p>}
            {byName.map(([n, v]) => (
              <div key={n} className="flex justify-between border-b py-1"><span>{n}</span><span className="font-semibold text-rose-600">৳{v.toFixed(0)}</span></div>
            ))}
          </div>
        </div>
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 text-white p-4 rounded-2xl shadow-lg">
          <h3 className="font-bold mb-3">ক্যাশ ফ্লো সারাংশ</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="opacity-80">বিক্রয় আয়</span><span>৳{salesInPeriod.toFixed(0)}</span></div>
            <div className="flex justify-between"><span className="opacity-80">খরচ</span><span className="text-rose-300">-৳{total.toFixed(0)}</span></div>
            <div className="flex justify-between border-t border-white/20 pt-2 font-bold"><span>নিট লাভ</span><span className={netProfit >= 0 ? "text-emerald-300" : "text-rose-300"}>৳{netProfit.toFixed(0)}</span></div>
            <div className="flex justify-between text-xs opacity-70 pt-2"><span>দৈনিক বার্ন রেট</span><span>৳{burnRate.toFixed(0)}/দিন</span></div>
            <div className="flex justify-between text-xs opacity-70"><span>শীর্ষ ক্যাটাগরি</span><span>{highestCat ? highestCat[0] : "—"}</span></div>
          </div>
        </div>
      </div>

      {/* Ledger */}
      <div className="bg-white/70 backdrop-blur p-4 rounded-2xl shadow-sm border border-white/40">
        <h3 className="font-bold mb-3">খরচের খাতা ({filtered.length})</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50"><tr className="text-left">
              <th className="p-2">তারিখ</th><th className="p-2">ক্যাটাগরি</th><th className="p-2">নাম</th><th className="p-2">পেমেন্ট</th><th className="p-2">নোট</th><th className="p-2 text-right">পরিমাণ</th><th className="p-2"></th>
            </tr></thead>
            <tbody>
              {filtered.length === 0 && <tr><td colSpan={7} className="p-6 text-center text-gray-400">কোনো খরচ পাওয়া যায়নি</td></tr>}
              {filtered.map((c) => (
                <tr key={c.id} className="border-b hover:bg-orange-50/50">
                  <td className="p-2">{c.cost_date}</td>
                  <td className="p-2"><span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 text-xs font-medium">{c.meta.category}</span></td>
                  <td className="p-2">{c.meta.name || "—"}</td>
                  <td className="p-2 text-xs">{c.meta.method || "—"}</td>
                  <td className="p-2 text-xs text-gray-600">{c.meta.note || "—"}</td>
                  <td className="p-2 text-right font-semibold text-rose-600">৳{Number(c.amount).toFixed(0)}</td>
                  <td className="p-2"><button onClick={() => removeExpense(c.id)} className="text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button></td>
                </tr>
              ))}
            </tbody>
            {filtered.length > 0 && <tfoot><tr className="font-bold bg-gray-50"><td colSpan={5} className="p-2 text-right">মোট</td><td className="p-2 text-right text-rose-700">৳{total.toFixed(0)}</td><td></td></tr></tfoot>}
          </table>
        </div>
      </div>
    </div>
  );
}
