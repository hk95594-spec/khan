import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Printer, X, Pencil, Trash2 } from "lucide-react";
import SalesReturnForm from "@/components/SalesReturnForm";
import { INVOICE_CSS, INVOICE_LOGO_SVG } from "@/lib/invoice-style";
import { buildInvoiceHtml } from "@/components/SaleHistory";
import { buildReturnHtml } from "@/components/ReturnHistory";

const toBnDigits = (s: string | number) => String(s).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
function numToBnWords(num: number): string {
  num = Math.round(num);
  if (num === 0) return "শূন্য";
  const ones = ["", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়", "দশ", "এগারো", "বারো", "তেরো", "চৌদ্দ", "পনেরো", "ষোলো", "সতেরো", "আঠারো", "ঊনিশ", "বিশ", "একুশ", "বাইশ", "তেইশ", "চব্বিশ", "পঁচিশ", "ছাব্বিশ", "সাতাশ", "আঠাশ", "ঊনত্রিশ", "ত্রিশ", "একত্রিশ", "বত্রিশ", "তেত্রিশ", "চৌত্রিশ", "পঁইত্রিশ", "ছত্রিশ", "সাঁইত্রিশ", "আটত্রিশ", "ঊনচল্লিশ", "চল্লিশ", "একচল্লিশ", "বিয়াল্লিশ", "তেতাল্লিশ", "চুয়াল্লিশ", "পঁইতাল্লিশ", "ছিচল্লিশ", "সাতচল্লিশ", "আটচল্লিশ", "ঊনপঞ্চাশ", "পঞ্চাশ", "একান্ন", "বায়ান্ন", "তিপ্পান্ন", "চুয়ান্ন", "পঞ্চান্ন", "ছাপ্পান্ন", "সাতান্ন", "আটান্ন", "ঊনষাট", "ষাট", "একষট্টি", "বাষট্টি", "তেষট্টি", "চৌষট্টি", "পঁইষট্টি", "ছিষট্টি", "সাতষট্টি", "আটষট্টি", "ঊনসত্তর", "সত্তর", "একাত্তর", "বাহাত্তর", "তিয়াত্তর", "চুয়াত্তর", "পঁচাত্তর", "ছিয়াত্তর", "সাতাত্তর", "আটাত্তর", "ঊনআশি", "আশি", "একাশি", "বিরাশি", "তিরাশি", "চুরাশি", "পঁচাশি", "ছিয়াশি", "সাতাশি", "আটাশি", "ঊননব্বই", "নব্বই", "একানব্বই", "বিরানব্বই", "তিরানব্বই", "চুরানব্বই", "পঁচানব্বই", "ছিয়ানব্বই", "সাতানব্বই", "আটানব্বই", "নিরানব্বই"];
  const below1000 = (n: number): string => {
    if (n < 100) return ones[n];
    const h = Math.floor(n / 100), r = n % 100;
    return ones[h] + "শ" + (r ? " " + ones[r] : "");
  };
  const parts: string[] = [];
  const crore = Math.floor(num / 10000000); num %= 10000000;
  const lakh = Math.floor(num / 100000); num %= 100000;
  const thousand = Math.floor(num / 1000); num %= 1000;
  if (crore) parts.push(below1000(crore) + " কোটি");
  if (lakh) parts.push(below1000(lakh) + " লক্ষ");
  if (thousand) parts.push(below1000(thousand) + " হাজার");
  if (num) parts.push(below1000(num));
  return parts.join(" ");
}

export function printPaymentReceipt(opts: {
  customerName: string; mobile: string; address: string;
  memoNo: string | number; previousDue: number; paid: number; remainingDue: number;
  kind?: "payment" | "writeoff";
}) {
  const { customerName, mobile, address, memoNo, previousDue, paid, remainingDue } = opts;
  const kind = opts.kind ?? "payment";
  const title = kind === "writeoff" ? "রাইট অফ মেমো" : "বাকি পরিশোধ মেমো";
  const paidLbl = kind === "writeoff" ? "রাইট অফ" : "জমা";
  const dateStr = new Date().toLocaleDateString("en-GB");
  const w = window.open("", "_blank", "width=900,height=700");
  if (!w) return;
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
    <style>${INVOICE_CSS}
      .pay-summary td { border:1px solid #000; padding:6px 8px; font-size:15px; }
      .pay-summary .lbl { font-weight:700; width:38mm; background:#f2f2f2; }
      .pay-summary .val { text-align:right; font-weight:700; }
    </style></head><body>
    <div class="wrap">
      <div class="top">
        <div class="logo">${INVOICE_LOGO_SVG}</div>
        <div class="center">
          <div class="bil">${title}</div>
          <div class="name">আলম টাইলস</div>
          <div class="en">ALAM TILES</div>
        </div>
        <div class="right">
          <div class="mob"><b>মোবাইলঃ</b></div>
          <div class="mob">হাসানঃ ০১৭৫-৭৭৭০৭৯৬</div>
          <div class="mob">০১৬২-১১৭৬৭৮৪</div>
          <div class="addr">বড় কালি বাড়ি রোড,</div>
          <div class="addr">টাংগাইল।</div>
        </div>
      </div>
      <div class="tag">সকল প্রকার টাইলস, মার্বেল পাথর, সিনারী, বর্ডার সামগ্রী পাইকারী ও খুচরা বিক্রেতা<br/>এবং সরবরাহকারক। ডিলার: কুংফু সিরামিক্স, তুষার সিরামিক্স।</div>
      <table class="meta">
        <tr>
          <td class="lbl">নামঃ</td><td class="cust-name">${customerName}</td>
          <td class="date-lbl">তারিখঃ</td><td class="date-val">${toBnDigits(dateStr)}</td>
        </tr>
        <tr><td class="lbl">মোবাইলঃ</td><td colspan="3">${toBnDigits(mobile || "")}</td></tr>
        <tr><td class="lbl">ঠিকানাঃ</td><td colspan="3">${address || ""}</td></tr>
      </table>
      <div class="billno">${title} নং ${toBnDigits(memoNo)}</div>
      <table class="pay-summary" style="margin-top:4mm;">
        <tr><td class="lbl">পূর্বের বাকি</td><td class="val">${toBnDigits(previousDue.toFixed(0))}</td></tr>
        <tr><td class="lbl">${paidLbl}</td><td class="val">${toBnDigits(paid.toFixed(0))}</td></tr>
        <tr><td class="lbl">বর্তমান বাকি</td><td class="val">${toBnDigits(remainingDue.toFixed(0))}</td></tr>
      </table>
      <div class="katha" style="margin-top:3mm; border:1px solid #000; padding:5px;"><b>কথায়:</b> ${numToBnWords(paid)} টাকা মাত্র</div>
      <div class="foot-note" style="margin-top:4mm;">সরবরাহের পর কোন প্রকার অভিযোগ গ্রহণযোগ্য নয়</div>
      <div class="sign">
        <div>গ্রাহকের স্বাক্ষর</div>
        <div style="text-align:right;"><div class="hasan">Hasan</div><div>পক্ষে আলম টাইলস</div></div>
      </div>
    </div>
    <script>window.onload=()=>{setTimeout(()=>window.print(),300)}</script>
    </body></html>`);
  w.document.close();
}


type Product = {
  id: string; name: string; size: string | null; company: string | null; category: string | null;
  sqft_per_piece: number; pcs_per_carton: number; stock_pieces: number;
  purchase_price_per_piece: number; sell_price_per_piece: number;
};
type Customer = { id: string; name: string; mobile: string | null; address: string | null; due_amount: number; created_at?: string };
type Sale = {
  id: string; invoice_no: string; customer_id: string | null; total_amount: number;
  paid_amount: number; due_amount: number; sale_date: string; is_returned: boolean; returned_amount: number;
  items?: any;
};

type ModalKind = "sales" | "return" | "due" | "payment" | "writeoff" | "payhistory" | null;
type DuePayment = { id: string; customer_id: string; memo_no: string; previous_due: number; paid_amount: number; remaining_due: number; kind: string; reason: string | null; created_at: string };

export default function CustomerReport({
  userId, customers, sales, products, refresh, showDueOnly: propShowDueOnly, onEditSale,
}: { userId: string; customers: Customer[]; sales: Sale[]; products: Product[]; refresh: () => void; showDueOnly?: boolean; onEditSale?: (id: string) => void }) {
  const [returnFor, setReturnFor] = useState<Customer | null>(null);
  const [fId, setFId] = useState("");
  const [fName, setFName] = useState("");
  const [fAddr, setFAddr] = useState("");
  const [fMobile, setFMobile] = useState("");
  const [pageSize, setPageSize] = useState(50);
  const [page, setPage] = useState(1);
  const [showDueOnly, setShowDueOnly] = useState(propShowDueOnly ?? false);
  const [modal, setModal] = useState<{ kind: ModalKind; cust: Customer | null }>({ kind: null, cust: null });

  // Build CustomerId like CUST000XXX based on created_at order
  const codeMap = useMemo(() => {
    const sorted = [...customers].sort((a, b) => (a.created_at || "").localeCompare(b.created_at || ""));
    const m = new Map<string, string>();
    sorted.forEach((c, i) => m.set(c.id, `CUST${String(i + 1).padStart(6, "0")}`));
    return m;
  }, [customers]);

  const filtered = useMemo(() => {
    const id = fId.trim().toLowerCase();
    const nm = fName.trim().toLowerCase();
    const ad = fAddr.trim().toLowerCase();
    const mb = fMobile.trim().toLowerCase();
    return customers.filter((c) => {
      if (showDueOnly && Number(c.due_amount) <= 0) return false;
      const code = (codeMap.get(c.id) || "").toLowerCase();
      if (id && !code.includes(id)) return false;
      if (nm && !(c.name || "").toLowerCase().includes(nm)) return false;
      if (ad && !(c.address || "").toLowerCase().includes(ad)) return false;
      if (mb && !(c.mobile || "").toLowerCase().includes(mb)) return false;
      return true;
    });
  }, [customers, codeMap, fId, fName, fAddr, fMobile, showDueOnly]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const pageData = filtered.slice((page - 1) * pageSize, page * pageSize);

  const clearFilters = () => { setFId(""); setFName(""); setFAddr(""); setFMobile(""); setPage(1); };

  const salesOf = (cid: string) => sales.filter((s) => s.customer_id === cid);

  // ---- Customer Due Print (whole list) ----
  const printDueList = () => {
    const dueList = filtered.filter((c) => Number(c.due_amount) > 0);
    const totalDue = dueList.reduce((s, c) => s + Number(c.due_amount), 0);
    const rows = dueList.map((c, i) => `
      <tr>
        <td>${i + 1}</td>
        <td>${codeMap.get(c.id) || ""}</td>
        <td>${c.name || ""}</td>
        <td>${c.mobile || ""}</td>
        <td>${c.address || ""}</td>
        <td style="text-align:right">৳${Number(c.due_amount).toFixed(0)}</td>
      </tr>`).join("");
    const w = window.open("", "_blank", "width=900,height=700");
    if (!w) return;
    w.document.write(`<html><head><title>Customer Due List</title>
      <style>
        body{font-family:Arial;padding:18px;font-size:13px}
        h2{text-align:center;margin:0 0 12px}
        table{width:100%;border-collapse:collapse}
        th,td{border:1px solid #333;padding:6px 8px}
        th{background:#1e3a5f;color:#fff;text-align:left}
        tfoot td{font-weight:bold;background:#f1f5f9}
      </style></head><body>
      <h2>Customer Due List</h2>
      <table>
        <thead><tr><th>SL</th><th>Customer ID</th><th>Name</th><th>Mobile</th><th>Address</th><th style="text-align:right">Due</th></tr></thead>
        <tbody>${rows}</tbody>
        <tfoot><tr><td colspan="5" style="text-align:right">Total Due:</td><td style="text-align:right">৳${totalDue.toFixed(0)}</td></tr></tfoot>
      </table>
      <script>window.onload=()=>{window.print();}</script>
    </body></html>`);
    w.document.close();
  };

  return (
    <div className="space-y-4 print:p-0">
      <h2 className="text-center text-2xl font-bold print:hidden">Alam Tiles — Customer Report</h2>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2 print:hidden">
        <input value={fId} onChange={(e) => { setFId(e.target.value); setPage(1); }} placeholder="Search by CustomerId" className="border rounded px-3 py-2 text-sm flex-1 min-w-[150px]" />
        <input value={fName} onChange={(e) => { setFName(e.target.value); setPage(1); }} placeholder="Search by Name" className="border rounded px-3 py-2 text-sm flex-1 min-w-[150px]" />
        <input value={fAddr} onChange={(e) => { setFAddr(e.target.value); setPage(1); }} placeholder="Search by Address" className="border rounded px-3 py-2 text-sm flex-1 min-w-[150px]" />
        <input value={fMobile} onChange={(e) => { setFMobile(e.target.value); setPage(1); }} placeholder="Search by Mobile" className="border rounded px-3 py-2 text-sm flex-1 min-w-[150px]" />
        <label className="flex items-center gap-2 text-sm whitespace-nowrap cursor-pointer select-none">
          <input type="checkbox" checked={showDueOnly} onChange={(e) => { setShowDueOnly(e.target.checked); setPage(1); }} className="w-4 h-4" />
          শুধু বকেয়া কাস্টমার
        </label>
        <button onClick={clearFilters} className="px-4 py-2 bg-red-600 text-white rounded text-sm">Clear Filters</button>
      </div>

      <div className="flex items-center justify-between print:hidden">
        <button onClick={printDueList} className="text-blue-600 underline text-sm">Customer Due Print</button>
        <div className="flex items-center gap-2 text-sm">
          <span>Items Per Page:</span>
          <select value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }} className="border rounded px-2 py-1">
            {[20, 50, 100, 200].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto border border-slate-300 rounded">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-slate-100 text-slate-700">
              <th className="border border-slate-300 px-2 py-2 text-left">CUSTOMERID</th>
              <th className="border border-slate-300 px-2 py-2 text-left">NAME</th>
              <th className="border border-slate-300 px-2 py-2 text-left">ADDRESS</th>
              <th className="border border-slate-300 px-2 py-2 text-left">MOBILE</th>
              <th className="border border-slate-300 px-2 py-2 text-right">CURRENT DUE</th>
              <th className="border border-slate-300 px-2 py-2 text-center">SALES RECORD</th>
              <th className="border border-slate-300 px-2 py-2 text-center">RETURN HISTORY</th>
              <th className="border border-slate-300 px-2 py-2 text-center">DUE HISTORY</th>
              <th className="border border-slate-300 px-2 py-2 text-center">DUE PAYMENT</th>
              <th className="border border-slate-300 px-2 py-2 text-center">DUE PAYMENT HISTORY</th>
              <th className="border border-slate-300 px-2 py-2 text-center print:hidden">WRITE OFF</th>
            </tr>
          </thead>
          <tbody>
            {pageData.map((c) => (
              <tr key={c.id} className="hover:bg-blue-50/40">
                <td className="border border-slate-300 px-2 py-2 font-mono text-xs">{codeMap.get(c.id)}</td>
                <td className="border border-slate-300 px-2 py-2">{c.name}</td>
                <td className="border border-slate-300 px-2 py-2">{c.address || "—"}</td>
                <td className="border border-slate-300 px-2 py-2">{c.mobile || "—"}</td>
                <td className="border border-slate-300 px-2 py-2 text-right font-bold text-lg text-rose-600">{Number(c.due_amount).toFixed(0)}</td>
                <td className="border border-slate-300 px-1 py-1 text-center"><ActBtn label="Sales History" color="green" onClick={() => setModal({ kind: "sales", cust: c })} /></td>
                <td className="border border-slate-300 px-1 py-1 text-center"><ActBtn label="Return History" color="red" onClick={() => setModal({ kind: "return", cust: c })} /></td>
                <td className="border border-slate-300 px-1 py-1 text-center"><ActBtn label="Due History" color="purple" onClick={() => setModal({ kind: "due", cust: c })} /></td>
                <td className="border border-slate-300 px-1 py-1 text-center"><ActBtn label="Due Payment" color="teal" onClick={() => setModal({ kind: "payment", cust: c })} /></td>
                <td className="border border-slate-300 px-1 py-1 text-center"><ActBtn label="Payment History" color="blue" onClick={() => setModal({ kind: "payhistory", cust: c })} /></td>
                <td className="border border-slate-300 px-1 py-1 text-center print:hidden"><ActBtn label="Write Off" color="slate" onClick={() => setModal({ kind: "writeoff", cust: c })} /></td>
              </tr>
            ))}
            {pageData.length === 0 && (
              <tr><td colSpan={11} className="text-center py-6 text-gray-500">No customers</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex flex-wrap items-center justify-center gap-2 text-sm print:hidden">
        {Array.from({ length: totalPages }, (_, i) => i + 1).map((n) => (
          <button
            key={n}
            onClick={() => setPage(n)}
            className={`min-w-[36px] h-9 px-2 rounded border text-sm ${
              n === page
                ? "bg-blue-500 text-white border-blue-500"
                : "bg-white text-slate-700 border-slate-300 hover:bg-slate-50"
            }`}
          >
            {n}
          </button>
        ))}
        <div className="flex items-center gap-2 ml-3 text-slate-600">
          <span>Go to page:</span>
          <input
            type="number"
            min={1}
            max={totalPages}
            placeholder="Page no"
            className="border rounded px-2 py-1 w-24 text-sm"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                const v = Number((e.target as HTMLInputElement).value);
                if (v >= 1 && v <= totalPages) setPage(v);
              }
            }}
          />
        </div>
      </div>

      {modal.cust && modal.kind && (
        <DetailModal
          kind={modal.kind}
          customer={modal.cust}
          code={codeMap.get(modal.cust.id) || ""}
          sales={salesOf(modal.cust.id)}
          products={products}
          customers={customers}
          userId={userId}
          onClose={() => setModal({ kind: null, cust: null })}
          refresh={refresh}
          onOpenReturn={(c) => { setReturnFor(c); setModal({ kind: null, cust: null }); }}
          onEditSale={onEditSale}
        />
      )}

      {returnFor && (
        <SalesReturnForm
          customer={returnFor}
          code={codeMap.get(returnFor.id) || ""}
          products={products}
          userId={userId}
          onClose={() => setReturnFor(null)}
          refresh={refresh}
        />
      )}
    </div>
  );
}

function ActBtn({ label, color = "blue", onClick }: { label: string; color?: "blue" | "green" | "red" | "purple" | "teal" | "slate"; onClick: () => void }) {
  const colors: Record<string, string> = {
    blue: "bg-blue-300 hover:bg-blue-400 text-blue-900",
    green: "bg-green-300 hover:bg-green-400 text-green-900",
    red: "bg-red-300 hover:bg-red-400 text-red-900",
    purple: "bg-purple-300 hover:bg-purple-400 text-purple-900",
    teal: "bg-teal-200 hover:bg-teal-300 text-teal-900",
    slate: "bg-slate-300 hover:bg-slate-400 text-slate-900",
  };
  return (
    <button onClick={onClick} className={`${colors[color]} text-xs font-medium rounded px-3 py-2 leading-tight w-full`}>
      {label}
    </button>
  );
}

function DetailModal({
  kind, customer, code, sales, products, customers, userId, onClose, refresh, onOpenReturn, onEditSale,
}: {
  kind: Exclude<ModalKind, null>;
  customer: Customer;
  code: string;
  sales: Sale[];
  products: Product[];
  customers: Customer[];
  userId: string;
  onClose: () => void;
  refresh: () => void;
  onOpenReturn: (c: Customer) => void;
  onEditSale?: (id: string) => void;
}) {
  const [collect, setCollect] = useState<number>(0);
  const [wOff, setWOff] = useState<number>(Number(customer.due_amount));
  const [wReason, setWReason] = useState("");
  const [payments, setPayments] = useState<DuePayment[]>([]);
  const [editPay, setEditPay] = useState<DuePayment | null>(null);
  const [editAmt, setEditAmt] = useState<number>(0);
  const [editReason, setEditReason] = useState("");
  const [savingPay, setSavingPay] = useState(false);

  const loadPayments = async () => {
    const { data } = await supabase
      .from("due_payments")
      .select("*")
      .eq("customer_id", customer.id)
      .order("created_at", { ascending: false });
    setPayments((data as any) || []);
  };

  useEffect(() => {
    if (kind !== "payhistory") return;
    loadPayments();
  }, [kind, customer.id]);

  const deletePayment = async (p: DuePayment) => {
    if (!confirm(`Delete memo ${p.memo_no}? Customer due will be restored by ${Number(p.paid_amount).toFixed(0)}.`)) return;
    const { error } = await supabase.from("due_payments").delete().eq("id", p.id);
    if (error) return toast.error(error.message);
    const newDue = (Number(customer.due_amount) || 0) + Number(p.paid_amount || 0);
    await supabase.from("customers").update({ due_amount: newDue }).eq("id", customer.id);
    toast.success("Record deleted");
    await loadPayments();
    refresh();
  };

  const savePaymentEdit = async () => {
    if (!editPay) return;
    const amt = Number(editAmt) || 0;
    if (amt <= 0) return toast.error("Amount must be > 0");
    setSavingPay(true);
    const delta = amt - Number(editPay.paid_amount || 0);
    const newRemaining = Math.max(0, Number(editPay.previous_due || 0) - amt);
    const { error } = await supabase.from("due_payments")
      .update({ paid_amount: amt, remaining_due: newRemaining, reason: editReason || null })
      .eq("id", editPay.id);
    if (error) { setSavingPay(false); return toast.error(error.message); }
    const newDue = Math.max(0, (Number(customer.due_amount) || 0) - delta);
    await supabase.from("customers").update({ due_amount: newDue }).eq("id", customer.id);
    setSavingPay(false);
    setEditPay(null);
    toast.success("Record updated");
    await loadPayments();
    refresh();
  };


  // History list filtering / paging
  const [dateMode, setDateMode] = useState<"all" | "today" | "custom" | "range">("all");
  const [singleDate, setSingleDate] = useState<string>("");
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");
  const [pageSize, setPageSize] = useState(20);
  const [page, setPage] = useState(1);
  const [jumpTo, setJumpTo] = useState<string>("1");
  const [editSale, setEditSale] = useState<Sale | null>(null);
  const [detailSale, setDetailSale] = useState<Sale | null>(null);

  const titleMap: Record<string, string> = {
    sales: "Sales History",
    return: "Return History",
    due: "Due Payment History / Invoice History",
    payment: "Due Payment",
    payhistory: "Due Payment History",
    writeoff: "Write Off",
  };

  const baseRows = useMemo(() => {
    if (kind === "return") return sales.filter((s) => s.is_returned || Number(s.returned_amount) > 0);
    if (kind === "due") return sales.filter((s) => Number(s.due_amount) > 0);
    return sales;
  }, [kind, sales]);

  const rows = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return baseRows.filter((s) => {
      const d = (s.sale_date || "").slice(0, 10);
      if (dateMode === "today") return d === today;
      if (dateMode === "custom" && singleDate) return d === singleDate;
      if (dateMode === "range") {
        if (fromDate && d < fromDate) return false;
        if (toDate && d > toDate) return false;
      }
      return true;
    });
  }, [baseRows, dateMode, singleDate, fromDate, toDate]);

  const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
  const pageRows = rows.slice((page - 1) * pageSize, page * pageSize);

  const clearFilters = () => { setDateMode("all"); setSingleDate(""); setFromDate(""); setToDate(""); setPage(1); };

  const fmtDate = (s: string) => {
    if (!s) return "";
    const d = new Date(s);
    if (isNaN(d.getTime())) return s;
    return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }).replace(/ /g, "-");
  };

  const handleCollect = async () => {
    if (collect <= 0) return toast.error("Amount must be > 0");
    const prevDue = Number(customer.due_amount) || 0;
    const newDue = Math.max(0, prevDue - collect);
    const memoNo = Date.now().toString().slice(-6);
    const { error } = await supabase.from("customers").update({ due_amount: newDue }).eq("id", customer.id);
    if (error) return toast.error(error.message);
    await supabase.from("cash_transactions").insert({
      user_id: userId, type: "in", amount: collect, reason: `Due collection — ${customer.name}`,
    });
    await supabase.from("due_payments").insert({
      user_id: userId, customer_id: customer.id, memo_no: memoNo,
      previous_due: prevDue, paid_amount: collect, remaining_due: newDue, kind: "payment",
    });
    toast.success(`৳${collect} collected`);
    printPaymentReceipt({
      customerName: customer.name || "", mobile: customer.mobile || "", address: customer.address || "",
      memoNo, previousDue: prevDue, paid: collect, remainingDue: newDue, kind: "payment",
    });
    refresh(); onClose();
  };

  const handleWriteOff = async () => {
    if (wOff <= 0) return toast.error("Amount must be > 0");
    const prevDue = Number(customer.due_amount) || 0;
    const newDue = Math.max(0, prevDue - wOff);
    const memoNo = Date.now().toString().slice(-6);
    const { error } = await supabase.from("customers").update({ due_amount: newDue }).eq("id", customer.id);
    if (error) return toast.error(error.message);
    await supabase.from("costs").insert({
      user_id: userId, amount: wOff, description: `Write off — ${customer.name}${wReason ? " — " + wReason : ""}`,
    });
    await supabase.from("due_payments").insert({
      user_id: userId, customer_id: customer.id, memo_no: memoNo,
      previous_due: prevDue, paid_amount: wOff, remaining_due: newDue, kind: "writeoff", reason: wReason || null,
    });
    toast.success("Write off saved");
    printPaymentReceipt({
      customerName: customer.name || "", mobile: customer.mobile || "", address: customer.address || "",
      memoNo, previousDue: prevDue, paid: wOff, remainingDue: newDue, kind: "writeoff",
    });
    refresh(); onClose();
  };


  const productMap = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);
  const customerMap = useMemo(() => new Map(customers.map((c) => [c.id, c])), [customers]);

  const buildBillHtml = (s: Sale, preview = false) => {
    const c = s.customer_id ? customerMap.get(s.customer_id) : undefined;
    if (s.is_returned || String(s.invoice_no || "").startsWith("RET-")) {
      return buildReturnHtml(s as any, c as any, productMap as any, { preview });
    }
    return buildInvoiceHtml(s as any, c as any, productMap as any, { preview });
  };

  const printInvoice = (s: Sale) => {
    const w = window.open("", "_blank", "width=900,height=700");
    if (!w) return;
    w.document.open();
    w.document.write(buildBillHtml(s, false));
    w.document.close();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-7xl max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-3 border-b bg-slate-800 text-white rounded-t-xl">
          <div>
            <h3 className="font-bold text-lg">{detailSale ? `Invoice Number: ${detailSale.invoice_no} Details` : titleMap[kind]}</h3>
            <p className="text-xs opacity-80">{customer.name} — {code}</p>
          </div>
          <div className="flex gap-2">
            {detailSale && (
              <button onClick={() => setDetailSale(null)} className="px-3 py-1.5 bg-white/20 hover:bg-white/30 rounded text-sm">← Back</button>
            )}
            <button onClick={onClose} className="p-1 hover:bg-white/20 rounded"><X className="w-5 h-5" /></button>
          </div>
        </div>

        <div className="p-4">
          {/* LIST VIEW for sales/return/due */}
          {(kind === "sales" || kind === "return" || kind === "due") && !detailSale && (
            <>
              <div className="border border-slate-200 rounded p-3 mb-3 space-y-3 bg-slate-50/40">
                <div className="flex flex-wrap items-center gap-2">
                  {(["all", "today", "custom", "range"] as const).map((m) => (
                    <button key={m} onClick={() => { setDateMode(m); setPage(1); }}
                      className={`px-4 py-1.5 rounded text-sm font-medium ${dateMode === m ? "bg-blue-600 text-white" : "text-slate-700 hover:bg-slate-200"}`}>
                      {m === "all" ? "All" : m === "today" ? "Today" : m === "custom" ? "Custom Date" : "Date Range"}
                    </button>
                  ))}
                  {dateMode === "custom" && (
                    <input type="date" value={singleDate} onChange={(e) => { setSingleDate(e.target.value); setPage(1); }} className="border rounded px-2 py-1 text-sm" />
                  )}
                  {dateMode === "range" && (
                    <>
                      <input type="date" value={fromDate} onChange={(e) => { setFromDate(e.target.value); setPage(1); }} className="border rounded px-2 py-1 text-sm" />
                      <span className="text-sm">to</span>
                      <input type="date" value={toDate} onChange={(e) => { setToDate(e.target.value); setPage(1); }} className="border rounded px-2 py-1 text-sm" />
                    </>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm">
                    <span>Show:</span>
                    <select value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }} className="border rounded px-2 py-1">
                      {[10, 20, 50, 100].map((n) => <option key={n} value={n}>{n}</option>)}
                    </select>
                    <span>entries</span>
                  </div>
                  <button onClick={clearFilters} className="px-4 py-1.5 bg-red-600 text-white rounded text-sm">Clear Filters</button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm border-collapse">
                  <thead>
                    <tr className="bg-slate-200 text-slate-800">
                      <th className="border border-slate-300 px-2 py-2 text-left font-bold">Invoice</th>
                      <th className="border border-slate-300 px-2 py-2 text-left font-bold">Date</th>
                      <th className="border border-slate-300 px-2 py-2 text-left font-bold">Customer Id</th>
                      <th className="border border-slate-300 px-2 py-2 text-left font-bold">Customer Info</th>
                      <th className="border border-slate-300 px-2 py-2 text-left font-bold">Mobile</th>
                      <th className="border border-slate-300 px-2 py-2 text-right font-bold">Total Due</th>
                      <th className="border border-slate-300 px-2 py-2 text-right font-bold">Paid</th>
                      <th className="border border-slate-300 px-2 py-2 text-right font-bold">Due</th>
                      <th className="border border-slate-300 px-2 py-2 text-center font-bold">Details</th>
                      <th className="border border-slate-300 px-2 py-2 text-center font-bold">Return</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pageRows.map((s) => (
                      <tr key={s.id} className="hover:bg-blue-50/30">
                        <td className="border border-slate-300 px-2 py-2">{s.invoice_no}</td>
                        <td className="border border-slate-300 px-2 py-2">{fmtDate(s.sale_date)}</td>
                        <td className="border border-slate-300 px-2 py-2 font-mono text-xs">{code}</td>
                        <td className="border border-slate-300 px-2 py-2">
                          <div className="text-blue-700">{customer.name}</div>
                          <div className="text-green-700 text-xs">{customer.address || ""}</div>
                        </td>
                        <td className="border border-slate-300 px-2 py-2 text-green-700">{customer.mobile || ""}</td>
                        <td className="border border-slate-300 px-2 py-2 text-right">{Number(s.total_amount).toFixed(0)}</td>
                        <td className="border border-slate-300 px-2 py-2 text-right text-emerald-700">{Number(s.paid_amount).toFixed(0)}</td>
                        <td className="border border-slate-300 px-2 py-2 text-right text-rose-600">{Number(s.due_amount).toFixed(0)}</td>
                        <td className="border border-slate-300 px-1 py-1 text-center">
                          <button onClick={() => setDetailSale(s)} className="bg-slate-700 hover:bg-slate-800 text-white text-xs font-medium rounded px-3 py-1.5">Details</button>
                        </td>
                        <td className="border border-slate-300 px-1 py-1 text-center">
                          <button onClick={() => onOpenReturn(customer)} className="bg-slate-700 hover:bg-slate-800 text-white text-xs font-medium rounded px-3 py-1.5">Return Sale</button>
                        </td>
                      </tr>
                    ))}
                    {pageRows.length === 0 && (
                      <tr><td colSpan={10} className="text-center py-6 text-gray-500">No records</td></tr>
                    )}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-col items-center justify-center gap-2 mt-3 text-sm">
                <div className="flex items-center gap-2">
                  <button disabled={page <= 1} onClick={() => setPage(page - 1)} className="px-3 py-1 border rounded disabled:opacity-50">«</button>
                  <span>Page {page} of {totalPages}</span>
                  <button disabled={page >= totalPages} onClick={() => setPage(page + 1)} className="px-3 py-1 border rounded disabled:opacity-50">»</button>
                </div>
                <div className="flex items-center gap-2">
                  <span>Jump to:</span>
                  <input value={jumpTo} onChange={(e) => setJumpTo(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { const n = Math.max(1, Math.min(totalPages, Number(jumpTo) || 1)); setPage(n); } }}
                    className="border rounded px-2 py-1 w-16 text-center" />
                </div>
              </div>
            </>
          )}

          {/* DETAIL VIEW — real bill preview (same as print) */}
          {(kind === "sales" || kind === "return" || kind === "due") && detailSale && (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2 justify-end">
                <button
                  onClick={() => printInvoice(detailSale)}
                  className="bg-slate-700 hover:bg-slate-800 text-white text-sm rounded px-4 py-2 inline-flex items-center gap-1"
                >
                  <Printer className="w-4 h-4" /> Print
                </button>
                <button
                  onClick={() => {
                    if (onEditSale) { onEditSale(detailSale.id); onClose(); }
                    else setEditSale(detailSale);
                  }}
                  className="bg-amber-600 hover:bg-amber-700 text-white text-sm rounded px-4 py-2 inline-flex items-center gap-1"
                >
                  <Pencil className="w-4 h-4" /> Edit
                </button>
              </div>
              <div className="w-full flex justify-center bg-slate-100 rounded p-2">
                <iframe
                  title={`Invoice ${detailSale.invoice_no}`}
                  srcDoc={buildBillHtml(detailSale, true)}
                  style={{ width: "560px", height: "800px", border: "1px solid #cbd5e1", background: "#fff" }}
                />
              </div>
            </div>
          )}

          {kind === "payment" && (() => {
            const unpaid = Number(customer.due_amount) || 0;
            const paidNow = Number(collect) || 0;
            const remaining = Math.max(0, unpaid - paidNow);
            const ro = "w-full border border-gray-300 rounded px-3 py-2 bg-gray-100 text-gray-700";
            const inp = "w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500";
            return (
              <div className="space-y-5">
                <h3 className="text-center text-2xl font-serif italic text-gray-800">Due Payment Form</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Customer Id <span className="text-rose-500">*</span></label>
                    <input readOnly value={code} className={ro} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Name <span className="text-rose-500">*</span></label>
                    <input readOnly value={customer.name || ""} className={ro} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Address <span className="text-rose-500">*</span></label>
                    <input readOnly value={customer.address || ""} className={ro} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Mobile <span className="text-rose-500">*</span></label>
                    <input readOnly value={customer.mobile || ""} className={ro} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Unpaid<span className="text-rose-500">*</span></label>
                    <input readOnly value={unpaid} className={ro} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Paid<span className="text-rose-500">*</span></label>
                    <input
                      type="number"
                      value={collect || ""}
                      onChange={(e) => setCollect(Number(e.target.value) || 0)}
                      className={inp}
                      autoFocus
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Due<span className="text-rose-500">*</span></label>
                    <input readOnly value={remaining} className={ro} />
                  </div>
                  <div></div>
                </div>
                <button
                  onClick={handleCollect}
                  className="w-full py-3 bg-emerald-500 hover:bg-emerald-600 text-white rounded font-semibold text-lg"
                >
                  Paid
                </button>
              </div>
            );
          })()}

          {kind === "writeoff" && (() => {
            const unpaid = Number(customer.due_amount) || 0;
            const wOffNow = Number(wOff) || 0;
            const remaining = Math.max(0, unpaid - wOffNow);
            const ro = "w-full border border-gray-300 rounded px-3 py-2 bg-gray-100 text-gray-700";
            const inp = "w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500";
            return (
              <div className="space-y-5">
                <h3 className="text-center text-2xl font-serif italic text-gray-800">Write Off Form</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Customer Id <span className="text-rose-500">*</span></label>
                    <input readOnly value={code} className={ro} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Name <span className="text-rose-500">*</span></label>
                    <input readOnly value={customer.name || ""} className={ro} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Address <span className="text-rose-500">*</span></label>
                    <input readOnly value={customer.address || ""} className={ro} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Mobile <span className="text-rose-500">*</span></label>
                    <input readOnly value={customer.mobile || ""} className={ro} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Unpaid<span className="text-rose-500">*</span></label>
                    <input readOnly value={unpaid} className={ro} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Write Off<span className="text-rose-500">*</span></label>
                    <input
                      type="number"
                      value={wOff || ""}
                      onChange={(e) => setWOff(Number(e.target.value) || 0)}
                      className={inp}
                      autoFocus
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm text-gray-700 mb-1">Reason (optional)</label>
                    <input value={wReason} onChange={(e) => setWReason(e.target.value)} className={inp} />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm text-gray-700 mb-1">Due<span className="text-rose-500">*</span></label>
                    <input readOnly value={remaining} className={ro} />
                  </div>
                </div>
                <button
                  onClick={handleWriteOff}
                  className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white rounded font-semibold text-lg"
                >
                  Confirm Write Off
                </button>
              </div>
            );
          })()}

          {kind === "payhistory" && (
            <div className="space-y-3">
              <div className="text-sm text-gray-600">Customer: <b>{customer.name}</b> ({code}) — Current Due: <b className="text-rose-600">৳{Number(customer.due_amount).toFixed(0)}</b></div>
              <div className="overflow-x-auto border border-slate-300 rounded">
                <table className="w-full text-sm border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700">
                      <th className="border border-slate-300 px-2 py-2 text-left">Date</th>
                      <th className="border border-slate-300 px-2 py-2 text-left">Memo No</th>
                      <th className="border border-slate-300 px-2 py-2 text-center">Type</th>
                      <th className="border border-slate-300 px-2 py-2 text-right">Previous Due</th>
                      <th className="border border-slate-300 px-2 py-2 text-right">Paid</th>
                      <th className="border border-slate-300 px-2 py-2 text-right">Remaining Due</th>
                      <th className="border border-slate-300 px-2 py-2 text-left">Reason</th>
                      <th className="border border-slate-300 px-1 py-2 text-center print:hidden">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {payments.map((p) => (
                      <tr key={p.id} className="hover:bg-blue-50/40">
                        <td className="border border-slate-300 px-2 py-1">{fmtDate(p.created_at)}</td>
                        <td className="border border-slate-300 px-2 py-1 font-mono text-xs">{p.memo_no}</td>
                        <td className="border border-slate-300 px-2 py-1 text-center">
                          <span className={`text-xs px-2 py-0.5 rounded ${p.kind === "writeoff" ? "bg-rose-100 text-rose-700" : "bg-emerald-100 text-emerald-700"}`}>
                            {p.kind === "writeoff" ? "Write Off" : "Payment"}
                          </span>
                        </td>
                        <td className="border border-slate-300 px-2 py-1 text-right">{Number(p.previous_due).toFixed(0)}</td>
                        <td className="border border-slate-300 px-2 py-1 text-right font-semibold text-emerald-700">{Number(p.paid_amount).toFixed(0)}</td>
                        <td className="border border-slate-300 px-2 py-1 text-right text-rose-600">{Number(p.remaining_due).toFixed(0)}</td>
                        <td className="border border-slate-300 px-2 py-1">{p.reason || "—"}</td>
                        <td className="border border-slate-300 px-1 py-1 text-center print:hidden">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => { setEditPay(p); setEditAmt(Number(p.paid_amount)); setEditReason(p.reason || ""); }}
                              className="bg-amber-500 hover:bg-amber-600 text-white text-xs rounded px-2 py-1.5 inline-flex items-center gap-1"
                            >
                              <Pencil className="w-3 h-3" /> Edit
                            </button>
                            <button
                              onClick={() => deletePayment(p)}
                              className="bg-rose-500 hover:bg-rose-600 text-white text-xs rounded px-2 py-1.5 inline-flex items-center gap-1"
                            >
                              <Trash2 className="w-3 h-3" /> Delete
                            </button>
                            <button
                              onClick={() => printPaymentReceipt({
                                customerName: customer.name || "", mobile: customer.mobile || "", address: customer.address || "",
                                memoNo: p.memo_no, previousDue: Number(p.previous_due), paid: Number(p.paid_amount),
                                remainingDue: Number(p.remaining_due), kind: p.kind === "writeoff" ? "writeoff" : "payment",
                              })}
                              className="bg-slate-700 hover:bg-slate-800 text-white text-xs rounded px-2 py-1.5 inline-flex items-center gap-1"
                            >
                              <Printer className="w-3 h-3" /> Print
                            </button>
                          </div>
                        </td>

                      </tr>
                    ))}
                    {payments.length === 0 && (
                      <tr><td colSpan={8} className="text-center py-6 text-gray-500">No payment records</td></tr>
                    )}
                  </tbody>
                  {payments.length > 0 && (
                    <tfoot>
                      <tr className="bg-slate-50 font-semibold">
                        <td colSpan={4} className="border border-slate-300 px-2 py-2 text-right">Total Paid:</td>
                        <td className="border border-slate-300 px-2 py-2 text-right text-emerald-700">৳{payments.reduce((s, p) => s + Number(p.paid_amount || 0), 0).toFixed(0)}</td>
                        <td colSpan={3} className="border border-slate-300"></td>
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
      {editSale && (
        <EditSaleModal sale={editSale} customer={customer} onClose={() => setEditSale(null)} refresh={refresh} />
      )}
      {editPay && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4" onClick={() => setEditPay(null)}>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-3 border-b bg-amber-600 text-white rounded-t-xl">
              <h4 className="font-bold">Edit Record — Memo {editPay.memo_no}</h4>
              <button onClick={() => setEditPay(null)} className="p-1 hover:bg-white/20 rounded"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-4 space-y-3">
              <div>
                <label className="block text-sm text-gray-700 mb-1">Amount</label>
                <input type="number" value={editAmt || ""} onChange={(e) => setEditAmt(Number(e.target.value) || 0)}
                  className="w-full border border-gray-300 rounded px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Reason</label>
                <input value={editReason} onChange={(e) => setEditReason(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2" />
              </div>
              <div className="text-xs text-gray-500">Previous Due: {Number(editPay.previous_due).toFixed(0)} — New Remaining: {Math.max(0, Number(editPay.previous_due) - (Number(editAmt) || 0)).toFixed(0)}</div>
              <button onClick={savePaymentEdit} disabled={savingPay}
                className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-60 text-white rounded font-semibold">
                {savingPay ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

function EditSaleModal({
  sale, customer, onClose, refresh,
}: { sale: Sale; customer: Customer; onClose: () => void; refresh: () => void }) {
  const initial: any[] = Array.isArray(sale.items) ? sale.items : [];
  const [items, setItems] = useState<any[]>(initial.map((it) => ({ ...it })));
  const [paid, setPaid] = useState<number>(Number(sale.paid_amount) || 0);
  const [discount, setDiscount] = useState<number>(() => {
    const sub = initial.reduce((s, it) => s + (Number(it.total) || Number(it.totalPrice) || 0), 0);
    return Math.max(0, sub - Number(sale.total_amount));
  });
  const [saving, setSaving] = useState(false);

  function updateItem(i: number, patch: any) {
    setItems((arr) => arr.map((it, idx) => {
      if (idx !== i) return it;
      const merged = { ...it, ...patch };
      const qty = Number(merged.quantity ?? merged.feet ?? merged.pieces ?? 0);
      const price = Number(merged.price ?? merged.rate ?? 0);
      const total = qty * price;
      merged.total = total;
      merged.totalPrice = total;
      return merged;
    }));
  }

  const subtotal = items.reduce((s, it) => s + (Number(it.total) || Number(it.totalPrice) || 0), 0);
  const grandTotal = Math.max(0, subtotal - (Number(discount) || 0));
  const dueAmount = Math.max(0, grandTotal - (Number(paid) || 0));

  async function save() {
    if (saving) return;
    setSaving(true);
    try {
      const oldDue = Number(sale.due_amount) || 0;
      const dueDiff = dueAmount - oldDue;
      const { error } = await supabase.from("sales").update({
        items, total_amount: grandTotal, paid_amount: Number(paid) || 0, due_amount: dueAmount,
      }).eq("id", sale.id);
      if (error) throw error;
      if (dueDiff !== 0) {
        await supabase.from("customers").update({
          due_amount: Math.max(0, (Number(customer.due_amount) || 0) + dueDiff),
        }).eq("id", customer.id);
      }
      toast.success("Invoice updated");
      refresh();
      onClose();
    } catch (e: any) {
      toast.error(e?.message || "Update failed");
    } finally {
      setSaving(false);
    }
  }

  const inputCls = "w-full px-2 py-1.5 rounded border border-gray-300 text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 outline-none";

  return (
    <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-4 py-3 border-b bg-amber-50">
          <h3 className="font-semibold text-amber-800">Edit Invoice — {sale.invoice_no}</h3>
          <button onClick={onClose} className="p-1 rounded hover:bg-amber-100"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-4 space-y-3">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-slate-100">
                <th className="border px-2 py-2 text-left">Product</th>
                <th className="border px-2 py-2 text-right">Quantity</th>
                <th className="border px-2 py-2 text-right">Price</th>
                <th className="border px-2 py-2 text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {items.map((it, i) => (
                <tr key={i}>
                  <td className="border px-2 py-1">{it.product_name || it.name || it.productId || "-"}</td>
                  <td className="border px-2 py-1">
                    <input type="number" step="0.01"
                      value={it.quantity ?? it.feet ?? it.pieces ?? 0}
                      onChange={(e) => {
                        const v = Number(e.target.value) || 0;
                        const patch: any = {};
                        if ("quantity" in it) patch.quantity = v;
                        else if ("feet" in it) patch.feet = v;
                        else patch.pieces = v;
                        updateItem(i, patch);
                      }}
                      className={inputCls + " text-right"} />
                  </td>
                  <td className="border px-2 py-1">
                    <input type="number" step="0.01"
                      value={it.price ?? it.rate ?? 0}
                      onChange={(e) => {
                        const v = Number(e.target.value) || 0;
                        const patch: any = "rate" in it ? { rate: v } : { price: v };
                        updateItem(i, patch);
                      }}
                      className={inputCls + " text-right"} />
                  </td>
                  <td className="border px-2 py-1 text-right">{Number(it.total || it.totalPrice || 0).toFixed(0)}</td>
                </tr>
              ))}
              {items.length === 0 && <tr><td colSpan={4} className="border px-2 py-3 text-center text-gray-500">No items</td></tr>}
            </tbody>
          </table>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
            <div>
              <label className="text-xs text-gray-500">Subtotal</label>
              <div className="px-2 py-2 bg-gray-50 rounded font-semibold">{subtotal.toFixed(0)}</div>
            </div>
            <div>
              <label className="text-xs text-gray-500">Discount</label>
              <input type="number" value={discount || ""} onChange={(e) => setDiscount(Number(e.target.value) || 0)} className={inputCls} />
            </div>
            <div>
              <label className="text-xs text-gray-500">Paid</label>
              <input type="number" value={paid || ""} onChange={(e) => setPaid(Number(e.target.value) || 0)} className={inputCls} />
            </div>
            <div>
              <label className="text-xs text-gray-500">Due</label>
              <div className="px-2 py-2 bg-gray-50 rounded font-semibold text-rose-600">{dueAmount.toFixed(0)}</div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3">
            <button onClick={onClose} className="px-4 py-2 rounded bg-gray-200 text-gray-800 text-sm">Cancel</button>
            <button onClick={save} disabled={saving} className="px-4 py-2 rounded bg-emerald-600 text-white text-sm font-medium disabled:opacity-60">{saving ? "Saving..." : "Save Changes"}</button>
          </div>
        </div>
      </div>
    </div>
  );
}


