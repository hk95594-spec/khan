import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import jsPDF from "jspdf";
import {
  UserPlus, Search, Edit3, Trash2, Eye, BookOpen, Wallet, Printer,
  Phone, MessageSquare, X, Users, TrendingUp, AlertTriangle, Store,
  IdCard, MapPin, FileText, Download, QrCode, Sparkles,
} from "lucide-react";

type Customer = { id: string; name: string; mobile: string | null; address: string | null; due_amount: number; created_at?: string };
type Sale = {
  id: string; invoice_no: string; customer_id: string | null; total_amount: number;
  paid_amount: number; due_amount: number; sale_date: string; is_returned: boolean; returned_amount: number;
};

type CustomerType = "খুচরা" | "পাইকারি" | "দোকানদার" | "Contractor" | "Dealer";
type CustomerMeta = {
  code?: string;
  whatsapp?: string;
  type?: CustomerType;
  shop_name?: string;
  nid?: string;
  opening_balance?: number;
};

const META_KEY = "tiles_customer_meta_v1";
const loadMeta = (): Record<string, CustomerMeta> => {
  try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch { return {}; }
};
const saveMeta = (m: Record<string, CustomerMeta>) => localStorage.setItem(META_KEY, JSON.stringify(m));

const typeColors: Record<CustomerType, string> = {
  "খুচরা": "from-emerald-500 to-green-600",
  "পাইকারি": "from-blue-500 to-indigo-600",
  "দোকানদার": "from-orange-500 to-amber-600",
  "Contractor": "from-pink-500 to-rose-600",
  "Dealer": "from-purple-500 to-fuchsia-600",
};

const typeBadge: Record<CustomerType, string> = {
  "খুচরা": "bg-emerald-100 text-emerald-700 border-emerald-300",
  "পাইকারি": "bg-blue-100 text-blue-700 border-blue-300",
  "দোকানদার": "bg-orange-100 text-orange-700 border-orange-300",
  "Contractor": "bg-pink-100 text-pink-700 border-pink-300",
  "Dealer": "bg-purple-100 text-purple-700 border-purple-300",
};

export default function CustomerManager({
  userId, customers, sales, refresh,
}: { userId: string; customers: Customer[]; sales: Sale[]; refresh: () => void }) {
  const [meta, setMeta] = useState<Record<string, CustomerMeta>>(loadMeta);
  const [filterType, setFilterType] = useState<string>("all");
  const [editing, setEditing] = useState<Customer | null>(null);
  const [viewing, setViewing] = useState<Customer | null>(null);
  const [ledgerOf, setLedgerOf] = useState<Customer | null>(null);
  const [dueOf, setDueOf] = useState<Customer | null>(null);
  const [prevDueOf, setPrevDueOf] = useState<Customer | null>(null);
  const [writeOffOf, setWriteOffOf] = useState<Customer | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // Filters
  const [qId, setQId] = useState("");
  const [qName, setQName] = useState("");
  const [qAddress, setQAddress] = useState("");
  const [qMobile, setQMobile] = useState("");
  const [actionFilter, setActionFilter] = useState<"all" | "prevDue" | "duePayment" | "writeOff">("all");
  const [perPage, setPerPage] = useState<number>(20);
  const [page, setPage] = useState<number>(1);
  const [gotoPage, setGotoPage] = useState<string>("");

  // Form state
  const [fName, setFName] = useState("");
  const [fMobile, setFMobile] = useState("");
  const [fWhatsapp, setFWhatsapp] = useState("");
  const [fAddress, setFAddress] = useState("");
  const [fType, setFType] = useState<CustomerType>("খুচরা");
  const [fNid, setFNid] = useState("");
  const [fShop, setFShop] = useState("");
  const [fPrevDue, setFPrevDue] = useState<number>(0);
  const [fOpening, setFOpening] = useState<number>(0);
  const [dupWarn, setDupWarn] = useState<Customer | null>(null);
  const [saving, setSaving] = useState(false);

  const nextCode = useMemo(() => {
    const sorted = [...customers].sort((a, b) =>
      (a.created_at || "").localeCompare(b.created_at || "")
    );
    const next = sorted.length + 1;
    return `CUST${String(next).padStart(6, "0")}`;
  }, [customers]);

  useEffect(() => {
    if (showAddModal) {
      setFName(""); setFMobile(""); setFWhatsapp(""); setFAddress("");
      setFNid(""); setFShop(""); setFPrevDue(0); setFOpening(0); setFType("খুচরা");
      setDupWarn(null);
    }
  }, [showAddModal]);

  useEffect(() => {
    const name = fName.trim().toLowerCase();
    const mobile = fMobile.trim().replace(/\D/g, "");
    if (!name && !mobile) { setDupWarn(null); return; }
    const hit = customers.find((c) => {
      const cName = (c.name || "").trim().toLowerCase();
      const cMobile = (c.mobile || "").replace(/\D/g, "");
      const sameMobile = mobile && cMobile === mobile;
      const sameName = name && cName === name;
      return sameMobile || (sameName && sameMobile);
    });
    setDupWarn(hit || null);
  }, [fName, fMobile, customers]);

  const statsByCust = useMemo(() => {
    const map = new Map<string, { totalPurchase: number; totalPaid: number; totalDue: number; lastDate: string | null; sales: Sale[] }>();
    for (const s of sales) {
      if (!s.customer_id) continue;
      const cur = map.get(s.customer_id) || { totalPurchase: 0, totalPaid: 0, totalDue: 0, lastDate: null, sales: [] };
      cur.totalPurchase += Number(s.total_amount) - Number(s.returned_amount || 0);
      cur.totalPaid += Number(s.paid_amount);
      cur.totalDue += Number(s.due_amount);
      cur.sales.push(s);
      if (!cur.lastDate || s.sale_date > cur.lastDate) cur.lastDate = s.sale_date;
      map.set(s.customer_id, cur);
    }
    return map;
  }, [sales]);

  const allFiltered = useMemo(() => {
    const list = customers.filter((c) => {
      const m = meta[c.id] || {};
      const code = (m.code || c.id).toLowerCase();
      if (qId && !code.includes(qId.toLowerCase())) return false;
      if (qName && !(c.name || "").toLowerCase().includes(qName.toLowerCase())) return false;
      if (qAddress && !(c.address || "").toLowerCase().includes(qAddress.toLowerCase())) return false;
      if (qMobile && !(c.mobile || "").toLowerCase().includes(qMobile.toLowerCase())) return false;
      if (filterType !== "all" && (m.type || "খুচরা") !== filterType) return false;
      if (actionFilter === "prevDue" && Number(c.due_amount) <= 0) return false;
      if (actionFilter === "duePayment" && Number(c.due_amount) <= 0) return false;
      return true;
    });
    return list;
  }, [customers, meta, qId, qName, qAddress, qMobile, filterType, actionFilter]);

  const totalPages = Math.max(1, Math.ceil(allFiltered.length / perPage));
  const currentPage = Math.min(page, totalPages);
  const filtered = useMemo(
    () => allFiltered.slice((currentPage - 1) * perPage, currentPage * perPage),
    [allFiltered, currentPage, perPage]
  );

  useEffect(() => { setPage(1); }, [perPage, qId, qName, qAddress, qMobile, filterType, actionFilter]);

  const goTo = (p: number) => setPage(Math.min(totalPages, Math.max(1, p)));
  const pageNumbers = useMemo(() => {
    const out: number[] = [];
    const start = Math.max(1, Math.min(currentPage - 2, totalPages - 4));
    for (let i = start; i < start + 5 && i <= totalPages; i++) out.push(i);
    return out;
  }, [currentPage, totalPages]);

  const clearFilters = () => {
    setQId(""); setQName(""); setQAddress(""); setQMobile("");
    setFilterType("all"); setActionFilter("all");
  };

  const handleAdd = async () => {
    if (!fName.trim()) return toast.error("নাম দিন / Name required");
    if (!fMobile.trim()) return toast.error("মোবাইল দিন / Mobile required");
    if (dupWarn) return toast.error(`এই মোবাইল আছে: ${dupWarn.name}`);
    if (saving) return;
    setSaving(true);

    try {
      const { data, error } = await supabase.from("customers").insert({
        user_id: userId, name: fName.trim(), mobile: fMobile.trim(),
        address: fAddress.trim() || null, due_amount: fPrevDue,
      }).select().single();

      if (error || !data) {
        toast.error(error?.message || "Failed");
        return;
      }

      const next = { ...meta };
      next[data.id] = {
        code: nextCode, whatsapp: fWhatsapp.trim(), type: fType,
        shop_name: fShop.trim(), nid: fNid.trim(), opening_balance: fOpening,
      };
      saveMeta(next); setMeta(next);

      toast.success(`কাস্টমার যুক্ত — ${nextCode}`);
      setFName(""); setFMobile(""); setFWhatsapp(""); setFAddress("");
      setFNid(""); setFShop(""); setFPrevDue(0); setFOpening(0); setFType("খুচরা");
      setShowAddModal(false);
      refresh();
    } finally {
      setSaving(false);
    }
  };

  const handleSaveEdit = async (c: Customer, m: CustomerMeta) => {
    const { error } = await supabase.from("customers").update({
      name: c.name, mobile: c.mobile, address: c.address, due_amount: c.due_amount,
    }).eq("id", c.id);
    if (error) return toast.error(error.message);
    const next = { ...meta, [c.id]: { ...meta[c.id], ...m } };
    saveMeta(next); setMeta(next);
    toast.success("আপডেট সফল");
    setEditing(null); refresh();
  };

  const handleDelete = async (c: Customer) => {
    if (!confirm(`Delete ${c.name}?`)) return;
    const { error } = await supabase.from("customers").delete().eq("id", c.id);
    if (error) return toast.error(error.message);
    const next = { ...meta }; delete next[c.id]; saveMeta(next); setMeta(next);
    toast.success("Deleted"); refresh();
  };

  const handleCollectDue = async (c: Customer, amount: number) => {
    if (amount <= 0) return toast.error("Amount > 0");
    const newDue = Math.max(0, Number(c.due_amount) - amount);
    const { error } = await supabase.from("customers").update({ due_amount: newDue }).eq("id", c.id);
    if (error) return toast.error(error.message);
    await supabase.from("cash_transactions").insert({
      user_id: userId, type: "in", amount, reason: `Due collection — ${c.name}`,
    });
    toast.success(`৳${amount} collected from ${c.name}`);
    setDueOf(null); refresh();
  };

  const handleAddPrevDue = async (c: Customer, amount: number) => {
    if (amount <= 0) return toast.error("Amount > 0");
    const newDue = Number(c.due_amount) + amount;
    const { error } = await supabase.from("customers").update({ due_amount: newDue }).eq("id", c.id);
    if (error) return toast.error(error.message);
    toast.success(`Previous due ৳${amount} added to ${c.name}`);
    setPrevDueOf(null); refresh();
  };

  const handleWriteOff = async (c: Customer, amount: number) => {
    if (amount <= 0) return toast.error("Amount > 0");
    const newDue = Math.max(0, Number(c.due_amount) - amount);
    const { error } = await supabase.from("customers").update({ due_amount: newDue }).eq("id", c.id);
    if (error) return toast.error(error.message);
    await supabase.from("cash_transactions").insert({
      user_id: userId, type: "out", amount, reason: `Write-off — ${c.name}`,
    });
    toast.success(`৳${amount} written off for ${c.name}`);
    setWriteOffOf(null); refresh();
  };

  const printList = () => window.print();

  return (
    <div className="space-y-4">
      {/* Top bar: Add Customer button */}
      <div className="flex items-start justify-between">
        <button
          onClick={() => setShowAddModal(true)}
          className="px-5 py-2.5 bg-blue-500 hover:bg-blue-600 text-white rounded-md font-medium shadow"
        >
          Add Customer
        </button>
      </div>

      {/* Centered title */}
      <h2 className="text-2xl font-semibold text-center text-gray-800">Customer List</h2>

      {/* Print link */}
      <div>
        <button onClick={printList} className="text-gray-700 hover:text-blue-600 underline-offset-2 hover:underline text-sm">
          Print
        </button>
      </div>

      {/* Search row */}
      <div className="flex flex-wrap items-center gap-3">
        <input value={qId} onChange={(e) => setQId(e.target.value)} placeholder="Search by CustomerId"
          className="flex-1 min-w-[180px] border rounded-md px-3 py-2 text-sm" />
        <input value={qName} onChange={(e) => setQName(e.target.value)} placeholder="Search by Name"
          className="flex-1 min-w-[180px] border rounded-md px-3 py-2 text-sm" />
        <input value={qAddress} onChange={(e) => setQAddress(e.target.value)} placeholder="Search by Address"
          className="flex-1 min-w-[180px] border rounded-md px-3 py-2 text-sm" />
        <input value={qMobile} onChange={(e) => setQMobile(e.target.value)} placeholder="Search by Mobile"
          className="flex-1 min-w-[180px] border rounded-md px-3 py-2 text-sm" />
        <select value={filterType} onChange={(e) => setFilterType(e.target.value)}
          className="border rounded-md px-3 py-2 text-sm bg-white">
          <option value="all">All Categories</option>
          <option value="খুচরা">খুচরা</option>
          <option value="পাইকারি">পাইকারি</option>
          <option value="দোকানদার">দোকানদার</option>
          <option value="Contractor">Contractor</option>
          <option value="Dealer">Dealer</option>
        </select>
        <button onClick={clearFilters} className="px-4 py-2 bg-white border rounded-md text-sm hover:bg-gray-50">
          Clear Filter
        </button>
      </div>

      {/* Action filter buttons */}
      <div className="flex flex-wrap items-center justify-center gap-3">
        <button
          onClick={() => setActionFilter("prevDue")}
          className={`px-4 py-2 rounded-md text-sm border ${actionFilter === "prevDue" ? "bg-blue-50 border-blue-400" : "bg-white"}`}
        >Add Previous Due</button>
        <button
          onClick={() => setActionFilter("duePayment")}
          className={`px-4 py-2 rounded-md text-sm border ${actionFilter === "duePayment" ? "bg-blue-50 border-blue-400" : "bg-white"}`}
        >Due Payment</button>
        <button
          onClick={() => setActionFilter("writeOff")}
          className={`px-4 py-2 rounded-md text-sm border ${actionFilter === "writeOff" ? "bg-blue-50 border-blue-400" : "bg-white"}`}
        >Write-off</button>
        <button
          onClick={() => setActionFilter("all")}
          className={`px-4 py-2 rounded-md text-sm text-white ${actionFilter === "all" ? "bg-emerald-700" : "bg-emerald-600 hover:bg-emerald-700"}`}
        >Show All</button>
      </div>

      {/* Items per page */}
      <div className="flex items-center justify-center gap-2 text-sm text-gray-700">
        <span>Items per page:</span>
        <select value={perPage} onChange={(e) => setPerPage(Number(e.target.value))} className="border rounded px-2 py-1 bg-white">
          <option value={20}>20</option>
          <option value={50}>50</option>
          <option value={100}>100</option>
          <option value={500}>500</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white border rounded-lg overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-gray-600 text-xs uppercase border-b">
              <th className="px-3 py-3 text-left">CustomerId</th>
              <th className="px-3 py-3 text-left">Name</th>
              <th className="px-3 py-3 text-left">Address</th>
              <th className="px-3 py-3 text-left">Mobile</th>
              <th className="px-3 py-3 text-left">Category</th>
              <th className="px-3 py-3 text-center">Edit</th>
              <th className="px-3 py-3 text-center">Delete</th>
              <th className="px-3 py-3 text-right">Due</th>
              <th className="px-3 py-3 text-center">Sale</th>
              <th className="px-3 py-3 text-center">Add Previous Due</th>
              <th className="px-3 py-3 text-center">Due Payment</th>
              <th className="px-3 py-3 text-center">Write-off</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((c) => {
              const m = meta[c.id] || {};
              const t = (m.type || "খুচরা") as CustomerType;
              return (
                <tr key={c.id} className="border-b hover:bg-gray-50">
                  <td className="px-3 py-3 font-mono text-xs text-gray-700">{m.code || c.id.slice(0, 8)}</td>
                  <td className="px-3 py-3 font-medium">
                    <button onClick={() => setViewing(c)} className="hover:underline text-left">{c.name}</button>
                  </td>
                  <td className="px-3 py-3 text-gray-700">{c.address || "—"}</td>
                  <td className="px-3 py-3">{c.mobile || "—"}</td>
                  <td className="px-3 py-3 text-gray-700">{t === "খুচরা" ? "general" : t}</td>
                  <td className="px-3 py-3 text-center">
                    <button onClick={() => setEditing(c)} className="text-gray-700 hover:text-blue-600">
                      <Edit3 className="w-4 h-4 inline" />
                    </button>
                  </td>
                  <td className="px-3 py-3 text-center">
                    <button onClick={() => handleDelete(c)} className="text-red-500 hover:text-red-700">
                      <Trash2 className="w-4 h-4 inline" />
                    </button>
                  </td>
                  <td className="px-3 py-3 text-right font-medium">{Number(c.due_amount).toFixed(0)}</td>
                  <td className="px-3 py-3 text-center">
                    <button
                      onClick={() => toast.info("Use Sale menu to create new invoice")}
                      className="px-4 py-1.5 bg-blue-500 hover:bg-blue-600 text-white text-xs rounded"
                    >Sale</button>
                  </td>
                  <td className="px-3 py-3 text-center">
                    <button
                      onClick={() => setPrevDueOf(c)}
                      className="px-4 py-1.5 bg-blue-500 hover:bg-blue-600 text-white text-xs rounded"
                    >Add Previous</button>
                  </td>
                  <td className="px-3 py-3 text-center">
                    <button
                      onClick={() => setDueOf(c)}
                      className="px-4 py-1.5 bg-blue-500 hover:bg-blue-600 text-white text-xs rounded"
                    >Due Payment</button>
                  </td>
                  <td className="px-3 py-3 text-center">
                    <button
                      onClick={() => setWriteOffOf(c)}
                      className="px-4 py-1.5 bg-blue-500 hover:bg-blue-600 text-white text-xs rounded"
                    >Write-off</button>
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr><td colSpan={12} className="text-center py-8 text-gray-500">কোন কাস্টমার নেই</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex flex-wrap items-center justify-center gap-2 text-sm">
        <span className="text-gray-600">
          {allFiltered.length === 0 ? 0 : (currentPage - 1) * perPage + 1}-
          {Math.min(currentPage * perPage, allFiltered.length)} of {allFiltered.length}
        </span>
        <button onClick={() => goTo(currentPage - 1)} disabled={currentPage === 1}
          className="px-3 py-1.5 border rounded bg-white disabled:opacity-40">Prev</button>
        {pageNumbers.map((p) => (
          <button key={p} onClick={() => goTo(p)}
            className={`px-3 py-1.5 border rounded ${p === currentPage ? "bg-emerald-600 text-white border-emerald-600" : "bg-white"}`}>{p}</button>
        ))}
        <button onClick={() => goTo(currentPage + 1)} disabled={currentPage === totalPages}
          className="px-3 py-1.5 border rounded bg-white disabled:opacity-40">Next</button>
        <span className="ml-2 text-gray-600">Go to page:</span>
        <input
          type="number"
          min={1}
          max={totalPages}
          value={gotoPage}
          onChange={(e) => setGotoPage(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") { goTo(Number(gotoPage) || 1); setGotoPage(""); } }}
          className="w-20 border rounded px-2 py-1.5"
          placeholder={String(currentPage)}
        />
        <button onClick={() => { goTo(Number(gotoPage) || 1); setGotoPage(""); }}
          className="px-3 py-1.5 border rounded bg-white">Go</button>
        <span className="text-gray-500">/ {totalPages}</span>
      </div>

      {/* Add Customer modal */}
      {showAddModal && (
        <Modal onClose={() => setShowAddModal(false)} title="Add Customer">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Field label="Customer ID (Auto)"><input value={nextCode} disabled className="w-full border rounded-lg px-3 py-2 bg-gray-100 text-gray-600 font-mono text-sm" /></Field>
            <Field label="Customer Name *"><input value={fName} onChange={(e) => setFName(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></Field>
            <Field label="Mobile *">
              <input value={fMobile} onChange={(e) => setFMobile(e.target.value)} className={`w-full border rounded-lg px-3 py-2 ${dupWarn ? "border-red-400 bg-red-50" : ""}`} />
              {dupWarn && <p className="text-xs text-red-600 mt-1">Exists: {dupWarn.name}</p>}
            </Field>
            <Field label="WhatsApp"><input value={fWhatsapp} onChange={(e) => setFWhatsapp(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></Field>
            <Field label="Customer Type">
              <select value={fType} onChange={(e) => setFType(e.target.value as CustomerType)} className="w-full border rounded-lg px-3 py-2 bg-white">
                <option value="খুচরা">খুচরা</option>
                <option value="পাইকারি">পাইকারি</option>
                <option value="দোকানদার">দোকানদার</option>
                <option value="Contractor">Contractor</option>
                <option value="Dealer">Dealer</option>
              </select>
            </Field>
            <Field label="Shop Name"><input value={fShop} onChange={(e) => setFShop(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></Field>
            <Field label="NID"><input value={fNid} onChange={(e) => setFNid(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></Field>
            <Field label="Previous Due"><input type="number" value={fPrevDue} onChange={(e) => setFPrevDue(Number(e.target.value) || 0)} className="w-full border rounded-lg px-3 py-2" /></Field>
            <Field label="Opening Balance"><input type="number" value={fOpening} onChange={(e) => setFOpening(Number(e.target.value) || 0)} className="w-full border rounded-lg px-3 py-2" /></Field>
            <div className="md:col-span-2">
              <Field label="Address"><textarea value={fAddress} onChange={(e) => setFAddress(e.target.value)} rows={2} className="w-full border rounded-lg px-3 py-2" /></Field>
            </div>
          </div>
          <button onClick={handleAdd} disabled={saving || !!dupWarn} className="mt-4 w-full px-6 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg font-medium">
            {saving ? "Saving..." : dupWarn ? "Already Saved" : "Save Customer"}
          </button>
        </Modal>
      )}

      {viewing && (
        <Modal onClose={() => setViewing(null)} title="Customer Profile">
          <ProfileView c={viewing} m={meta[viewing.id] || {}} stats={statsByCust.get(viewing.id)} />
          <div className="mt-3 flex gap-2">
            <button onClick={() => { setLedgerOf(viewing); setViewing(null); }} className="px-3 py-1.5 bg-indigo-100 text-indigo-700 rounded text-sm">Ledger</button>
            <button onClick={() => { printCustomerReport(viewing); }} className="px-3 py-1.5 bg-gray-100 text-gray-700 rounded text-sm flex items-center gap-1"><Printer className="w-3.5 h-3.5" /> Print</button>
            <button onClick={() => handleDelete(viewing)} className="px-3 py-1.5 bg-red-100 text-red-700 rounded text-sm ml-auto">Delete</button>
          </div>
        </Modal>
      )}

      {editing && (
        <Modal onClose={() => setEditing(null)} title="Edit Customer">
          <EditForm c={editing} m={meta[editing.id] || {}} onSave={handleSaveEdit} />
        </Modal>
      )}

      {ledgerOf && (
        <Modal onClose={() => setLedgerOf(null)} title={`Ledger — ${ledgerOf.name}`}>
          <LedgerView c={ledgerOf} sales={statsByCust.get(ledgerOf.id)?.sales || []} />
        </Modal>
      )}

      {dueOf && (
        <Modal onClose={() => setDueOf(null)} title={`Due Payment — ${dueOf.name}`}>
          <DueCollect c={dueOf} onCollect={(amt) => handleCollectDue(dueOf, amt)} />
        </Modal>
      )}

      {prevDueOf && (
        <Modal onClose={() => setPrevDueOf(null)} title={`Add Previous Due — ${prevDueOf.name}`}>
          <AmountForm label="Previous Due Amount" buttonLabel="Add Due" onSubmit={(amt) => handleAddPrevDue(prevDueOf, amt)} />
        </Modal>
      )}

      {writeOffOf && (
        <Modal onClose={() => setWriteOffOf(null)} title={`Write-off — ${writeOffOf.name}`}>
          <AmountForm label="Write-off Amount" buttonLabel="Confirm Write-off" defaultValue={Number(writeOffOf.due_amount)} onSubmit={(amt) => handleWriteOff(writeOffOf, amt)} />
        </Modal>
      )}
    </div>
  );

  function printCustomerReport(c: Customer) {
    const m = meta[c.id] || {};
    const st = statsByCust.get(c.id);
    const doc = new jsPDF();
    doc.setFontSize(18); doc.text("Customer Report", 14, 18);
    doc.setFontSize(11);
    let y = 32;
    const row = (k: string, v: string) => { doc.text(`${k}: ${v}`, 14, y); y += 7; };
    row("Customer ID", m.code || c.id.slice(0, 8));
    row("Name", c.name);
    row("Mobile", c.mobile || "—");
    row("Address", c.address || "—");
    row("Current Due", `${Number(c.due_amount).toFixed(2)}`);
    row("Total Purchase", `${(st?.totalPurchase || 0).toFixed(2)}`);
    doc.save(`customer-${(m.code || c.id).replace(/\s+/g, "_")}.pdf`);
  }
}

function AmountForm({ label, buttonLabel, defaultValue = 0, onSubmit }: { label: string; buttonLabel: string; defaultValue?: number; onSubmit: (amount: number) => void }) {
  const [amount, setAmount] = useState<number>(defaultValue);
  return (
    <div className="space-y-3">
      <Field label={label}>
        <input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)} className="w-full border rounded-lg px-3 py-2 text-lg" />
      </Field>
      <button onClick={() => onSubmit(amount)} className="w-full px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium">
        {buttonLabel}
      </button>
    </div>
  );
}

// ---------- Sub components ----------
function KpiCard({ label, value, grad, icon }: { label: string; value: number | string; grad: string; icon: React.ReactNode }) {
  return (
    <div className={`bg-gradient-to-br ${grad} text-white rounded-2xl p-3 shadow-lg`}>
      <div className="flex items-center justify-between">
        <span className="text-xs opacity-90">{label}</span>
        <span className="bg-white/20 rounded-full p-1.5">{icon}</span>
      </div>
      <p className="text-xl font-bold mt-1">{value}</p>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-gray-600 block mb-1">{label}</span>
      {children}
    </label>
  );
}

function IconBtn({ children, onClick, title, color }: { children: React.ReactNode; onClick: () => void; title: string; color: string }) {
  return <button onClick={onClick} title={title} className={`p-1.5 rounded-md ${color} hover:scale-110 transition`}>{children}</button>;
}

function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-blue-600 to-indigo-700 text-white rounded-t-2xl">
          <h3 className="font-bold">{title}</h3>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function ProfileView({ c, m, stats }: { c: Customer; m: CustomerMeta; stats?: { totalPurchase: number; totalPaid: number; totalDue: number; lastDate: string | null; sales: Sale[] } }) {
  const t = (m.type || "খুচরা") as CustomerType;
  return (
    <div className="space-y-4">
      <div className={`bg-gradient-to-r ${typeColors[t]} text-white rounded-xl p-5`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs opacity-80">{m.code || c.id.slice(0, 8)}</p>
            <h3 className="text-2xl font-bold">{c.name}</h3>
            {m.shop_name && <p className="text-sm opacity-90">{m.shop_name}</p>}
          </div>
          <QrCode className="w-16 h-16 opacity-50" />
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
        <Info icon={<Phone className="w-3.5 h-3.5" />} label="Mobile" value={c.mobile || "—"} />
        <Info icon={<MessageSquare className="w-3.5 h-3.5" />} label="WhatsApp" value={m.whatsapp || "—"} />
        <Info icon={<IdCard className="w-3.5 h-3.5" />} label="NID" value={m.nid || "—"} />
        <Info icon={<MapPin className="w-3.5 h-3.5" />} label="Address" value={c.address || "—"} />
        <Info icon={<Sparkles className="w-3.5 h-3.5" />} label="Type" value={t} />
        <Info icon={<FileText className="w-3.5 h-3.5" />} label="Last Sale" value={stats?.lastDate || "—"} />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Stat label="Total Purchase" value={`৳${(stats?.totalPurchase || 0).toFixed(0)}`} clr="from-indigo-500 to-violet-600" />
        <Stat label="Total Paid" value={`৳${(stats?.totalPaid || 0).toFixed(0)}`} clr="from-emerald-500 to-teal-600" />
        <Stat label="Current Due" value={`৳${Number(c.due_amount).toFixed(0)}`} clr="from-rose-500 to-red-600" />
        <Stat label="Invoices" value={String(stats?.sales.length || 0)} clr="from-amber-500 to-orange-600" />
      </div>
    </div>
  );
}

function Info({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="border rounded-lg p-2.5 bg-gray-50">
      <div className="text-xs text-gray-500 flex items-center gap-1">{icon} {label}</div>
      <div className="font-medium text-gray-800">{value}</div>
    </div>
  );
}

function Stat({ label, value, clr }: { label: string; value: string; clr: string }) {
  return (
    <div className={`bg-gradient-to-br ${clr} text-white rounded-xl p-3`}>
      <p className="text-xs opacity-90">{label}</p>
      <p className="text-lg font-bold">{value}</p>
    </div>
  );
}

function EditForm({ c, m, onSave }: { c: Customer; m: CustomerMeta; onSave: (c: Customer, m: CustomerMeta) => void }) {
  const [name, setName] = useState(c.name);
  const [mobile, setMobile] = useState(c.mobile || "");
  const [address, setAddress] = useState(c.address || "");
  const [due, setDue] = useState<number>(Number(c.due_amount));
  const [whatsapp, setWhatsapp] = useState(m.whatsapp || "");
  const [shop, setShop] = useState(m.shop_name || "");
  const [type, setType] = useState<CustomerType>((m.type || "খুচরা") as CustomerType);
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Field label="Name"><input value={name} onChange={(e) => setName(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></Field>
        <Field label="Mobile"><input value={mobile} onChange={(e) => setMobile(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></Field>
        <Field label="WhatsApp"><input value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></Field>
        <Field label="Shop Name"><input value={shop} onChange={(e) => setShop(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></Field>
        <Field label="Type">
          <select value={type} onChange={(e) => setType(e.target.value as CustomerType)} className="w-full border rounded-lg px-3 py-2 bg-white">
            <option value="খুচরা">খুচরা</option>
            <option value="পাইকারি">পাইকারি</option>
            <option value="দোকানদার">দোকানদার</option>
            <option value="Contractor">Contractor</option>
            <option value="Dealer">Dealer</option>
          </select>
        </Field>
        <Field label="Due Amount"><input type="number" value={due} onChange={(e) => setDue(Number(e.target.value) || 0)} className="w-full border rounded-lg px-3 py-2" /></Field>
        <div className="md:col-span-2"><Field label="Address"><textarea value={address} onChange={(e) => setAddress(e.target.value)} rows={2} className="w-full border rounded-lg px-3 py-2" /></Field></div>
      </div>
      <button
        onClick={() => onSave({ ...c, name, mobile, address, due_amount: due }, { whatsapp, shop_name: shop, type })}
        className="w-full px-4 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg font-medium"
      >Save Changes</button>
    </div>
  );
}

function LedgerView({ c, sales }: { c: Customer; sales: Sale[] }) {
  const sorted = [...sales].sort((a, b) => a.sale_date.localeCompare(b.sale_date));
  let bal = 0;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-indigo-600 text-white">
          <tr>
            <th className="px-2 py-2 text-left">Date</th>
            <th className="px-2 py-2 text-left">Invoice</th>
            <th className="px-2 py-2 text-right">Sale</th>
            <th className="px-2 py-2 text-right">Paid</th>
            <th className="px-2 py-2 text-right">Due</th>
            <th className="px-2 py-2 text-right">Balance</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((s) => {
            bal += Number(s.due_amount);
            return (
              <tr key={s.id} className="border-b">
                <td className="px-2 py-2">{s.sale_date}</td>
                <td className="px-2 py-2 font-mono text-xs">{s.invoice_no}</td>
                <td className="px-2 py-2 text-right">৳{Number(s.total_amount).toFixed(0)}</td>
                <td className="px-2 py-2 text-right text-emerald-700">৳{Number(s.paid_amount).toFixed(0)}</td>
                <td className="px-2 py-2 text-right text-rose-600">৳{Number(s.due_amount).toFixed(0)}</td>
                <td className="px-2 py-2 text-right font-semibold">৳{bal.toFixed(0)}</td>
              </tr>
            );
          })}
          {sorted.length === 0 && <tr><td colSpan={6} className="text-center py-6 text-gray-500">No transactions</td></tr>}
        </tbody>
        <tfoot>
          <tr className="bg-gray-100 font-bold">
            <td colSpan={4} className="px-2 py-2 text-right">Current Due:</td>
            <td colSpan={2} className="px-2 py-2 text-right text-rose-600">৳{Number(c.due_amount).toFixed(0)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}

function DueCollect({ c, onCollect }: { c: Customer; onCollect: (amount: number) => void }) {
  const [amount, setAmount] = useState<number>(Number(c.due_amount));
  return (
    <div className="space-y-3">
      <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 text-center">
        <p className="text-xs text-rose-600">Current Due</p>
        <p className="text-2xl font-bold text-rose-700">৳{Number(c.due_amount).toFixed(2)}</p>
      </div>
      <Field label="Collect Amount">
        <input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)} className="w-full border rounded-lg px-3 py-2 text-lg" />
      </Field>
      <button onClick={() => onCollect(amount)} className="w-full px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-lg font-medium">
        Receive Payment
      </button>
    </div>
  );
}
