import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import jsPDF from "jspdf";
import {
  Wallet, TrendingDown, TrendingUp, AlertTriangle, Download, Printer, Share2,
  Search, BookOpen, X, Banknote, Smartphone, CreditCard, Trophy, Bell,
  ArrowDownRight, ArrowUpRight, Building2, Phone,
} from "lucide-react";

type Supplier = { id: string; name: string; mobile: string | null; address: string | null; advance: number; total_due: number };
type Purchase = { id: string; product_id: string | null; supplier_id: string | null; pieces: number; cost_per_piece: number; total_cost: number; purchase_date: string };
type CashTx = { id: string; type: "in" | "out"; amount: number; reason: string | null; trans_date: string; created_at?: string };

type Period = "today" | "week" | "month" | "all" | "custom";
type PayMethod = "Cash" | "bKash" | "Nagad" | "Rocket" | "Bank";

const META_KEY = "tiles_supplier_pay_meta_v1";
type PayMeta = Record<string, { supplierId: string; method: PayMethod; note?: string }>;
const loadMeta = (): PayMeta => { try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch { return {}; } };
const saveMeta = (m: PayMeta) => localStorage.setItem(META_KEY, JSON.stringify(m));

const fmt = (n: number) => `৳${Number(n || 0).toLocaleString("en-BD", { maximumFractionDigits: 2 })}`;
const today = () => new Date().toISOString().slice(0, 10);
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const iso = (d: Date) => d.toISOString().slice(0, 10);

export default function SupplierPayment({
  userId, suppliers, purchases, cashTx, refresh,
}: {
  userId: string; suppliers: Supplier[]; purchases: Purchase[]; cashTx: CashTx[]; refresh: () => void;
}) {
  const [meta, setMeta] = useState<PayMeta>(() => loadMeta());
  const [period, setPeriod] = useState<Period>("month");
  const [fromDate, setFromDate] = useState(iso(addDays(new Date(), -30)));
  const [toDate, setToDate] = useState(today());
  const [search, setSearch] = useState("");
  const [ledger, setLedger] = useState<Supplier | null>(null);

  // Payment form
  const [supplierId, setSupplierId] = useState("");
  const [amount, setAmount] = useState<number>(0);
  const [method, setMethod] = useState<PayMethod>("Cash");
  const [note, setNote] = useState("");
  const [payFull, setPayFull] = useState(false);

  const range = useMemo(() => {
    const now = new Date();
    if (period === "today") return { from: today(), to: today() };
    if (period === "week") return { from: iso(addDays(now, -7)), to: today() };
    if (period === "month") return { from: iso(addDays(now, -30)), to: today() };
    if (period === "all") return { from: "0000-01-01", to: "9999-12-31" };
    return { from: fromDate, to: toDate };
  }, [period, fromDate, toDate]);

  const inRange = (d: string) => d >= range.from && d <= range.to;

  // Per-supplier aggregates
  const rows = useMemo(() => suppliers.map((s) => {
    const purs = purchases.filter((p) => p.supplier_id === s.id);
    const totalPurchaseAll = purs.reduce((a, p) => a + Number(p.total_cost), 0);
    const totalPurchase = purs.filter((p) => inRange(p.purchase_date)).reduce((a, p) => a + Number(p.total_cost), 0);
    const payments = cashTx.filter((t) => t.type === "out" && meta[t.id]?.supplierId === s.id);
    const paid = payments.reduce((a, t) => a + Number(t.amount), 0);
    const paidInRange = payments.filter((t) => inRange(t.trans_date)).reduce((a, t) => a + Number(t.amount), 0);
    const due = Number(s.total_due);
    const advance = Number(s.advance || 0);
    const lastPay = payments.sort((a, b) => b.trans_date.localeCompare(a.trans_date))[0];
    const daysSince = lastPay ? Math.floor((Date.now() - new Date(lastPay.trans_date).getTime()) / 86400000) : null;
    return { s, totalPurchase, totalPurchaseAll, paid, paidInRange, due, advance, lastPay, daysSince, payments };
  }), [suppliers, purchases, cashTx, meta, range]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? rows.filter((r) => [r.s.name, r.s.mobile].some((x) => (x || "").toLowerCase().includes(q))) : rows;
  }, [rows, search]);

  const totals = useMemo(() => rows.reduce((a, r) => ({
    purchase: a.purchase + r.totalPurchase,
    paid: a.paid + r.paid,
    paidPeriod: a.paidPeriod + r.paidInRange,
    due: a.due + r.due,
    advance: a.advance + r.advance,
  }), { purchase: 0, paid: 0, paidPeriod: 0, due: 0, advance: 0 }), [rows]);

  // Auto-fill amount when "Pay Full" toggled or supplier changes
  const selectedSup = suppliers.find((s) => s.id === supplierId);
  useEffect(() => {
    if (payFull && selectedSup) setAmount(Number(selectedSup.total_due) || 0);
  }, [payFull, selectedSup]);

  const pay = async () => {
    if (!supplierId) return toast.error("Select a supplier");
    if (amount <= 0) return toast.error("Enter amount > 0");
    const s = suppliers.find((x) => x.id === supplierId)!;
    const curDue = Number(s.total_due);
    const curAdv = Number(s.advance || 0);
    let newDue = curDue - amount;
    let newAdv = curAdv;
    if (newDue < 0) { newAdv += -newDue; newDue = 0; }

    const { error: e1 } = await supabase.from("suppliers")
      .update({ total_due: newDue, advance: newAdv }).eq("id", supplierId);
    if (e1) return toast.error(e1.message);

    const { data: tx, error: e2 } = await supabase.from("cash_transactions").insert({
      user_id: userId, type: "out", amount,
      reason: `Payment to ${s.name} (${method})${note ? ` — ${note}` : ""}`,
      trans_date: today(),
    }).select().single();
    if (e2) return toast.error(e2.message);

    if (tx?.id) {
      const m = { ...meta, [tx.id]: { supplierId, method, note } };
      saveMeta(m); setMeta(m);
    }

    if (curAdv + amount - curDue > 0 && newDue === 0 && newAdv > curAdv) {
      toast.warning(`Overpayment! ৳${(newAdv - curAdv).toFixed(2)} added to advance`);
    } else {
      toast.success("Payment recorded");
    }
    setAmount(0); setNote(""); setPayFull(false); refresh();
  };

  const exportPDF = () => {
    try {
      const doc = new jsPDF();
      doc.setFontSize(16); doc.text("Supplier Payment Report", 14, 16);
      doc.setFontSize(10); doc.text(`Period: ${range.from} to ${range.to}`, 14, 24);
      doc.text(`Total Purchase: ${fmt(totals.purchase)} | Paid: ${fmt(totals.paid)} | Due: ${fmt(totals.due)}`, 14, 32);
      let y = 44;
      doc.text("Supplier", 14, y); doc.text("Purchase", 80, y); doc.text("Paid", 120, y); doc.text("Due", 160, y);
      y += 4; doc.line(14, y, 196, y); y += 5;
      filtered.forEach((r) => {
        if (y > 280) { doc.addPage(); y = 20; }
        doc.text(r.s.name.slice(0, 28), 14, y);
        doc.text(r.totalPurchase.toFixed(0), 80, y);
        doc.text(r.paid.toFixed(0), 120, y);
        doc.text(r.due.toFixed(0), 160, y);
        y += 6;
      });
      doc.save(`supplier-payments-${range.from}-${range.to}.pdf`);
      toast.success("PDF downloaded");
    } catch { toast.error("Failed to export"); }
  };

  const exportCSV = () => {
    const header = "Supplier,Mobile,Purchase,Paid,Due,Advance\n";
    const body = filtered.map((r) => [r.s.name, r.s.mobile || "", r.totalPurchase, r.paid, r.due, r.advance].join(",")).join("\n");
    const blob = new Blob([header + body], { type: "text/csv" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = `supplier-payments-${range.from}-${range.to}.csv`; a.click(); URL.revokeObjectURL(url);
    toast.success("CSV downloaded");
  };

  const shareWA = (r?: typeof rows[number]) => {
    const target = r || filtered[0];
    if (!target) return;
    const txt = `💳 Supplier Payment Status\n${target.s.name}\nPurchase: ${fmt(target.totalPurchase)}\nPaid: ${fmt(target.paid)}\nDue: ${fmt(target.due)}`;
    const phone = (target.s.mobile || "").replace(/\D/g, "");
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(txt)}`, "_blank");
  };

  // Smart alerts
  const alerts = useMemo(() => {
    const a: { type: "danger" | "warn" | "info"; msg: string }[] = [];
    rows.forEach((r) => {
      if (r.due > 100000) a.push({ type: "danger", msg: `${r.s.name}: Very high due ${fmt(r.due)}` });
      else if (r.due > 50000) a.push({ type: "warn", msg: `${r.s.name}: High due ${fmt(r.due)}` });
      if (r.daysSince !== null && r.daysSince > 30 && r.due > 0) a.push({ type: "warn", msg: `${r.s.name}: No payment for ${r.daysSince} days` });
      if (r.advance > 0) a.push({ type: "info", msg: `${r.s.name}: Advance ${fmt(r.advance)}` });
    });
    return a;
  }, [rows]);

  const ranking = [...rows].sort((a, b) => b.totalPurchase - a.totalPurchase);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600 text-white p-5 shadow-lg">
        <div className="absolute inset-0 bg-white/5 backdrop-blur-sm" />
        <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center"><Wallet className="w-7 h-7" /></div>
            <div>
              <h2 className="text-2xl font-bold">Supplier Payment</h2>
              <p className="text-sm text-white/80">Smart accounting • Auto due • Ledger • Alerts</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={exportPDF} className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur px-3 py-2 rounded-lg text-sm"><Download className="w-4 h-4" /> PDF</button>
            <button onClick={exportCSV} className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur px-3 py-2 rounded-lg text-sm"><Download className="w-4 h-4" /> Excel</button>
            <button onClick={() => window.print()} className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur px-3 py-2 rounded-lg text-sm"><Printer className="w-4 h-4" /> Print</button>
          </div>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Kpi icon={TrendingDown} label={`Total Purchase (${period})`} value={fmt(totals.purchase)} g="from-blue-500 to-indigo-600" />
        <Kpi icon={TrendingUp} label="Total Paid" value={fmt(totals.paid)} g="from-emerald-500 to-teal-600" />
        <Kpi icon={Wallet} label={`Paid (${period})`} value={fmt(totals.paidPeriod)} g="from-cyan-500 to-sky-600" />
        <Kpi icon={AlertTriangle} label="Outstanding Due" value={fmt(totals.due)} g="from-rose-500 to-red-600" />
        <Kpi icon={ArrowUpRight} label="Advance Balance" value={fmt(totals.advance)} g="from-violet-500 to-purple-600" />
      </div>

      {/* Payment Form */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
          <h3 className="font-bold flex items-center gap-2 mb-4"><Banknote className="w-5 h-5 text-emerald-600" /> Smart Payment Entry</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="md:col-span-2">
              <label className="text-xs font-medium text-gray-600">Supplier *</label>
              <select value={supplierId} onChange={(e) => { setSupplierId(e.target.value); setPayFull(false); }} className="border rounded-lg p-2 w-full text-sm">
                <option value="">Select Supplier</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>{s.name} — Due: {fmt(Number(s.total_due))}{Number(s.advance) > 0 ? ` | Adv: ${fmt(Number(s.advance))}` : ""}</option>
                ))}
              </select>
            </div>
            {selectedSup && (
              <div className="md:col-span-2 grid grid-cols-3 gap-2 text-xs">
                <Mini label="Current Due" value={fmt(Number(selectedSup.total_due))} color="bg-rose-500" />
                <Mini label="Advance" value={fmt(Number(selectedSup.advance || 0))} color="bg-violet-500" />
                <Mini label="Mobile" value={selectedSup.mobile || "—"} color="bg-blue-500" />
              </div>
            )}
            <div>
              <label className="text-xs font-medium text-gray-600">Payment Method</label>
              <div className="flex flex-wrap gap-1.5 mt-1">
                {(["Cash", "bKash", "Nagad", "Rocket", "Bank"] as PayMethod[]).map((m) => (
                  <button key={m} type="button" onClick={() => setMethod(m)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${method === m ? "bg-emerald-600 text-white border-emerald-600" : "bg-white hover:bg-gray-50"}`}>
                    {m === "Cash" ? <Banknote className="w-3.5 h-3.5 inline mr-1" /> :
                     m === "Bank" ? <CreditCard className="w-3.5 h-3.5 inline mr-1" /> :
                     <Smartphone className="w-3.5 h-3.5 inline mr-1" />}{m}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-gray-600">Amount *</label>
              <input type="number" value={amount || ""} onChange={(e) => { setAmount(parseFloat(e.target.value) || 0); setPayFull(false); }}
                placeholder="0" className="border rounded-lg p-2 w-full text-sm" />
              <label className="flex items-center gap-1.5 mt-1.5 text-xs text-gray-600">
                <input type="checkbox" checked={payFull} onChange={(e) => setPayFull(e.target.checked)} />
                Pay full due ({fmt(Number(selectedSup?.total_due || 0))})
              </label>
            </div>
            <div className="md:col-span-2">
              <label className="text-xs font-medium text-gray-600">Note (optional)</label>
              <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Reference / Transaction ID" className="border rounded-lg p-2 w-full text-sm" />
            </div>
            <div className="md:col-span-2 flex gap-2 pt-2">
              <button onClick={pay} className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold py-2.5 rounded-lg shadow hover:shadow-lg transition">
                Record Payment
              </button>
            </div>
          </div>
        </div>

        {/* Smart Alerts */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
          <h3 className="font-bold flex items-center gap-2 mb-3"><Bell className="w-5 h-5 text-amber-500" /> Smart Alerts</h3>
          {alerts.length === 0 ? (
            <p className="text-sm text-gray-400">All clear — no warnings.</p>
          ) : (
            <ul className="space-y-2 max-h-72 overflow-y-auto">
              {alerts.slice(0, 12).map((a, i) => (
                <li key={i} className={`text-xs p-2 rounded-lg border ${
                  a.type === "danger" ? "bg-red-50 text-red-700 border-red-200" :
                  a.type === "warn" ? "bg-amber-50 text-amber-700 border-amber-200" :
                  "bg-blue-50 text-blue-700 border-blue-200"
                }`}>{a.msg}</li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white/80 backdrop-blur rounded-2xl shadow-sm p-4 border border-white/60">
        <div className="flex flex-wrap gap-2 mb-3">
          {(["today", "week", "month", "all", "custom"] as Period[]).map((p) => (
            <button key={p} onClick={() => setPeriod(p)} className={`px-3 py-1.5 text-sm rounded-lg capitalize ${period === p ? "bg-emerald-600 text-white shadow" : "bg-gray-100 hover:bg-gray-200"}`}>{p}</button>
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <label className="text-xs font-medium text-gray-600">From</label>
            <input type="date" value={range.from === "0000-01-01" ? "" : range.from} onChange={(e) => { setPeriod("custom"); setFromDate(e.target.value); }} className="border rounded-lg p-2 w-full text-sm" />
          </div>
          <div>
            <label className="text-xs font-medium text-gray-600">To</label>
            <input type="date" value={range.to === "9999-12-31" ? "" : range.to} onChange={(e) => { setPeriod("custom"); setToDate(e.target.value); }} className="border rounded-lg p-2 w-full text-sm" />
          </div>
          <div>
            <label className="text-xs font-medium text-gray-600">Search</label>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-2 top-2.5 text-gray-400" />
              <input placeholder="Supplier name or mobile" value={search} onChange={(e) => setSearch(e.target.value)} className="border rounded-lg p-2 pl-8 w-full text-sm" />
            </div>
          </div>
        </div>
      </div>

      {/* Suppliers table */}
      <div className="bg-white rounded-2xl shadow-sm overflow-hidden border border-gray-100">
        <div className="px-4 py-3 bg-gradient-to-r from-gray-50 to-white border-b flex items-center justify-between">
          <h3 className="font-bold flex items-center gap-2"><Building2 className="w-5 h-5 text-emerald-600" /> Supplier Accounts</h3>
          <span className="text-xs text-gray-500">{filtered.length} suppliers</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-gray-600">
              <tr>
                <th className="p-2 text-left">Supplier</th>
                <th className="p-2 text-left">Mobile</th>
                <th className="p-2 text-right">Purchase</th>
                <th className="p-2 text-right">Paid</th>
                <th className="p-2 text-right">Due</th>
                <th className="p-2 text-right">Advance</th>
                <th className="p-2 text-center">Last Pay</th>
                <th className="p-2 text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={8} className="p-6 text-center text-gray-400">No suppliers found</td></tr>
              )}
              {filtered.map((r) => (
                <tr key={r.s.id} className="border-t hover:bg-gray-50/60">
                  <td className="p-2 font-medium">{r.s.name}</td>
                  <td className="p-2 text-gray-600">{r.s.mobile || "—"}</td>
                  <td className="p-2 text-right">{fmt(r.totalPurchase)}</td>
                  <td className="p-2 text-right text-emerald-700">{fmt(r.paid)}</td>
                  <td className={`p-2 text-right font-semibold ${r.due > 0 ? "text-rose-700" : "text-gray-500"}`}>{fmt(r.due)}</td>
                  <td className="p-2 text-right text-violet-700">{r.advance > 0 ? fmt(r.advance) : "—"}</td>
                  <td className="p-2 text-center text-xs text-gray-500">{r.lastPay?.trans_date || "—"}</td>
                  <td className="p-2 text-center">
                    <div className="flex gap-1 justify-center">
                      <button onClick={() => { setSupplierId(r.s.id); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                        className="px-2 py-1 text-xs bg-emerald-100 text-emerald-700 rounded hover:bg-emerald-200">Pay</button>
                      <button onClick={() => setLedger(r.s)} className="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded hover:bg-blue-200 flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />Ledger
                      </button>
                      {r.s.mobile && (
                        <button onClick={() => shareWA(r)} className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded hover:bg-green-200">
                          <Share2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Ranking */}
      {ranking.length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="px-4 py-3 bg-gradient-to-r from-amber-50 to-yellow-50 border-b flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-600" /><h3 className="font-bold">Top Suppliers (by purchase)</h3>
          </div>
          <div className="divide-y">
            {ranking.slice(0, 5).map((r, i) => (
              <div key={r.s.id} className="flex items-center gap-3 px-4 py-3">
                <div className={`w-8 h-8 rounded-full text-white flex items-center justify-center font-bold text-sm ${i === 0 ? "bg-amber-500" : i === 1 ? "bg-gray-400" : i === 2 ? "bg-orange-500" : "bg-emerald-500"}`}>{i + 1}</div>
                <div className="flex-1"><div className="font-medium">{r.s.name}</div><div className="text-xs text-gray-500">{r.s.mobile || ""}</div></div>
                <div className="text-right"><div className="font-bold">{fmt(r.totalPurchase)}</div><div className="text-xs text-rose-600">Due {fmt(r.due)}</div></div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Ledger Modal */}
      {ledger && <LedgerModal supplier={ledger} purchases={purchases.filter((p) => p.supplier_id === ledger.id)}
        payments={cashTx.filter((t) => t.type === "out" && meta[t.id]?.supplierId === ledger.id)}
        meta={meta} onClose={() => setLedger(null)} />}
    </div>
  );
}

function LedgerModal({ supplier, purchases, payments, meta, onClose }: {
  supplier: Supplier; purchases: Purchase[]; payments: CashTx[]; meta: PayMeta; onClose: () => void;
}) {
  const entries = useMemo(() => {
    const list: { date: string; type: "Purchase" | "Payment"; desc: string; debit: number; credit: number }[] = [];
    purchases.forEach((p) => list.push({ date: p.purchase_date, type: "Purchase", desc: `Purchase (${p.pieces} pcs)`, debit: Number(p.total_cost), credit: 0 }));
    payments.forEach((t) => list.push({ date: t.trans_date, type: "Payment", desc: `${meta[t.id]?.method || "Cash"} payment${meta[t.id]?.note ? ` — ${meta[t.id]!.note}` : ""}`, debit: 0, credit: Number(t.amount) }));
    list.sort((a, b) => a.date.localeCompare(b.date));
    let bal = 0;
    return list.map((e) => { bal += e.debit - e.credit; return { ...e, balance: bal }; });
  }, [purchases, payments, meta]);

  const totalPurchase = purchases.reduce((a, p) => a + Number(p.total_cost), 0);
  const totalPaid = payments.reduce((a, t) => a + Number(t.amount), 0);

  const downloadPDF = () => {
    try {
      const doc = new jsPDF();
      doc.setFontSize(16); doc.text(`Ledger — ${supplier.name}`, 14, 16);
      doc.setFontSize(10); doc.text(`Mobile: ${supplier.mobile || "—"}`, 14, 24);
      doc.text(`Purchase: ${fmt(totalPurchase)} | Paid: ${fmt(totalPaid)} | Due: ${fmt(Number(supplier.total_due))}`, 14, 30);
      let y = 42;
      doc.text("Date", 14, y); doc.text("Description", 45, y); doc.text("Debit", 130, y); doc.text("Credit", 155, y); doc.text("Balance", 180, y);
      y += 4; doc.line(14, y, 200, y); y += 5;
      entries.forEach((e) => {
        if (y > 280) { doc.addPage(); y = 20; }
        doc.text(e.date, 14, y);
        doc.text(e.desc.slice(0, 40), 45, y);
        doc.text(e.debit ? e.debit.toFixed(0) : "-", 130, y);
        doc.text(e.credit ? e.credit.toFixed(0) : "-", 155, y);
        doc.text(e.balance.toFixed(0), 180, y);
        y += 5;
      });
      doc.save(`ledger-${supplier.name}.pdf`);
    } catch { toast.error("Export failed"); }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="p-5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-t-2xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BookOpen className="w-7 h-7" />
            <div>
              <h3 className="text-xl font-bold">{supplier.name}</h3>
              <p className="text-xs text-white/80 flex items-center gap-2"><Phone className="w-3 h-3" />{supplier.mobile || "—"}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={downloadPDF} className="bg-white/20 hover:bg-white/30 px-3 py-1.5 rounded-lg text-sm flex items-center gap-1"><Download className="w-4 h-4" /> PDF</button>
            <button onClick={onClose} className="text-white/80 hover:text-white text-2xl"><X className="w-6 h-6" /></button>
          </div>
        </div>
        <div className="p-5">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            <Mini label="Purchase" value={fmt(totalPurchase)} color="bg-blue-500" />
            <Mini label="Paid" value={fmt(totalPaid)} color="bg-emerald-500" />
            <Mini label="Due" value={fmt(Number(supplier.total_due))} color="bg-rose-500" />
            <Mini label="Advance" value={fmt(Number(supplier.advance || 0))} color="bg-violet-500" />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="p-2 text-left">Date</th>
                  <th className="p-2 text-left">Type</th>
                  <th className="p-2 text-left">Description</th>
                  <th className="p-2 text-right">Debit</th>
                  <th className="p-2 text-right">Credit</th>
                  <th className="p-2 text-right">Balance</th>
                </tr>
              </thead>
              <tbody>
                {entries.length === 0 && <tr><td colSpan={6} className="p-6 text-center text-gray-400">No transactions</td></tr>}
                {entries.map((e, i) => (
                  <tr key={i} className="border-t hover:bg-gray-50/60">
                    <td className="p-2">{e.date}</td>
                    <td className="p-2">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${e.type === "Purchase" ? "bg-blue-100 text-blue-700" : "bg-emerald-100 text-emerald-700"}`}>{e.type}</span>
                    </td>
                    <td className="p-2 text-gray-600">{e.desc}</td>
                    <td className="p-2 text-right text-blue-700">{e.debit ? fmt(e.debit) : "—"}</td>
                    <td className="p-2 text-right text-emerald-700">{e.credit ? fmt(e.credit) : "—"}</td>
                    <td className={`p-2 text-right font-semibold ${e.balance > 0 ? "text-rose-700" : "text-gray-500"}`}>{fmt(e.balance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

function Kpi({ icon: Icon, label, value, g }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; g: string }) {
  return (
    <div className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${g} text-white p-4 shadow-md`}>
      <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/10 rounded-full blur-2xl" />
      <div className="relative flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-white/20 backdrop-blur flex items-center justify-center"><Icon className="w-5 h-5" /></div>
        <div className="min-w-0">
          <div className="text-xs opacity-80 truncate">{label}</div>
          <div className="font-extrabold text-lg truncate">{value}</div>
        </div>
      </div>
    </div>
  );
}

function Mini({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className={`${color} text-white rounded-xl p-3`}>
      <div className="text-[10px] uppercase opacity-90">{label}</div>
      <div className="font-extrabold truncate">{value}</div>
    </div>
  );
}
