ALTER TABLE public.products ADD COLUMN product_code text;

CREATE UNIQUE INDEX products_product_code_unique ON public.products (product_code) WHERE product_code IS NOT NULL AND product_code <> '';

GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;