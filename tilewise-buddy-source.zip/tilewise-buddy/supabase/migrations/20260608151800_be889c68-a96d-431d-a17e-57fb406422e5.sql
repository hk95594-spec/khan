CREATE TABLE public.stock_cuts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  pieces INTEGER NOT NULL DEFAULT 0,
  reason TEXT,
  cut_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.stock_cuts TO authenticated;
GRANT ALL ON public.stock_cuts TO service_role;

ALTER TABLE public.stock_cuts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own stock cuts" ON public.stock_cuts FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
