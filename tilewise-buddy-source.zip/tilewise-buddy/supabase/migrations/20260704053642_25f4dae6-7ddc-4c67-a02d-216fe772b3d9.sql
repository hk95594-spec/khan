
CREATE TABLE public.due_payments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  memo_no TEXT NOT NULL,
  previous_due NUMERIC NOT NULL DEFAULT 0,
  paid_amount NUMERIC NOT NULL DEFAULT 0,
  remaining_due NUMERIC NOT NULL DEFAULT 0,
  kind TEXT NOT NULL DEFAULT 'payment',
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.due_payments TO authenticated;
GRANT ALL ON public.due_payments TO service_role;
ALTER TABLE public.due_payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own due_payments" ON public.due_payments
  FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_due_payments_customer ON public.due_payments(customer_id, created_at DESC);
